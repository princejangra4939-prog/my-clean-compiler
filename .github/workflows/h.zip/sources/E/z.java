package e;

import android.view.KeyEvent;
import android.view.MotionEvent;
import androidx.appcompat.widget.ContentFrameLayout;
import g.C0030c;

/* JADX INFO: loaded from: classes.dex */
public final class z extends ContentFrameLayout {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final /* synthetic */ LayoutInflaterFactory2C0012B f1007i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public z(LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B, C0030c c0030c) {
        super(c0030c, null);
        this.f1007i = layoutInflaterFactory2C0012B;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return this.f1007i.u(keyEvent) || super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            int x2 = (int) motionEvent.getX();
            int y2 = (int) motionEvent.getY();
            if (x2 < -5 || y2 < -5 || x2 > getWidth() + 5 || y2 > getHeight() + 5) {
                LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = this.f1007i;
                layoutInflaterFactory2C0012B.s(layoutInflaterFactory2C0012B.z(0), true);
                return true;
            }
        }
        return super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.view.View
    public final void setBackgroundResource(int i2) {
        setBackgroundDrawable(D.g.w(getContext(), i2));
    }
}
