package e;

import androidx.appcompat.widget.ActionMenuView;
import i.C0061h;
import i.C0069l;

/* JADX INFO: loaded from: classes.dex */
public final class H implements h.y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f898a;
    public final /* synthetic */ I b;

    public H(I i2) {
        this.b = i2;
    }

    @Override // h.y
    public final void b(h.n nVar, boolean z2) {
        C0069l c0069l;
        if (this.f898a) {
            return;
        }
        this.f898a = true;
        I i2 = this.b;
        ActionMenuView actionMenuView = i2.f899o.f1339a.f489a;
        if (actionMenuView != null && (c0069l = actionMenuView.f450t) != null) {
            c0069l.f();
            C0061h c0061h = c0069l.f1404t;
            if (c0061h != null && c0061h.b()) {
                c0061h.f1207i.dismiss();
            }
        }
        i2.f900p.onPanelClosed(108, nVar);
        this.f898a = false;
    }

    @Override // h.y
    public final boolean m(h.n nVar) {
        this.b.f900p.onMenuOpened(108, nVar);
        return true;
    }
}
