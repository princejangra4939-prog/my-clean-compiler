package e;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

/* JADX INFO: renamed from: e.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ExecutorC0026m implements Executor {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f985a = new Object();
    public final ArrayDeque b = new ArrayDeque();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ExecutorC0027n f986c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Runnable f987d;

    public ExecutorC0026m(ExecutorC0027n executorC0027n) {
        this.f986c = executorC0027n;
    }

    public final void a() {
        synchronized (this.f985a) {
            try {
                Runnable runnable = (Runnable) this.b.poll();
                this.f987d = runnable;
                if (runnable != null) {
                    this.f986c.execute(runnable);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        synchronized (this.f985a) {
            try {
                this.b.add(new L.h(this, 1, runnable));
                if (this.f987d == null) {
                    a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
