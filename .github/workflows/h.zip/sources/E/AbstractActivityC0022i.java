package e;

import android.R;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import e.AbstractActivityC0022i;
import g.C0035h;
import i.C0088v;
import i.N0;
import i.j1;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import l.C0105e;
import x.InterfaceC0149a;

/* JADX INFO: renamed from: e.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractActivityC0022i extends androidx.activity.l implements InterfaceC0023j, o.b {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f981t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f982u;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public LayoutInflaterFactory2C0012B f984w;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final C.j f979r = new C.j(12, new androidx.fragment.app.f(this));

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final androidx.lifecycle.s f980s = new androidx.lifecycle.s(this);

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f983v = true;

    public AbstractActivityC0022i() {
        ((M.e) this.f331e.f120c).e("android:support:lifecycle", new androidx.activity.f(1, this));
        final int i2 = 0;
        this.f336k.add(new InterfaceC0149a(this) { // from class: androidx.fragment.app.e
            public final /* synthetic */ AbstractActivityC0022i b;

            {
                this.b = this;
            }

            @Override // x.InterfaceC0149a
            public final void a(Object obj) {
                switch (i2) {
                    case 0:
                        this.b.f979r.x();
                        break;
                    default:
                        this.b.f979r.x();
                        break;
                }
            }
        });
        final int i3 = 1;
        this.f338m.add(new InterfaceC0149a(this) { // from class: androidx.fragment.app.e
            public final /* synthetic */ AbstractActivityC0022i b;

            {
                this.b = this;
            }

            @Override // x.InterfaceC0149a
            public final void a(Object obj) {
                switch (i3) {
                    case 0:
                        this.b.f979r.x();
                        break;
                    default:
                        this.b.f979r.x();
                        break;
                }
            }
        });
        f(new androidx.activity.g(this, 1));
    }

    @Override // android.app.Activity
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        h();
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
        layoutInflaterFactory2C0012B.w();
        ((ViewGroup) layoutInflaterFactory2C0012B.f840A.findViewById(R.id.content)).addView(view, layoutParams);
        layoutInflaterFactory2C0012B.f875m.a(layoutInflaterFactory2C0012B.f874l.getCallback());
    }

    /* JADX WARN: Removed duplicated region for block: B:167:0x0232 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0099  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00ab  */
    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void attachBaseContext(android.content.Context r11) {
        /*
            Method dump skipped, instruction units count: 587
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: e.AbstractActivityC0022i.attachBaseContext(android.content.Context):void");
    }

    @Override // android.app.Activity
    public final void closeOptionsMenu() {
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
        layoutInflaterFactory2C0012B.A();
        D.g gVar = layoutInflaterFactory2C0012B.f877o;
        if (getWindow().hasFeature(0)) {
            if (gVar == null || !gVar.f()) {
                super.closeOptionsMenu();
            }
        }
    }

    @Override // o.h, android.app.Activity, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
        layoutInflaterFactory2C0012B.A();
        D.g gVar = layoutInflaterFactory2C0012B.f877o;
        if (keyCode == 82 && gVar != null && gVar.P(keyEvent)) {
            return true;
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0046  */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void dump(java.lang.String r6, java.io.FileDescriptor r7, java.io.PrintWriter r8, java.lang.String[] r9) {
        /*
            Method dump skipped, instruction units count: 620
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: e.AbstractActivityC0022i.dump(java.lang.String, java.io.FileDescriptor, java.io.PrintWriter, java.lang.String[]):void");
    }

    @Override // android.app.Activity
    public final View findViewById(int i2) {
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
        layoutInflaterFactory2C0012B.w();
        return layoutInflaterFactory2C0012B.f874l.findViewById(i2);
    }

    @Override // android.app.Activity
    public final MenuInflater getMenuInflater() {
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
        if (layoutInflaterFactory2C0012B.f878p == null) {
            layoutInflaterFactory2C0012B.A();
            D.g gVar = layoutInflaterFactory2C0012B.f877o;
            layoutInflaterFactory2C0012B.f878p = new C0035h(gVar != null ? gVar.D() : layoutInflaterFactory2C0012B.f873k);
        }
        return layoutInflaterFactory2C0012B.f878p;
    }

    @Override // android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final Resources getResources() {
        int i2 = j1.f1385a;
        return super.getResources();
    }

    public final o i() {
        if (this.f984w == null) {
            ExecutorC0026m executorC0026m = o.f988a;
            this.f984w = new LayoutInflaterFactory2C0012B(this, null, this, this);
        }
        return this.f984w;
    }

    @Override // android.app.Activity
    public final void invalidateOptionsMenu() {
        i().b();
    }

    public final void j() {
        Integer num;
        Integer num2;
        Integer num3;
        super.onDestroy();
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) this.f979r.b).f635c;
        boolean zIsChangingConfigurations = true;
        pVar.f650A = true;
        pVar.e(true);
        Iterator it = pVar.b().iterator();
        if (it.hasNext()) {
            ((androidx.fragment.app.v) it.next()).a();
            throw null;
        }
        androidx.fragment.app.f fVar = pVar.f671r;
        T.t tVar = pVar.f657c;
        if (fVar != null) {
            zIsChangingConfigurations = ((androidx.fragment.app.r) tVar.f213d).f;
        } else {
            AbstractActivityC0022i abstractActivityC0022i = fVar.f634a;
            if (abstractActivityC0022i != null) {
                zIsChangingConfigurations = true ^ abstractActivityC0022i.isChangingConfigurations();
            }
        }
        if (zIsChangingConfigurations) {
            Iterator it2 = pVar.f662i.values().iterator();
            while (it2.hasNext()) {
                ArrayList arrayList = ((androidx.fragment.app.c) it2.next()).f632a;
                int size = arrayList.size();
                int i2 = 0;
                while (i2 < size) {
                    Object obj = arrayList.get(i2);
                    i2++;
                    String str = (String) obj;
                    androidx.fragment.app.r rVar = (androidx.fragment.app.r) tVar.f213d;
                    rVar.getClass();
                    if (androidx.fragment.app.p.h(3)) {
                        Log.d("FragmentManager", "Clearing non-config state for saved state of Fragment " + str);
                    }
                    HashMap map = rVar.f688d;
                    androidx.fragment.app.r rVar2 = (androidx.fragment.app.r) map.get(str);
                    if (rVar2 != null) {
                        rVar2.a();
                        map.remove(str);
                    }
                    HashMap map2 = rVar.f689e;
                    androidx.lifecycle.G g2 = (androidx.lifecycle.G) map2.get(str);
                    if (g2 != null) {
                        g2.a();
                        map2.remove(str);
                    }
                }
            }
        }
        pVar.c(-1);
        androidx.fragment.app.f fVar2 = pVar.f671r;
        if (fVar2 != null) {
            fVar2.f636d.f337l.remove(pVar.f666m);
        }
        androidx.fragment.app.f fVar3 = pVar.f671r;
        if (fVar3 != null) {
            fVar3.f636d.f336k.remove(pVar.f665l);
        }
        androidx.fragment.app.f fVar4 = pVar.f671r;
        if (fVar4 != null) {
            fVar4.f636d.f339n.remove(pVar.f667n);
        }
        androidx.fragment.app.f fVar5 = pVar.f671r;
        if (fVar5 != null) {
            fVar5.f636d.f340o.remove(pVar.f668o);
        }
        androidx.fragment.app.f fVar6 = pVar.f671r;
        if (fVar6 != null) {
            C.h hVar = fVar6.f636d.f329c;
            CopyOnWriteArrayList copyOnWriteArrayList = (CopyOnWriteArrayList) hVar.b;
            androidx.fragment.app.l lVar = pVar.f669p;
            copyOnWriteArrayList.remove(lVar);
            if (((HashMap) hVar.f7c).remove(lVar) != null) {
                throw new ClassCastException();
            }
            ((Runnable) hVar.f6a).run();
        }
        pVar.f671r = null;
        pVar.f672s = null;
        if (pVar.f != null) {
            Iterator it3 = pVar.f660g.b.iterator();
            while (it3.hasNext()) {
                ((androidx.activity.c) it3.next()).cancel();
            }
            pVar.f = null;
        }
        G.a aVar = pVar.f674u;
        if (aVar != null) {
            androidx.activity.h hVar2 = (androidx.activity.h) aVar.b;
            ArrayList arrayList2 = hVar2.f322d;
            String str2 = (String) aVar.f57a;
            if (!arrayList2.contains(str2) && (num3 = (Integer) hVar2.b.remove(str2)) != null) {
                hVar2.f320a.remove(num3);
            }
            hVar2.f323e.remove(str2);
            HashMap map3 = hVar2.f;
            if (map3.containsKey(str2)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str2 + ": " + map3.get(str2));
                map3.remove(str2);
            }
            Bundle bundle = hVar2.f324g;
            if (bundle.containsKey(str2)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str2 + ": " + bundle.getParcelable(str2));
                bundle.remove(str2);
            }
            if (hVar2.f321c.get(str2) != null) {
                throw new ClassCastException();
            }
            G.a aVar2 = pVar.f675v;
            androidx.activity.h hVar3 = (androidx.activity.h) aVar2.b;
            ArrayList arrayList3 = hVar3.f322d;
            String str3 = (String) aVar2.f57a;
            if (!arrayList3.contains(str3) && (num2 = (Integer) hVar3.b.remove(str3)) != null) {
                hVar3.f320a.remove(num2);
            }
            hVar3.f323e.remove(str3);
            HashMap map4 = hVar3.f;
            if (map4.containsKey(str3)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str3 + ": " + map4.get(str3));
                map4.remove(str3);
            }
            Bundle bundle2 = hVar3.f324g;
            if (bundle2.containsKey(str3)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str3 + ": " + bundle2.getParcelable(str3));
                bundle2.remove(str3);
            }
            if (hVar3.f321c.get(str3) != null) {
                throw new ClassCastException();
            }
            G.a aVar3 = pVar.f676w;
            androidx.activity.h hVar4 = (androidx.activity.h) aVar3.b;
            ArrayList arrayList4 = hVar4.f322d;
            String str4 = (String) aVar3.f57a;
            if (!arrayList4.contains(str4) && (num = (Integer) hVar4.b.remove(str4)) != null) {
                hVar4.f320a.remove(num);
            }
            hVar4.f323e.remove(str4);
            HashMap map5 = hVar4.f;
            if (map5.containsKey(str4)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str4 + ": " + map5.get(str4));
                map5.remove(str4);
            }
            Bundle bundle3 = hVar4.f324g;
            if (bundle3.containsKey(str4)) {
                Log.w("ActivityResultRegistry", "Dropping pending result for request " + str4 + ": " + bundle3.getParcelable(str4));
                bundle3.remove(str4);
            }
            if (hVar4.f321c.get(str4) != null) {
                throw new ClassCastException();
            }
        }
        this.f980s.d(androidx.lifecycle.k.ON_DESTROY);
    }

    public final boolean k(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 != 6) {
            return false;
        }
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) this.f979r.b).f635c;
        if (pVar.f670q < 1) {
            return false;
        }
        Iterator it = pVar.f657c.d().iterator();
        while (it.hasNext()) {
            if (it.next() != null) {
                throw new ClassCastException();
            }
        }
        return false;
    }

    public final void l() {
        super.onPostResume();
        this.f980s.d(androidx.lifecycle.k.ON_RESUME);
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) this.f979r.b).f635c;
        pVar.f678y = false;
        pVar.f679z = false;
        pVar.f654E.getClass();
        pVar.c(7);
    }

    public final void m() {
        C.j jVar = this.f979r;
        jVar.x();
        super.onStart();
        this.f983v = false;
        boolean z2 = this.f981t;
        androidx.fragment.app.f fVar = (androidx.fragment.app.f) jVar.b;
        if (!z2) {
            this.f981t = true;
            androidx.fragment.app.p pVar = fVar.f635c;
            pVar.f678y = false;
            pVar.f679z = false;
            pVar.f654E.getClass();
            pVar.c(4);
        }
        fVar.f635c.e(true);
        this.f980s.d(androidx.lifecycle.k.ON_START);
        androidx.fragment.app.p pVar2 = fVar.f635c;
        pVar2.f678y = false;
        pVar2.f679z = false;
        pVar2.f654E.getClass();
        pVar2.c(5);
    }

    public final void n() {
        super.onStop();
        this.f983v = true;
        C.j jVar = this.f979r;
        Iterator it = ((androidx.fragment.app.f) jVar.b).f635c.f657c.d().iterator();
        while (it.hasNext()) {
            if (it.next() != null) {
                throw new ClassCastException();
            }
        }
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) jVar.b).f635c;
        pVar.f679z = true;
        pVar.f654E.getClass();
        pVar.c(4);
        this.f980s.d(androidx.lifecycle.k.ON_STOP);
    }

    @Override // androidx.activity.l, android.app.Activity
    public void onActivityResult(int i2, int i3, Intent intent) {
        this.f979r.x();
        super.onActivityResult(i2, i3, intent);
    }

    @Override // androidx.activity.l, android.app.Activity, android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) throws IllegalAccessException {
        super.onConfigurationChanged(configuration);
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
        if (layoutInflaterFactory2C0012B.f845F && layoutInflaterFactory2C0012B.f888z) {
            layoutInflaterFactory2C0012B.A();
            D.g gVar = layoutInflaterFactory2C0012B.f877o;
            if (gVar != null) {
                gVar.J();
            }
        }
        C0088v c0088vA = C0088v.a();
        Context context = layoutInflaterFactory2C0012B.f873k;
        synchronized (c0088vA) {
            N0 n0 = c0088vA.f1450a;
            synchronized (n0) {
                C0105e c0105e = (C0105e) n0.b.get(context);
                if (c0105e != null) {
                    int i2 = c0105e.f1512d;
                    Object[] objArr = c0105e.f1511c;
                    for (int i3 = 0; i3 < i2; i3++) {
                        objArr[i3] = null;
                    }
                    c0105e.f1512d = 0;
                    c0105e.f1510a = false;
                }
            }
        }
        layoutInflaterFactory2C0012B.f857R = new Configuration(layoutInflaterFactory2C0012B.f873k.getResources().getConfiguration());
        layoutInflaterFactory2C0012B.n(false, false);
    }

    @Override // androidx.activity.l, o.h, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f980s.d(androidx.lifecycle.k.ON_CREATE);
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) this.f979r.b).f635c;
        pVar.f678y = false;
        pVar.f679z = false;
        pVar.f654E.getClass();
        pVar.c(1);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((androidx.fragment.app.f) this.f979r.b).f635c.f659e.onCreateView(view, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(view, str, context, attributeSet) : viewOnCreateView;
    }

    @Override // android.app.Activity
    public void onDestroy() {
        j();
        i().e();
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        Window window;
        if (Build.VERSION.SDK_INT >= 26 || keyEvent.isCtrlPressed() || KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState()) || keyEvent.getRepeatCount() != 0 || KeyEvent.isModifierKey(keyEvent.getKeyCode()) || (window = getWindow()) == null || window.getDecorView() == null || !window.getDecorView().dispatchKeyShortcutEvent(keyEvent)) {
            return super.onKeyDown(i2, keyEvent);
        }
        return true;
    }

    @Override // androidx.activity.l, android.app.Activity, android.view.Window.Callback
    public final boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        Intent intentB;
        if (!k(i2, menuItem)) {
            LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
            layoutInflaterFactory2C0012B.A();
            D.g gVar = layoutInflaterFactory2C0012B.f877o;
            if (menuItem.getItemId() != 16908332 || gVar == null || (gVar.u() & 4) == 0 || (intentB = o.e.b(this)) == null) {
                return false;
            }
            if (!shouldUpRecreateTask(intentB)) {
                navigateUpTo(intentB);
                return true;
            }
            ArrayList arrayList = new ArrayList();
            Intent intentB2 = o.e.b(this);
            if (intentB2 == null) {
                intentB2 = o.e.b(this);
            }
            if (intentB2 != null) {
                ComponentName component = intentB2.getComponent();
                if (component == null) {
                    component = intentB2.resolveActivity(getPackageManager());
                }
                int size = arrayList.size();
                try {
                    Intent intentC = o.e.c(this, component);
                    while (intentC != null) {
                        arrayList.add(size, intentC);
                        intentC = o.e.c(this, intentC.getComponent());
                    }
                    arrayList.add(intentB2);
                } catch (PackageManager.NameNotFoundException e2) {
                    Log.e("TaskStackBuilder", "Bad ComponentName while traversing activity parent metadata");
                    throw new IllegalArgumentException(e2);
                }
            }
            if (arrayList.isEmpty()) {
                throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
            }
            Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[0]);
            intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
            startActivities(intentArr, null);
            try {
                finishAffinity();
            } catch (IllegalStateException unused) {
                finish();
            }
        }
        return true;
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        this.f982u = false;
        ((androidx.fragment.app.f) this.f979r.b).f635c.c(5);
        this.f980s.d(androidx.lifecycle.k.ON_PAUSE);
    }

    @Override // android.app.Activity
    public final void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        ((LayoutInflaterFactory2C0012B) i()).w();
    }

    @Override // android.app.Activity
    public final void onPostResume() {
        l();
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
        layoutInflaterFactory2C0012B.A();
        D.g gVar = layoutInflaterFactory2C0012B.f877o;
        if (gVar != null) {
            gVar.e0(true);
        }
    }

    @Override // androidx.activity.l, android.app.Activity
    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        this.f979r.x();
        super.onRequestPermissionsResult(i2, strArr, iArr);
    }

    @Override // android.app.Activity
    public void onResume() {
        C.j jVar = this.f979r;
        jVar.x();
        super.onResume();
        this.f982u = true;
        ((androidx.fragment.app.f) jVar.b).f635c.e(true);
    }

    @Override // android.app.Activity
    public final void onStart() throws IllegalAccessException {
        m();
        ((LayoutInflaterFactory2C0012B) i()).n(true, false);
    }

    @Override // android.app.Activity
    public final void onStateNotSaved() {
        this.f979r.x();
    }

    @Override // android.app.Activity
    public final void onStop() {
        n();
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
        layoutInflaterFactory2C0012B.A();
        D.g gVar = layoutInflaterFactory2C0012B.f877o;
        if (gVar != null) {
            gVar.e0(false);
        }
    }

    @Override // android.app.Activity
    public final void onTitleChanged(CharSequence charSequence, int i2) {
        super.onTitleChanged(charSequence, i2);
        i().m(charSequence);
    }

    @Override // android.app.Activity
    public final void openOptionsMenu() {
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) i();
        layoutInflaterFactory2C0012B.A();
        D.g gVar = layoutInflaterFactory2C0012B.f877o;
        if (getWindow().hasFeature(0)) {
            if (gVar == null || !gVar.R()) {
                super.openOptionsMenu();
            }
        }
    }

    @Override // android.app.Activity
    public final void setContentView(int i2) {
        h();
        i().j(i2);
    }

    @Override // android.app.Activity, android.view.ContextThemeWrapper, android.content.ContextWrapper, android.content.Context
    public final void setTheme(int i2) {
        super.setTheme(i2);
        ((LayoutInflaterFactory2C0012B) i()).f859T = i2;
    }

    @Override // androidx.activity.l, android.app.Activity
    public void setContentView(View view) {
        h();
        i().k(view);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((androidx.fragment.app.f) this.f979r.b).f635c.f659e.onCreateView(null, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(str, context, attributeSet) : viewOnCreateView;
    }

    @Override // android.app.Activity
    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        h();
        i().l(view, layoutParams);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final void onContentChanged() {
    }
}
