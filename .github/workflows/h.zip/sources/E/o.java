package e;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import l.C0103c;
import l.C0107g;
import u.C0134c;

/* JADX INFO: loaded from: classes.dex */
public abstract class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final ExecutorC0026m f988a = new ExecutorC0026m(new ExecutorC0027n());
    public static final int b = -100;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static C0134c f989c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static C0134c f990d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Boolean f991e = null;
    public static boolean f = false;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final C0103c f992g = new C0103c(0);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final Object f993h = new Object();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final Object f994i = new Object();

    public static boolean c(Context context) {
        if (f991e == null) {
            try {
                int i2 = F.f896a;
                Bundle bundle = context.getPackageManager().getServiceInfo(new ComponentName(context, (Class<?>) F.class), E.a() | 128).metaData;
                if (bundle != null) {
                    f991e = Boolean.valueOf(bundle.getBoolean("autoStoreLocales"));
                }
            } catch (PackageManager.NameNotFoundException unused) {
                Log.d("AppCompatDelegate", "Checking for metadata for AppLocalesMetadataHolderService : Service not found");
                f991e = Boolean.FALSE;
            }
        }
        return f991e.booleanValue();
    }

    public static void f(LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B) {
        synchronized (f993h) {
            try {
                Iterator it = f992g.iterator();
                while (true) {
                    C0107g c0107g = (C0107g) it;
                    if (c0107g.hasNext()) {
                        o oVar = (o) ((WeakReference) c0107g.next()).get();
                        if (oVar == layoutInflaterFactory2C0012B || oVar == null) {
                            c0107g.remove();
                        }
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public abstract void a();

    public abstract void b();

    public abstract void d();

    public abstract void e();

    public abstract boolean i(int i2);

    public abstract void j(int i2);

    public abstract void k(View view);

    public abstract void l(View view, ViewGroup.LayoutParams layoutParams);

    public abstract void m(CharSequence charSequence);
}
