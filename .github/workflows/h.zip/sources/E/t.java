package e;

import android.content.res.Configuration;
import android.os.LocaleList;
import u.C0134c;

/* JADX INFO: loaded from: classes.dex */
public abstract class t {
    public static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
        LocaleList locales = configuration.getLocales();
        LocaleList locales2 = configuration2.getLocales();
        if (locales.equals(locales2)) {
            return;
        }
        configuration3.setLocales(locales2);
        configuration3.locale = configuration2.locale;
    }

    public static C0134c b(Configuration configuration) {
        return C0134c.a(configuration.getLocales().toLanguageTags());
    }

    public static void c(C0134c c0134c) {
        LocaleList.setDefault(LocaleList.forLanguageTags(c0134c.f1622a.f1623a.toLanguageTags()));
    }

    public static void d(Configuration configuration, C0134c c0134c) {
        configuration.setLocales(LocaleList.forLanguageTags(c0134c.f1622a.f1623a.toLanguageTags()));
    }
}
