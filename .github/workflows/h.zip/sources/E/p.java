package e;

import android.view.ViewGroup;
import y.Q;

/* JADX INFO: loaded from: classes.dex */
public final class p implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f995a;
    public final /* synthetic */ LayoutInflaterFactory2C0012B b;

    public /* synthetic */ p(LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B, int i2) {
        this.f995a = i2;
        this.b = layoutInflaterFactory2C0012B;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ViewGroup viewGroup;
        switch (this.f995a) {
            case 0:
                LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = this.b;
                if ((layoutInflaterFactory2C0012B.f865Z & 1) != 0) {
                    layoutInflaterFactory2C0012B.v(0);
                }
                if ((layoutInflaterFactory2C0012B.f865Z & 4096) != 0) {
                    layoutInflaterFactory2C0012B.v(108);
                }
                layoutInflaterFactory2C0012B.f864Y = false;
                layoutInflaterFactory2C0012B.f865Z = 0;
                break;
            default:
                LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B2 = this.b;
                layoutInflaterFactory2C0012B2.f885w.showAtLocation(layoutInflaterFactory2C0012B2.f884v, 55, 0, 0);
                Q q2 = layoutInflaterFactory2C0012B2.f887y;
                if (q2 != null) {
                    q2.b();
                }
                if (!(layoutInflaterFactory2C0012B2.f888z && (viewGroup = layoutInflaterFactory2C0012B2.f840A) != null && viewGroup.isLaidOut())) {
                    layoutInflaterFactory2C0012B2.f884v.setAlpha(1.0f);
                    layoutInflaterFactory2C0012B2.f884v.setVisibility(0);
                } else {
                    layoutInflaterFactory2C0012B2.f884v.setAlpha(0.0f);
                    Q qA = y.K.a(layoutInflaterFactory2C0012B2.f884v);
                    qA.a(1.0f);
                    layoutInflaterFactory2C0012B2.f887y = qA;
                    qA.d(new r(0, this));
                }
                break;
        }
    }
}
