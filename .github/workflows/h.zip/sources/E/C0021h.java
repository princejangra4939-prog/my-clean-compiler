package e;

import com.warppaiwarden.tictactoe.MainActivity;

/* JADX INFO: renamed from: e.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0021h implements a.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ MainActivity f978a;

    public C0021h(MainActivity mainActivity) {
        this.f978a = mainActivity;
    }

    @Override // a.b
    public final void a() {
        MainActivity mainActivity = this.f978a;
        o oVarI = mainActivity.i();
        oVarI.a();
        ((M.e) mainActivity.f331e.f120c).c("androidx:appcompat");
        oVarI.d();
    }
}
