package e;

import android.view.View;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import java.util.WeakHashMap;
import y.AbstractC0180y;

/* JADX INFO: loaded from: classes.dex */
public final class L extends z.i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f911a;
    public final /* synthetic */ N b;

    public /* synthetic */ L(N n2, int i2) {
        this.f911a = i2;
        this.b = n2;
    }

    @Override // y.S
    public final void a() {
        View view;
        N n2 = this.b;
        switch (this.f911a) {
            case 0:
                if (n2.f920C && (view = n2.f936u) != null) {
                    view.setTranslationY(0.0f);
                    n2.f933r.setTranslationY(0.0f);
                }
                n2.f933r.setVisibility(8);
                n2.f933r.setTransitioning(false);
                n2.f924G = null;
                G.a aVar = n2.f940y;
                if (aVar != null) {
                    aVar.b(n2.f939x);
                    n2.f939x = null;
                    n2.f940y = null;
                }
                ActionBarOverlayLayout actionBarOverlayLayout = n2.f932q;
                if (actionBarOverlayLayout != null) {
                    WeakHashMap weakHashMap = y.K.f1647a;
                    AbstractC0180y.c(actionBarOverlayLayout);
                }
                break;
            default:
                n2.f924G = null;
                n2.f933r.requestLayout();
                break;
        }
    }
}
