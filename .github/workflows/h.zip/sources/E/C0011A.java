package e;

import android.os.Bundle;
import android.view.View;
import g.C0030c;

/* JADX INFO: renamed from: e.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0011A {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f824a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f825c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f826d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public z f827e;
    public View f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public View f828g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public h.n f829h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public h.j f830i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public C0030c f831j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f832k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f833l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f834m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f835n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f836o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Bundle f837p;
}
