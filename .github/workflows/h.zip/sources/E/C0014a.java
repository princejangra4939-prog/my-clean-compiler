package e;

import android.content.DialogInterface;
import android.view.View;
import android.widget.AdapterView;

/* JADX INFO: renamed from: e.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0014a implements AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0018e f942a;
    public final /* synthetic */ C0015b b;

    public C0014a(C0015b c0015b, C0018e c0018e) {
        this.b = c0015b;
        this.f942a = c0018e;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        C0015b c0015b = this.b;
        DialogInterface.OnClickListener onClickListener = c0015b.f948h;
        C0018e c0018e = this.f942a;
        onClickListener.onClick(c0018e.b, i2);
        if (c0015b.f949i) {
            return;
        }
        c0018e.b.dismiss();
    }
}
