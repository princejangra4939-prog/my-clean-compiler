package e;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import androidx.appcompat.widget.ActionBarContextView;
import com.warppaiwarden.tictactoe.R;
import i.InterfaceC0068k0;
import i.l1;
import i.m1;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import p.AbstractC0123b;
import y.AbstractC0151B;
import y.AbstractC0180y;
import y.InterfaceC0172p;
import y.U;
import y.V;
import y.W;
import y.X;
import y.d0;
import y.f0;

/* JADX INFO: loaded from: classes.dex */
public final class q implements InterfaceC0172p, InterfaceC0068k0, h.y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f996a;
    public final /* synthetic */ LayoutInflaterFactory2C0012B b;

    public /* synthetic */ q(LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B, int i2) {
        this.f996a = i2;
        this.b = layoutInflaterFactory2C0012B;
    }

    @Override // y.InterfaceC0172p
    public f0 a(View view, f0 f0Var) {
        int i2;
        boolean z2;
        f0 f0VarB;
        boolean z3;
        boolean z4;
        d0 d0Var = f0Var.f1684a;
        int i3 = d0Var.j().b;
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = this.b;
        layoutInflaterFactory2C0012B.getClass();
        int i4 = d0Var.j().b;
        ActionBarContextView actionBarContextView = layoutInflaterFactory2C0012B.f884v;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            i2 = 0;
            z2 = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutInflaterFactory2C0012B.f884v.getLayoutParams();
            if (layoutInflaterFactory2C0012B.f884v.isShown()) {
                if (layoutInflaterFactory2C0012B.c0 == null) {
                    layoutInflaterFactory2C0012B.c0 = new Rect();
                    layoutInflaterFactory2C0012B.f868d0 = new Rect();
                }
                Rect rect = layoutInflaterFactory2C0012B.c0;
                Rect rect2 = layoutInflaterFactory2C0012B.f868d0;
                rect.set(d0Var.j().f1600a, d0Var.j().b, d0Var.j().f1601c, d0Var.j().f1602d);
                ViewGroup viewGroup = layoutInflaterFactory2C0012B.f840A;
                if (Build.VERSION.SDK_INT >= 29) {
                    boolean z5 = m1.f1408a;
                    l1.a(viewGroup, rect, rect2);
                } else {
                    if (!m1.f1408a) {
                        m1.f1408a = true;
                        try {
                            Method declaredMethod = View.class.getDeclaredMethod("computeFitSystemWindows", Rect.class, Rect.class);
                            m1.b = declaredMethod;
                            if (!declaredMethod.isAccessible()) {
                                m1.b.setAccessible(true);
                            }
                        } catch (NoSuchMethodException unused) {
                            Log.d("ViewUtils", "Could not find method computeFitSystemWindows. Oh well.");
                        }
                    }
                    Method method = m1.b;
                    if (method != null) {
                        try {
                            method.invoke(viewGroup, rect, rect2);
                        } catch (Exception e2) {
                            Log.d("ViewUtils", "Could not invoke computeFitSystemWindows", e2);
                        }
                    }
                }
                int i5 = rect.top;
                int i6 = rect.left;
                int i7 = rect.right;
                ViewGroup viewGroup2 = layoutInflaterFactory2C0012B.f840A;
                WeakHashMap weakHashMap = y.K.f1647a;
                f0 f0VarA = AbstractC0151B.a(viewGroup2);
                int i8 = f0VarA == null ? 0 : f0VarA.f1684a.j().f1600a;
                int i9 = f0VarA == null ? 0 : f0VarA.f1684a.j().f1601c;
                if (marginLayoutParams.topMargin == i5 && marginLayoutParams.leftMargin == i6 && marginLayoutParams.rightMargin == i7) {
                    z4 = false;
                } else {
                    marginLayoutParams.topMargin = i5;
                    marginLayoutParams.leftMargin = i6;
                    marginLayoutParams.rightMargin = i7;
                    z4 = true;
                }
                Context context = layoutInflaterFactory2C0012B.f873k;
                if (i5 <= 0 || layoutInflaterFactory2C0012B.f842C != null) {
                    View view2 = layoutInflaterFactory2C0012B.f842C;
                    if (view2 != null) {
                        ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view2.getLayoutParams();
                        int i10 = marginLayoutParams2.height;
                        int i11 = marginLayoutParams.topMargin;
                        if (i10 != i11 || marginLayoutParams2.leftMargin != i8 || marginLayoutParams2.rightMargin != i9) {
                            marginLayoutParams2.height = i11;
                            marginLayoutParams2.leftMargin = i8;
                            marginLayoutParams2.rightMargin = i9;
                            layoutInflaterFactory2C0012B.f842C.setLayoutParams(marginLayoutParams2);
                        }
                    }
                } else {
                    View view3 = new View(context);
                    layoutInflaterFactory2C0012B.f842C = view3;
                    view3.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
                    layoutParams.leftMargin = i8;
                    layoutParams.rightMargin = i9;
                    layoutInflaterFactory2C0012B.f840A.addView(layoutInflaterFactory2C0012B.f842C, -1, layoutParams);
                }
                View view4 = layoutInflaterFactory2C0012B.f842C;
                boolean z6 = view4 != null;
                if (z6 && view4.getVisibility() != 0) {
                    View view5 = layoutInflaterFactory2C0012B.f842C;
                    view5.setBackgroundColor((view5.getWindowSystemUiVisibility() & 8192) != 0 ? AbstractC0123b.a(context, R.color.abc_decor_view_status_guard_light) : AbstractC0123b.a(context, R.color.abc_decor_view_status_guard));
                }
                if (!layoutInflaterFactory2C0012B.f847H && z6) {
                    i4 = 0;
                }
                z3 = z4;
                z2 = z6;
                i2 = 0;
            } else {
                i2 = 0;
                if (marginLayoutParams.topMargin != 0) {
                    marginLayoutParams.topMargin = 0;
                    z2 = false;
                    z3 = true;
                } else {
                    z2 = false;
                    z3 = false;
                }
            }
            if (z3) {
                layoutInflaterFactory2C0012B.f884v.setLayoutParams(marginLayoutParams);
            }
        }
        View view6 = layoutInflaterFactory2C0012B.f842C;
        if (view6 != null) {
            view6.setVisibility(z2 ? i2 : 8);
        }
        if (i3 != i4) {
            int i12 = d0Var.j().f1600a;
            int i13 = d0Var.j().f1601c;
            int i14 = d0Var.j().f1602d;
            int i15 = Build.VERSION.SDK_INT;
            X w2 = i15 >= 30 ? new W(f0Var) : i15 >= 29 ? new V(f0Var) : new U(f0Var);
            w2.d(r.c.a(i12, i4, i13, i14));
            f0VarB = w2.b();
        } else {
            f0VarB = f0Var;
        }
        WeakHashMap weakHashMap2 = y.K.f1647a;
        WindowInsets windowInsetsB = f0VarB.b();
        if (windowInsetsB == null) {
            return f0VarB;
        }
        WindowInsets windowInsetsB2 = AbstractC0180y.b(view, windowInsetsB);
        return !windowInsetsB2.equals(windowInsetsB) ? f0.c(windowInsetsB2, view) : f0VarB;
    }

    @Override // h.y
    public void b(h.n nVar, boolean z2) {
        C0011A c0011a;
        switch (this.f996a) {
            case 2:
                this.b.r(nVar);
                break;
            default:
                h.n nVarK = nVar.k();
                int i2 = 0;
                boolean z3 = nVarK != nVar;
                if (z3) {
                    nVar = nVarK;
                }
                LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = this.b;
                C0011A[] c0011aArr = layoutInflaterFactory2C0012B.f851L;
                int length = c0011aArr != null ? c0011aArr.length : 0;
                while (true) {
                    if (i2 >= length) {
                        c0011a = null;
                    } else {
                        c0011a = c0011aArr[i2];
                        if (c0011a == null || c0011a.f829h != nVar) {
                            i2++;
                        }
                    }
                }
                if (c0011a != null) {
                    if (!z3) {
                        layoutInflaterFactory2C0012B.s(c0011a, z2);
                    } else {
                        layoutInflaterFactory2C0012B.q(c0011a.f824a, c0011a, nVarK);
                        layoutInflaterFactory2C0012B.s(c0011a, true);
                    }
                }
                break;
        }
    }

    @Override // h.y
    public boolean m(h.n nVar) {
        Window.Callback callback;
        switch (this.f996a) {
            case 2:
                Window.Callback callback2 = this.b.f874l.getCallback();
                if (callback2 != null) {
                    callback2.onMenuOpened(108, nVar);
                }
                break;
            default:
                if (nVar == nVar.k()) {
                    LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = this.b;
                    if (layoutInflaterFactory2C0012B.f845F && (callback = layoutInflaterFactory2C0012B.f874l.getCallback()) != null && !layoutInflaterFactory2C0012B.f856Q) {
                        callback.onMenuOpened(108, nVar);
                        break;
                    }
                }
                break;
        }
        return true;
    }
}
