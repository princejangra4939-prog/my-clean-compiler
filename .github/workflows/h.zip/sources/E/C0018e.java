package e;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;
import androidx.appcompat.app.AlertController$RecycleListView;
import androidx.core.widget.NestedScrollView;
import com.warppaiwarden.tictactoe.R;
import d.AbstractC0010a;
import java.lang.ref.WeakReference;

/* JADX INFO: renamed from: e.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0018e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f952a;
    public final DialogC0020g b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Window f953c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f954d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public AlertController$RecycleListView f955e;
    public Button f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Button f956g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Button f957h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public NestedScrollView f958i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Drawable f959j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public ImageView f960k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public TextView f961l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public TextView f962m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public View f963n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public ListAdapter f964o;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f966q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f967r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int f968s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f969t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final boolean f970u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final HandlerC0016c f971v;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f965p = -1;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final W.c f972w = new W.c(1, this);

    public C0018e(Context context, DialogC0020g dialogC0020g, Window window) {
        this.f952a = context;
        this.b = dialogC0020g;
        this.f953c = window;
        HandlerC0016c handlerC0016c = new HandlerC0016c();
        handlerC0016c.f951a = new WeakReference(dialogC0020g);
        this.f971v = handlerC0016c;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, AbstractC0010a.f803e, R.attr.alertDialogStyle, 0);
        this.f966q = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        typedArrayObtainStyledAttributes.getResourceId(2, 0);
        this.f967r = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f968s = typedArrayObtainStyledAttributes.getResourceId(7, 0);
        this.f969t = typedArrayObtainStyledAttributes.getResourceId(3, 0);
        this.f970u = typedArrayObtainStyledAttributes.getBoolean(6, true);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        dialogC0020g.d().i(1);
    }

    public static ViewGroup a(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }
}
