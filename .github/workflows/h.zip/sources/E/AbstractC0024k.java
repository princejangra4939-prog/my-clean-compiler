package e;

import android.os.LocaleList;

/* JADX INFO: renamed from: e.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0024k {
    public static LocaleList a(String str) {
        return LocaleList.forLanguageTags(str);
    }
}
