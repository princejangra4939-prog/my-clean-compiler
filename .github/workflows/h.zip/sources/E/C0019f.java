package e;

import android.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AlertController$RecycleListView;
import v.C0143g;

/* JADX INFO: renamed from: e.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0019f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f973a;
    public final Object b;

    public C0019f(Context context) {
        int i2 = DialogC0020g.i(context, 0);
        this.b = new C0015b(new ContextThemeWrapper(context, DialogC0020g.i(context, i2)));
        this.f973a = i2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r7v1, types: [android.widget.ListAdapter] */
    /* JADX WARN: Type inference failed for: r7v3 */
    /* JADX WARN: Type inference failed for: r7v4 */
    public DialogC0020g a() {
        C0015b c0015b = (C0015b) this.b;
        DialogC0020g dialogC0020g = new DialogC0020g(c0015b.f943a, this.f973a);
        View view = c0015b.f946e;
        C0018e c0018e = dialogC0020g.f;
        if (view != null) {
            c0018e.f963n = view;
        } else {
            CharSequence charSequence = c0015b.f945d;
            if (charSequence != null) {
                c0018e.f954d = charSequence;
                TextView textView = c0018e.f961l;
                if (textView != null) {
                    textView.setText(charSequence);
                }
            }
            Drawable drawable = c0015b.f944c;
            if (drawable != null) {
                c0018e.f959j = drawable;
                ImageView imageView = c0018e.f960k;
                if (imageView != null) {
                    imageView.setVisibility(0);
                    c0018e.f960k.setImageDrawable(drawable);
                }
            }
        }
        if (c0015b.f947g != null) {
            AlertController$RecycleListView alertController$RecycleListView = (AlertController$RecycleListView) c0015b.b.inflate(c0018e.f967r, (ViewGroup) null);
            int i2 = c0015b.f949i ? c0018e.f968s : c0018e.f969t;
            Object obj = c0015b.f947g;
            ?? c0017d = obj;
            if (obj == null) {
                c0017d = new C0017d(c0015b.f943a, i2, R.id.text1, null);
            }
            c0018e.f964o = c0017d;
            c0018e.f965p = c0015b.f950j;
            if (c0015b.f948h != null) {
                alertController$RecycleListView.setOnItemClickListener(new C0014a(c0015b, c0018e));
            }
            if (c0015b.f949i) {
                alertController$RecycleListView.setChoiceMode(1);
            }
            c0018e.f955e = alertController$RecycleListView;
        }
        dialogC0020g.setCancelable(true);
        dialogC0020g.setCanceledOnTouchOutside(true);
        dialogC0020g.setOnCancelListener(null);
        dialogC0020g.setOnDismissListener(null);
        h.o oVar = c0015b.f;
        if (oVar != null) {
            dialogC0020g.setOnKeyListener(oVar);
        }
        return dialogC0020g;
    }

    public C0019f(int i2, C0143g[] c0143gArr) {
        this.f973a = i2;
        this.b = c0143gArr;
    }
}
