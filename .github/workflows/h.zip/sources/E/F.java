package e;

import android.app.Service;

/* JADX INFO: loaded from: classes.dex */
public abstract class F extends Service {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f896a = 0;
}
