package e;

import android.content.Context;
import android.content.IntentFilter;
import android.location.Location;
import android.location.LocationManager;
import android.os.PowerManager;
import android.util.Log;
import java.util.Calendar;

/* JADX INFO: loaded from: classes.dex */
public final class w extends y {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1002c = 1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ LayoutInflaterFactory2C0012B f1003d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Object f1004e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w(LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B, C.h hVar) {
        super(layoutInflaterFactory2C0012B);
        this.f1003d = layoutInflaterFactory2C0012B;
        this.f1004e = hVar;
    }

    @Override // e.y
    public final IntentFilter d() {
        switch (this.f1002c) {
            case 0:
                IntentFilter intentFilter = new IntentFilter();
                intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
                return intentFilter;
            default:
                IntentFilter intentFilter2 = new IntentFilter();
                intentFilter2.addAction("android.intent.action.TIME_SET");
                intentFilter2.addAction("android.intent.action.TIMEZONE_CHANGED");
                intentFilter2.addAction("android.intent.action.TIME_TICK");
                return intentFilter2;
        }
    }

    @Override // e.y
    public final int e() {
        Location location;
        boolean z2;
        long j2;
        switch (this.f1002c) {
            case 0:
                return s.a((PowerManager) this.f1004e) ? 2 : 1;
            default:
                C.h hVar = (C.h) this.f1004e;
                K k2 = (K) hVar.f7c;
                if (k2.b <= System.currentTimeMillis()) {
                    Context context = (Context) hVar.f6a;
                    int iE = D.g.e(context, "android.permission.ACCESS_COARSE_LOCATION");
                    Location lastKnownLocation = null;
                    LocationManager locationManager = (LocationManager) hVar.b;
                    if (iE == 0) {
                        try {
                        } catch (Exception e2) {
                            Log.d("TwilightManager", "Failed to get last known location", e2);
                        }
                        Location lastKnownLocation2 = locationManager.isProviderEnabled("network") ? locationManager.getLastKnownLocation("network") : null;
                        location = lastKnownLocation2;
                    } else {
                        location = null;
                    }
                    if (D.g.e(context, "android.permission.ACCESS_FINE_LOCATION") == 0) {
                        try {
                            if (locationManager.isProviderEnabled("gps")) {
                                lastKnownLocation = locationManager.getLastKnownLocation("gps");
                            }
                        } catch (Exception e3) {
                            Log.d("TwilightManager", "Failed to get last known location", e3);
                        }
                    }
                    if (lastKnownLocation == null || location == null ? lastKnownLocation != null : lastKnownLocation.getTime() > location.getTime()) {
                        location = lastKnownLocation;
                    }
                    if (location != null) {
                        long jCurrentTimeMillis = System.currentTimeMillis();
                        if (J.f907d == null) {
                            J.f907d = new J();
                        }
                        J j3 = J.f907d;
                        j3.a(jCurrentTimeMillis - 86400000, location.getLatitude(), location.getLongitude());
                        j3.a(jCurrentTimeMillis, location.getLatitude(), location.getLongitude());
                        z2 = j3.f909c == 1;
                        long j4 = j3.b;
                        long j5 = j3.f908a;
                        j3.a(86400000 + jCurrentTimeMillis, location.getLatitude(), location.getLongitude());
                        long j6 = j3.b;
                        if (j4 == -1 || j5 == -1) {
                            j2 = jCurrentTimeMillis + 43200000;
                        } else {
                            if (jCurrentTimeMillis <= j5) {
                                j6 = jCurrentTimeMillis > j4 ? j5 : j4;
                            }
                            j2 = j6 + 60000;
                        }
                        k2.f910a = z2;
                        k2.b = j2;
                    } else {
                        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
                        int i2 = Calendar.getInstance().get(11);
                        if (i2 < 6 || i2 >= 22) {
                            z2 = true;
                        }
                    }
                    break;
                } else {
                    z2 = k2.f910a;
                }
                return z2 ? 2 : 1;
        }
    }

    @Override // e.y
    public final void g() throws IllegalAccessException {
        switch (this.f1002c) {
            case 0:
                this.f1003d.n(true, true);
                break;
            default:
                this.f1003d.n(true, true);
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w(LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B, Context context) {
        super(layoutInflaterFactory2C0012B);
        this.f1003d = layoutInflaterFactory2C0012B;
        this.f1004e = (PowerManager) context.getApplicationContext().getSystemService("power");
    }
}
