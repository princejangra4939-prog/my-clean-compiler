package e;

import android.content.Context;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import i.C0069l;
import i.Z0;
import i.e1;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class I extends D.g {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final e1 f899o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final v f900p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final G f901q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f902r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f903s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f904t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final ArrayList f905u = new ArrayList();

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final D.b f906v = new D.b(5, this);

    public I(Toolbar toolbar, CharSequence charSequence, v vVar) {
        G g2 = new G(this);
        e1 e1Var = new e1(toolbar, false);
        this.f899o = e1Var;
        vVar.getClass();
        this.f900p = vVar;
        e1Var.f1347k = vVar;
        toolbar.setOnMenuItemClickListener(g2);
        if (!e1Var.f1343g) {
            e1Var.f1344h = charSequence;
            if ((e1Var.b & 8) != 0) {
                Toolbar toolbar2 = e1Var.f1339a;
                toolbar2.setTitle(charSequence);
                if (e1Var.f1343g) {
                    y.K.i(toolbar2.getRootView(), charSequence);
                }
            }
        }
        this.f901q = new G(this);
    }

    @Override // D.g
    public final Context D() {
        return this.f899o.f1339a.getContext();
    }

    @Override // D.g
    public final boolean F() {
        e1 e1Var = this.f899o;
        Toolbar toolbar = e1Var.f1339a;
        D.b bVar = this.f906v;
        toolbar.removeCallbacks(bVar);
        Toolbar toolbar2 = e1Var.f1339a;
        WeakHashMap weakHashMap = y.K.f1647a;
        toolbar2.postOnAnimation(bVar);
        return true;
    }

    @Override // D.g
    public final void L() {
        this.f899o.f1339a.removeCallbacks(this.f906v);
    }

    @Override // D.g
    public final boolean N(int i2, KeyEvent keyEvent) {
        Menu menuK0 = k0();
        if (menuK0 == null) {
            return false;
        }
        menuK0.setQwertyMode(KeyCharacterMap.load(keyEvent.getDeviceId()).getKeyboardType() != 1);
        return menuK0.performShortcut(i2, keyEvent, 0);
    }

    @Override // D.g
    public final boolean P(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 1) {
            R();
        }
        return true;
    }

    @Override // D.g
    public final boolean R() {
        return this.f899o.f1339a.u();
    }

    @Override // D.g
    public final boolean f() {
        C0069l c0069l;
        ActionMenuView actionMenuView = this.f899o.f1339a.f489a;
        return (actionMenuView == null || (c0069l = actionMenuView.f450t) == null || !c0069l.f()) ? false : true;
    }

    @Override // D.g
    public final void g0(CharSequence charSequence) {
        e1 e1Var = this.f899o;
        if (e1Var.f1343g) {
            return;
        }
        e1Var.f1344h = charSequence;
        if ((e1Var.b & 8) != 0) {
            Toolbar toolbar = e1Var.f1339a;
            toolbar.setTitle(charSequence);
            if (e1Var.f1343g) {
                y.K.i(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // D.g
    public final boolean h() {
        h.p pVar;
        Z0 z0 = this.f899o.f1339a.f481M;
        if (z0 == null || (pVar = z0.b) == null) {
            return false;
        }
        if (z0 == null) {
            pVar = null;
        }
        if (pVar == null) {
            return true;
        }
        pVar.collapseActionView();
        return true;
    }

    public final Menu k0() {
        boolean z2 = this.f903s;
        e1 e1Var = this.f899o;
        if (!z2) {
            H h2 = new H(this);
            G g2 = new G(this);
            Toolbar toolbar = e1Var.f1339a;
            toolbar.f482N = h2;
            toolbar.f483O = g2;
            ActionMenuView actionMenuView = toolbar.f489a;
            if (actionMenuView != null) {
                actionMenuView.f451u = h2;
                actionMenuView.f452v = g2;
            }
            this.f903s = true;
        }
        return e1Var.f1339a.getMenu();
    }

    @Override // D.g
    public final void r(boolean z2) {
        if (z2 == this.f904t) {
            return;
        }
        this.f904t = z2;
        ArrayList arrayList = this.f905u;
        if (arrayList.size() <= 0) {
            return;
        }
        arrayList.get(0).getClass();
        throw new ClassCastException();
    }

    @Override // D.g
    public final int u() {
        return this.f899o.b;
    }

    @Override // D.g
    public final void Z(boolean z2) {
    }

    @Override // D.g
    public final void e0(boolean z2) {
    }

    @Override // D.g
    public final void J() {
    }
}
