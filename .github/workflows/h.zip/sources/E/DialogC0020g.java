package e;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.app.AlertController$RecycleListView;
import androidx.core.widget.NestedScrollView;
import com.warppaiwarden.tictactoe.R;
import java.util.WeakHashMap;
import y.AbstractC0151B;
import y.InterfaceC0167k;

/* JADX INFO: renamed from: e.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class DialogC0020g extends Dialog implements DialogInterface, InterfaceC0023j, androidx.lifecycle.q, M.g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public androidx.lifecycle.s f974a;
    public final M.f b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final androidx.activity.v f975c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public LayoutInflaterFactory2C0012B f976d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C0013C f977e;
    public final C0018e f;

    /* JADX WARN: Type inference failed for: r2v4, types: [e.C] */
    public DialogC0020g(ContextThemeWrapper contextThemeWrapper, int i2) {
        int i3;
        int i4 = i(contextThemeWrapper, i2);
        if (i4 == 0) {
            TypedValue typedValue = new TypedValue();
            contextThemeWrapper.getTheme().resolveAttribute(R.attr.dialogTheme, typedValue, true);
            i3 = typedValue.resourceId;
        } else {
            i3 = i4;
        }
        super(contextThemeWrapper, i3);
        this.b = new M.f(this);
        this.f975c = new androidx.activity.v(new androidx.activity.d(2, this));
        this.f977e = new InterfaceC0167k() { // from class: e.C
            @Override // y.InterfaceC0167k
            public final boolean d(KeyEvent keyEvent) {
                return this.f889a.k(keyEvent);
            }
        };
        o oVarD = d();
        if (i4 == 0) {
            TypedValue typedValue2 = new TypedValue();
            contextThemeWrapper.getTheme().resolveAttribute(R.attr.dialogTheme, typedValue2, true);
            i4 = typedValue2.resourceId;
        }
        ((LayoutInflaterFactory2C0012B) oVarD).f859T = i4;
        oVarD.d();
        this.f = new C0018e(getContext(), this, getWindow());
    }

    public static void b(DialogC0020g dialogC0020g) {
        e0.c.e(dialogC0020g, "this$0");
        super.onBackPressed();
    }

    public static int i(Context context, int i2) {
        if (((i2 >>> 24) & 255) >= 1) {
            return i2;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.alertDialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    @Override // M.g
    public final M.e a() {
        return (M.e) this.b.f120c;
    }

    @Override // android.app.Dialog
    public final void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        e();
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) d();
        layoutInflaterFactory2C0012B.w();
        ((ViewGroup) layoutInflaterFactory2C0012B.f840A.findViewById(android.R.id.content)).addView(view, layoutParams);
        layoutInflaterFactory2C0012B.f875m.a(layoutInflaterFactory2C0012B.f874l.getCallback());
    }

    @Override // androidx.lifecycle.q
    public final androidx.lifecycle.s c() {
        androidx.lifecycle.s sVar = this.f974a;
        if (sVar != null) {
            return sVar;
        }
        androidx.lifecycle.s sVar2 = new androidx.lifecycle.s(this);
        this.f974a = sVar2;
        return sVar2;
    }

    public final o d() {
        if (this.f976d == null) {
            ExecutorC0026m executorC0026m = o.f988a;
            this.f976d = new LayoutInflaterFactory2C0012B(getContext(), getWindow(), this, this);
        }
        return this.f976d;
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public final void dismiss() {
        super.dismiss();
        d().e();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return D.g.q(this.f977e, getWindow().getDecorView(), this, keyEvent);
    }

    public final void e() {
        Window window = getWindow();
        e0.c.b(window);
        View decorView = window.getDecorView();
        e0.c.d(decorView, "window!!.decorView");
        decorView.setTag(R.id.view_tree_lifecycle_owner, this);
        Window window2 = getWindow();
        e0.c.b(window2);
        View decorView2 = window2.getDecorView();
        e0.c.d(decorView2, "window!!.decorView");
        decorView2.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        Window window3 = getWindow();
        e0.c.b(window3);
        View decorView3 = window3.getDecorView();
        e0.c.d(decorView3, "window!!.decorView");
        decorView3.setTag(R.id.view_tree_saved_state_registry_owner, this);
    }

    public final void f(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcher = getOnBackInvokedDispatcher();
            e0.c.d(onBackInvokedDispatcher, "onBackInvokedDispatcher");
            androidx.activity.v vVar = this.f975c;
            vVar.getClass();
            vVar.f361e = onBackInvokedDispatcher;
            vVar.b(vVar.f362g);
        }
        this.b.b(bundle);
        androidx.lifecycle.s sVar = this.f974a;
        if (sVar == null) {
            sVar = new androidx.lifecycle.s(this);
            this.f974a = sVar;
        }
        sVar.d(androidx.lifecycle.k.ON_CREATE);
    }

    @Override // android.app.Dialog
    public final View findViewById(int i2) {
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) d();
        layoutInflaterFactory2C0012B.w();
        return layoutInflaterFactory2C0012B.f874l.findViewById(i2);
    }

    public final void g(Bundle bundle) {
        d().a();
        f(bundle);
        d().d();
    }

    public final void h() {
        androidx.lifecycle.s sVar = this.f974a;
        if (sVar == null) {
            sVar = new androidx.lifecycle.s(this);
            this.f974a = sVar;
        }
        sVar.d(androidx.lifecycle.k.ON_DESTROY);
        this.f974a = null;
        super.onStop();
    }

    @Override // android.app.Dialog
    public final void invalidateOptionsMenu() {
        d().b();
    }

    public final void j(CharSequence charSequence) {
        super.setTitle(charSequence);
        d().m(charSequence);
    }

    public final boolean k(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    @Override // android.app.Dialog
    public final void onBackPressed() {
        this.f975c.a();
    }

    @Override // android.app.Dialog
    public final void onCreate(Bundle bundle) {
        int i2;
        ListAdapter listAdapter;
        View viewFindViewById;
        g(bundle);
        C0018e c0018e = this.f;
        c0018e.b.setContentView(c0018e.f966q);
        Window window = c0018e.f953c;
        View viewFindViewById2 = window.findViewById(R.id.parentPanel);
        View viewFindViewById3 = viewFindViewById2.findViewById(R.id.topPanel);
        View viewFindViewById4 = viewFindViewById2.findViewById(R.id.contentPanel);
        View viewFindViewById5 = viewFindViewById2.findViewById(R.id.buttonPanel);
        ViewGroup viewGroup = (ViewGroup) viewFindViewById2.findViewById(R.id.customPanel);
        window.setFlags(131072, 131072);
        viewGroup.setVisibility(8);
        View viewFindViewById6 = viewGroup.findViewById(R.id.topPanel);
        View viewFindViewById7 = viewGroup.findViewById(R.id.contentPanel);
        View viewFindViewById8 = viewGroup.findViewById(R.id.buttonPanel);
        ViewGroup viewGroupA = C0018e.a(viewFindViewById6, viewFindViewById3);
        ViewGroup viewGroupA2 = C0018e.a(viewFindViewById7, viewFindViewById4);
        ViewGroup viewGroupA3 = C0018e.a(viewFindViewById8, viewFindViewById5);
        NestedScrollView nestedScrollView = (NestedScrollView) window.findViewById(R.id.scrollView);
        c0018e.f958i = nestedScrollView;
        nestedScrollView.setFocusable(false);
        c0018e.f958i.setNestedScrollingEnabled(false);
        TextView textView = (TextView) viewGroupA2.findViewById(android.R.id.message);
        c0018e.f962m = textView;
        if (textView != null) {
            textView.setVisibility(8);
            c0018e.f958i.removeView(c0018e.f962m);
            if (c0018e.f955e != null) {
                ViewGroup viewGroup2 = (ViewGroup) c0018e.f958i.getParent();
                int iIndexOfChild = viewGroup2.indexOfChild(c0018e.f958i);
                viewGroup2.removeViewAt(iIndexOfChild);
                viewGroup2.addView(c0018e.f955e, iIndexOfChild, new ViewGroup.LayoutParams(-1, -1));
            } else {
                viewGroupA2.setVisibility(8);
            }
        }
        Button button = (Button) viewGroupA3.findViewById(android.R.id.button1);
        c0018e.f = button;
        W.c cVar = c0018e.f972w;
        button.setOnClickListener(cVar);
        if (TextUtils.isEmpty(null)) {
            c0018e.f.setVisibility(8);
            i2 = 0;
        } else {
            c0018e.f.setText((CharSequence) null);
            c0018e.f.setVisibility(0);
            i2 = 1;
        }
        Button button2 = (Button) viewGroupA3.findViewById(android.R.id.button2);
        c0018e.f956g = button2;
        button2.setOnClickListener(cVar);
        if (TextUtils.isEmpty(null)) {
            c0018e.f956g.setVisibility(8);
        } else {
            c0018e.f956g.setText((CharSequence) null);
            c0018e.f956g.setVisibility(0);
            i2 |= 2;
        }
        Button button3 = (Button) viewGroupA3.findViewById(android.R.id.button3);
        c0018e.f957h = button3;
        button3.setOnClickListener(cVar);
        if (TextUtils.isEmpty(null)) {
            c0018e.f957h.setVisibility(8);
        } else {
            c0018e.f957h.setText((CharSequence) null);
            c0018e.f957h.setVisibility(0);
            i2 |= 4;
        }
        TypedValue typedValue = new TypedValue();
        c0018e.f952a.getTheme().resolveAttribute(R.attr.alertDialogCenterButtons, typedValue, true);
        if (typedValue.data != 0) {
            if (i2 == 1) {
                Button button4 = c0018e.f;
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button4.getLayoutParams();
                layoutParams.gravity = 1;
                layoutParams.weight = 0.5f;
                button4.setLayoutParams(layoutParams);
            } else if (i2 == 2) {
                Button button5 = c0018e.f956g;
                LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) button5.getLayoutParams();
                layoutParams2.gravity = 1;
                layoutParams2.weight = 0.5f;
                button5.setLayoutParams(layoutParams2);
            } else if (i2 == 4) {
                Button button6 = c0018e.f957h;
                LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) button6.getLayoutParams();
                layoutParams3.gravity = 1;
                layoutParams3.weight = 0.5f;
                button6.setLayoutParams(layoutParams3);
            }
        }
        if (i2 == 0) {
            viewGroupA3.setVisibility(8);
        }
        if (c0018e.f963n != null) {
            viewGroupA.addView(c0018e.f963n, 0, new ViewGroup.LayoutParams(-1, -2));
            window.findViewById(R.id.title_template).setVisibility(8);
        } else {
            c0018e.f960k = (ImageView) window.findViewById(android.R.id.icon);
            if (TextUtils.isEmpty(c0018e.f954d) || !c0018e.f970u) {
                window.findViewById(R.id.title_template).setVisibility(8);
                c0018e.f960k.setVisibility(8);
                viewGroupA.setVisibility(8);
            } else {
                TextView textView2 = (TextView) window.findViewById(R.id.alertTitle);
                c0018e.f961l = textView2;
                textView2.setText(c0018e.f954d);
                Drawable drawable = c0018e.f959j;
                if (drawable != null) {
                    c0018e.f960k.setImageDrawable(drawable);
                } else {
                    c0018e.f961l.setPadding(c0018e.f960k.getPaddingLeft(), c0018e.f960k.getPaddingTop(), c0018e.f960k.getPaddingRight(), c0018e.f960k.getPaddingBottom());
                    c0018e.f960k.setVisibility(8);
                }
            }
        }
        boolean z2 = viewGroup.getVisibility() != 8;
        int i3 = (viewGroupA == null || viewGroupA.getVisibility() == 8) ? 0 : 1;
        boolean z3 = viewGroupA3.getVisibility() != 8;
        if (!z3 && (viewFindViewById = viewGroupA2.findViewById(R.id.textSpacerNoButtons)) != null) {
            viewFindViewById.setVisibility(0);
        }
        if (i3 != 0) {
            NestedScrollView nestedScrollView2 = c0018e.f958i;
            if (nestedScrollView2 != null) {
                nestedScrollView2.setClipToPadding(true);
            }
            View viewFindViewById9 = c0018e.f955e != null ? viewGroupA.findViewById(R.id.titleDividerNoCustom) : null;
            if (viewFindViewById9 != null) {
                viewFindViewById9.setVisibility(0);
            }
        } else {
            View viewFindViewById10 = viewGroupA2.findViewById(R.id.textSpacerNoTitle);
            if (viewFindViewById10 != null) {
                viewFindViewById10.setVisibility(0);
            }
        }
        AlertController$RecycleListView alertController$RecycleListView = c0018e.f955e;
        if (alertController$RecycleListView != null && (!z3 || i3 == 0)) {
            alertController$RecycleListView.setPadding(alertController$RecycleListView.getPaddingLeft(), i3 != 0 ? alertController$RecycleListView.getPaddingTop() : alertController$RecycleListView.f363a, alertController$RecycleListView.getPaddingRight(), z3 ? alertController$RecycleListView.getPaddingBottom() : alertController$RecycleListView.b);
        }
        if (!z2) {
            View view = c0018e.f955e;
            if (view == null) {
                view = c0018e.f958i;
            }
            if (view != null) {
                int i4 = (z3 ? 2 : 0) | i3;
                View viewFindViewById11 = window.findViewById(R.id.scrollIndicatorUp);
                View viewFindViewById12 = window.findViewById(R.id.scrollIndicatorDown);
                WeakHashMap weakHashMap = y.K.f1647a;
                AbstractC0151B.d(view, i4, 3);
                if (viewFindViewById11 != null) {
                    viewGroupA2.removeView(viewFindViewById11);
                }
                if (viewFindViewById12 != null) {
                    viewGroupA2.removeView(viewFindViewById12);
                }
            }
        }
        AlertController$RecycleListView alertController$RecycleListView2 = c0018e.f955e;
        if (alertController$RecycleListView2 == null || (listAdapter = c0018e.f964o) == null) {
            return;
        }
        alertController$RecycleListView2.setAdapter(listAdapter);
        int i5 = c0018e.f965p;
        if (i5 > -1) {
            alertController$RecycleListView2.setItemChecked(i5, true);
            alertController$RecycleListView2.setSelection(i5);
        }
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f.f958i;
        if (nestedScrollView == null || !nestedScrollView.j(keyEvent)) {
            return super.onKeyDown(i2, keyEvent);
        }
        return true;
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public final boolean onKeyUp(int i2, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.f.f958i;
        if (nestedScrollView == null || !nestedScrollView.j(keyEvent)) {
            return super.onKeyUp(i2, keyEvent);
        }
        return true;
    }

    @Override // android.app.Dialog
    public final Bundle onSaveInstanceState() {
        Bundle bundleOnSaveInstanceState = super.onSaveInstanceState();
        e0.c.d(bundleOnSaveInstanceState, "super.onSaveInstanceState()");
        this.b.c(bundleOnSaveInstanceState);
        return bundleOnSaveInstanceState;
    }

    @Override // android.app.Dialog
    public final void onStart() {
        super.onStart();
        androidx.lifecycle.s sVar = this.f974a;
        if (sVar == null) {
            sVar = new androidx.lifecycle.s(this);
            this.f974a = sVar;
        }
        sVar.d(androidx.lifecycle.k.ON_RESUME);
    }

    @Override // android.app.Dialog
    public final void onStop() {
        h();
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) d();
        layoutInflaterFactory2C0012B.A();
        D.g gVar = layoutInflaterFactory2C0012B.f877o;
        if (gVar != null) {
            gVar.e0(false);
        }
    }

    @Override // android.app.Dialog
    public final void setContentView(int i2) {
        e();
        d().j(i2);
    }

    @Override // android.app.Dialog
    public final void setTitle(int i2) {
        super.setTitle(i2);
        d().m(getContext().getString(i2));
    }

    @Override // android.app.Dialog
    public final void setContentView(View view) {
        e();
        d().k(view);
    }

    @Override // android.app.Dialog
    public final void setTitle(CharSequence charSequence) {
        j(charSequence);
        C0018e c0018e = this.f;
        c0018e.f954d = charSequence;
        TextView textView = c0018e.f961l;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    @Override // android.app.Dialog
    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        e();
        d().l(view, layoutParams);
    }
}
