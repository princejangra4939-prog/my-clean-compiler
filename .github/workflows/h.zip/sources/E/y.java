package e;

import android.content.Context;
import android.content.IntentFilter;
import android.view.MenuItem;
import l.C0111k;
import t.InterfaceMenuItemC0131a;

/* JADX INFO: loaded from: classes.dex */
public abstract class y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f1006a;
    public Object b;

    public y(Context context) {
        this.f1006a = context;
    }

    public void c() {
        x xVar = (x) this.f1006a;
        if (xVar != null) {
            try {
                ((LayoutInflaterFactory2C0012B) this.b).f873k.unregisterReceiver(xVar);
            } catch (IllegalArgumentException unused) {
            }
            this.f1006a = null;
        }
    }

    public abstract IntentFilter d();

    public abstract int e();

    public MenuItem f(MenuItem menuItem) {
        if (!(menuItem instanceof InterfaceMenuItemC0131a)) {
            return menuItem;
        }
        InterfaceMenuItemC0131a interfaceMenuItemC0131a = (InterfaceMenuItemC0131a) menuItem;
        if (((C0111k) this.b) == null) {
            this.b = new C0111k();
        }
        MenuItem menuItem2 = (MenuItem) ((C0111k) this.b).getOrDefault(interfaceMenuItemC0131a, null);
        if (menuItem2 != null) {
            return menuItem2;
        }
        h.u uVar = new h.u((Context) this.f1006a, interfaceMenuItemC0131a);
        ((C0111k) this.b).put(interfaceMenuItemC0131a, uVar);
        return uVar;
    }

    public abstract void g();

    public void h() {
        c();
        IntentFilter intentFilterD = d();
        if (intentFilterD.countActions() == 0) {
            return;
        }
        if (((x) this.f1006a) == null) {
            this.f1006a = new x(this);
        }
        ((LayoutInflaterFactory2C0012B) this.b).f873k.registerReceiver((x) this.f1006a, intentFilterD);
    }

    public y(LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B) {
        this.b = layoutInflaterFactory2C0012B;
    }
}
