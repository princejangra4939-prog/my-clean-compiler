package e;

import android.view.MenuItem;
import i.b1;

/* JADX INFO: loaded from: classes.dex */
public final class G implements b1, h.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ I f897a;

    public /* synthetic */ G(I i2) {
        this.f897a = i2;
    }

    @Override // h.l
    public void g(h.n nVar) {
        I i2 = this.f897a;
        boolean zO = i2.f899o.f1339a.o();
        v vVar = i2.f900p;
        if (zO) {
            vVar.onPanelClosed(108, nVar);
        } else if (vVar.onPreparePanel(0, null, nVar)) {
            vVar.onMenuOpened(108, nVar);
        }
    }

    @Override // h.l
    public boolean h(h.n nVar, MenuItem menuItem) {
        return false;
    }
}
