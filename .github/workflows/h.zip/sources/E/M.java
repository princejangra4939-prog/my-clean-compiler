package e;

import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import g.AbstractC0028a;
import g.C0035h;
import i.C0069l;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public final class M extends AbstractC0028a implements h.l {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Context f912c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final h.n f913d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public G.a f914e;
    public WeakReference f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ N f915g;

    public M(N n2, Context context, G.a aVar) {
        this.f915g = n2;
        this.f912c = context;
        this.f914e = aVar;
        h.n nVar = new h.n(context);
        nVar.f1150l = 1;
        this.f913d = nVar;
        nVar.f1144e = this;
    }

    @Override // g.AbstractC0028a
    public final void a() {
        N n2 = this.f915g;
        if (n2.f938w != this) {
            return;
        }
        if (n2.f921D) {
            n2.f939x = this;
            n2.f940y = this.f914e;
        } else {
            this.f914e.b(this);
        }
        this.f914e = null;
        n2.k0(false);
        ActionBarContextView actionBarContextView = n2.f935t;
        if (actionBarContextView.f406k == null) {
            actionBarContextView.e();
        }
        n2.f932q.setHideOnContentScrollEnabled(n2.f926I);
        n2.f938w = null;
    }

    @Override // g.AbstractC0028a
    public final View b() {
        WeakReference weakReference = this.f;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // g.AbstractC0028a
    public final h.n c() {
        return this.f913d;
    }

    @Override // g.AbstractC0028a
    public final MenuInflater d() {
        return new C0035h(this.f912c);
    }

    @Override // g.AbstractC0028a
    public final CharSequence e() {
        return this.f915g.f935t.getSubtitle();
    }

    @Override // g.AbstractC0028a
    public final CharSequence f() {
        return this.f915g.f935t.getTitle();
    }

    @Override // h.l
    public final void g(h.n nVar) {
        if (this.f914e == null) {
            return;
        }
        i();
        C0069l c0069l = this.f915g.f935t.f400d;
        if (c0069l != null) {
            c0069l.l();
        }
    }

    @Override // h.l
    public final boolean h(h.n nVar, MenuItem menuItem) {
        G.a aVar = this.f914e;
        if (aVar != null) {
            return ((T.t) aVar.f57a).f(this, menuItem);
        }
        return false;
    }

    @Override // g.AbstractC0028a
    public final void i() {
        if (this.f915g.f938w != this) {
            return;
        }
        h.n nVar = this.f913d;
        nVar.w();
        try {
            this.f914e.d(this, nVar);
        } finally {
            nVar.v();
        }
    }

    @Override // g.AbstractC0028a
    public final boolean j() {
        return this.f915g.f935t.f414s;
    }

    @Override // g.AbstractC0028a
    public final void k(View view) {
        this.f915g.f935t.setCustomView(view);
        this.f = new WeakReference(view);
    }

    @Override // g.AbstractC0028a
    public final void l(int i2) {
        m(this.f915g.f930o.getResources().getString(i2));
    }

    @Override // g.AbstractC0028a
    public final void m(CharSequence charSequence) {
        this.f915g.f935t.setSubtitle(charSequence);
    }

    @Override // g.AbstractC0028a
    public final void n(int i2) {
        o(this.f915g.f930o.getResources().getString(i2));
    }

    @Override // g.AbstractC0028a
    public final void o(CharSequence charSequence) {
        this.f915g.f935t.setTitle(charSequence);
    }

    @Override // g.AbstractC0028a
    public final void p(boolean z2) {
        this.b = z2;
        this.f915g.f935t.setTitleOptional(z2);
    }
}
