package e;

import android.app.Activity;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public abstract class u {
    public static OnBackInvokedDispatcher a(Activity activity) {
        return activity.getOnBackInvokedDispatcher();
    }

    public static OnBackInvokedCallback b(Object obj, LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B) {
        Objects.requireNonNull(layoutInflaterFactory2C0012B);
        androidx.activity.p pVar = new androidx.activity.p(1, layoutInflaterFactory2C0012B);
        androidx.activity.m.e(obj).registerOnBackInvokedCallback(1000000, pVar);
        return pVar;
    }

    public static void c(Object obj, Object obj2) {
        androidx.activity.m.e(obj).unregisterOnBackInvokedCallback(androidx.activity.m.b(obj2));
    }
}
