package e;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;

/* JADX INFO: renamed from: e.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0015b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ContextThemeWrapper f943a;
    public final LayoutInflater b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Drawable f944c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public CharSequence f945d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public View f946e;
    public h.o f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Object f947g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public DialogInterface.OnClickListener f948h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f949i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f950j = -1;

    public C0015b(ContextThemeWrapper contextThemeWrapper) {
        this.f943a = contextThemeWrapper;
        this.b = (LayoutInflater) contextThemeWrapper.getSystemService("layout_inflater");
    }
}
