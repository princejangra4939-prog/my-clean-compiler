package e;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.appcompat.widget.ContentFrameLayout;
import d.AbstractC0010a;
import g.AbstractC0028a;
import g.C0030c;
import g.C0035h;
import i.C0054d0;
import i.C0061h;
import i.C0066j0;
import i.C0069l;
import i.C0077p;
import i.C0082s;
import i.C0084t;
import i.C0088v;
import i.C0092x;
import i.C0096z;
import i.InterfaceC0070l0;
import i.S;
import i.e1;
import i.j1;
import i.m1;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.WeakHashMap;
import l.C0111k;
import u.AbstractC0133b;
import u.C0134c;
import u.C0135d;
import y.AbstractC0150A;
import y.C0178w;
import y.Q;

/* JADX INFO: renamed from: e.B, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class LayoutInflaterFactory2C0012B extends o implements h.l, LayoutInflater.Factory2 {

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public static final C0111k f838h0 = new C0111k();

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public static final int[] f839i0 = {R.attr.windowBackground};
    public static final boolean j0 = !"robolectric".equals(Build.FINGERPRINT);

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public ViewGroup f840A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public TextView f841B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public View f842C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public boolean f843D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f844E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public boolean f845F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public boolean f846G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public boolean f847H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f848I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public boolean f849J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public boolean f850K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public C0011A[] f851L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public C0011A f852M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public boolean f853N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public boolean f854O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public boolean f855P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public boolean f856Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public Configuration f857R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public final int f858S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public int f859T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public int f860U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public boolean f861V;

    /* JADX INFO: renamed from: W, reason: collision with root package name */
    public w f862W;

    /* JADX INFO: renamed from: X, reason: collision with root package name */
    public w f863X;

    /* JADX INFO: renamed from: Y, reason: collision with root package name */
    public boolean f864Y;

    /* JADX INFO: renamed from: Z, reason: collision with root package name */
    public int f865Z;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public boolean f867b0;
    public Rect c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public Rect f868d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public D f869e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public OnBackInvokedDispatcher f870f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public OnBackInvokedCallback f871g0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Object f872j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final Context f873k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Window f874l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public v f875m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Object f876n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public D.g f877o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public C0035h f878p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public CharSequence f879q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public InterfaceC0070l0 f880r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public q f881s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public q f882t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public AbstractC0028a f883u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public ActionBarContextView f884v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public PopupWindow f885w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public p f886x;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f888z;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public Q f887y = null;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final p f866a0 = new p(this, 0);

    public LayoutInflaterFactory2C0012B(Context context, Window window, InterfaceC0023j interfaceC0023j, Object obj) {
        AbstractActivityC0022i abstractActivityC0022i;
        this.f858S = -100;
        this.f873k = context;
        this.f876n = interfaceC0023j;
        this.f872j = obj;
        if (obj instanceof Dialog) {
            while (context != null) {
                if (!(context instanceof AbstractActivityC0022i)) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                } else {
                    abstractActivityC0022i = (AbstractActivityC0022i) context;
                    break;
                }
            }
            abstractActivityC0022i = null;
            if (abstractActivityC0022i != null) {
                this.f858S = ((LayoutInflaterFactory2C0012B) abstractActivityC0022i.i()).f858S;
            }
        }
        if (this.f858S == -100) {
            C0111k c0111k = f838h0;
            Integer num = (Integer) c0111k.getOrDefault(this.f872j.getClass().getName(), null);
            if (num != null) {
                this.f858S = num.intValue();
                c0111k.remove(this.f872j.getClass().getName());
            }
        }
        if (window != null) {
            o(window);
        }
        C0088v.c();
    }

    public static C0134c p(Context context) {
        C0134c c0134c;
        C0134c c0134c2;
        if (Build.VERSION.SDK_INT >= 33 || (c0134c = o.f989c) == null) {
            return null;
        }
        C0134c c0134cB = t.b(context.getApplicationContext().getResources().getConfiguration());
        C0135d c0135d = c0134c.f1622a;
        if (c0135d.f1623a.isEmpty()) {
            c0134c2 = C0134c.b;
        } else {
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            int i2 = 0;
            while (i2 < c0134cB.f1622a.f1623a.size() + c0135d.f1623a.size()) {
                Locale locale = i2 < c0135d.f1623a.size() ? c0135d.f1623a.get(i2) : c0134cB.f1622a.f1623a.get(i2 - c0135d.f1623a.size());
                if (locale != null) {
                    linkedHashSet.add(locale);
                }
                i2++;
            }
            c0134c2 = new C0134c(new C0135d(AbstractC0133b.a((Locale[]) linkedHashSet.toArray(new Locale[linkedHashSet.size()]))));
        }
        return c0134c2.f1622a.f1623a.isEmpty() ? c0134cB : c0134c2;
    }

    public static Configuration t(Context context, int i2, C0134c c0134c, Configuration configuration, boolean z2) {
        int i3 = i2 != 1 ? i2 != 2 ? z2 ? 0 : context.getApplicationContext().getResources().getConfiguration().uiMode & 48 : 32 : 16;
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i3 | (configuration2.uiMode & (-49));
        if (c0134c != null) {
            t.d(configuration2, c0134c);
        }
        return configuration2;
    }

    public final void A() {
        w();
        if (this.f845F && this.f877o == null) {
            Object obj = this.f872j;
            if (obj instanceof Activity) {
                this.f877o = new N((Activity) obj, this.f846G);
            } else if (obj instanceof Dialog) {
                this.f877o = new N((Dialog) obj);
            }
            D.g gVar = this.f877o;
            if (gVar != null) {
                gVar.Z(this.f867b0);
            }
        }
    }

    public final void B(int i2) {
        this.f865Z = (1 << i2) | this.f865Z;
        if (this.f864Y) {
            return;
        }
        View decorView = this.f874l.getDecorView();
        p pVar = this.f866a0;
        WeakHashMap weakHashMap = y.K.f1647a;
        decorView.postOnAnimation(pVar);
        this.f864Y = true;
    }

    public final int C(Context context, int i2) {
        if (i2 != -100) {
            if (i2 != -1) {
                if (i2 != 0) {
                    if (i2 != 1 && i2 != 2) {
                        if (i2 != 3) {
                            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                        }
                        if (this.f863X == null) {
                            this.f863X = new w(this, context);
                        }
                        return this.f863X.e();
                    }
                } else if (((UiModeManager) context.getApplicationContext().getSystemService("uimode")).getNightMode() != 0) {
                    return y(context).e();
                }
            }
            return i2;
        }
        return -1;
    }

    public final boolean D() {
        boolean z2 = this.f853N;
        this.f853N = false;
        C0011A c0011aZ = z(0);
        if (!c0011aZ.f834m) {
            AbstractC0028a abstractC0028a = this.f883u;
            if (abstractC0028a != null) {
                abstractC0028a.a();
                return true;
            }
            A();
            D.g gVar = this.f877o;
            if (gVar == null || !gVar.h()) {
                return false;
            }
        } else if (!z2) {
            s(c0011aZ, true);
            return true;
        }
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:87:0x0176, code lost:
    
        if (r3.f.getCount() > 0) goto L88;
     */
    /* JADX WARN: Removed duplicated region for block: B:100:0x01d3  */
    /* JADX WARN: Removed duplicated region for block: B:105:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void E(e.C0011A r18, android.view.KeyEvent r19) {
        /*
            Method dump skipped, instruction units count: 474
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: e.LayoutInflaterFactory2C0012B.E(e.A, android.view.KeyEvent):void");
    }

    public final boolean F(C0011A c0011a, int i2, KeyEvent keyEvent) {
        h.n nVar;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((c0011a.f832k || G(c0011a, keyEvent)) && (nVar = c0011a.f829h) != null) {
            return nVar.performShortcut(i2, keyEvent, 1);
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:62:0x00d8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean G(e.C0011A r13, android.view.KeyEvent r14) {
        /*
            Method dump skipped, instruction units count: 369
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: e.LayoutInflaterFactory2C0012B.G(e.A, android.view.KeyEvent):boolean");
    }

    public final void H() {
        if (this.f888z) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    public final void I() {
        OnBackInvokedCallback onBackInvokedCallback;
        if (Build.VERSION.SDK_INT >= 33) {
            boolean z2 = false;
            if (this.f870f0 != null && (z(0).f834m || this.f883u != null)) {
                z2 = true;
            }
            if (z2 && this.f871g0 == null) {
                this.f871g0 = u.b(this.f870f0, this);
            } else {
                if (z2 || (onBackInvokedCallback = this.f871g0) == null) {
                    return;
                }
                u.c(this.f870f0, onBackInvokedCallback);
                this.f871g0 = null;
            }
        }
    }

    @Override // e.o
    public final void a() {
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(this.f873k);
        if (layoutInflaterFrom.getFactory() == null) {
            layoutInflaterFrom.setFactory2(this);
        } else {
            if (layoutInflaterFrom.getFactory2() instanceof LayoutInflaterFactory2C0012B) {
                return;
            }
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    @Override // e.o
    public final void b() {
        if (this.f877o != null) {
            A();
            if (this.f877o.F()) {
                return;
            }
            B(0);
        }
    }

    @Override // e.o
    public final void d() throws IllegalAccessException {
        String strD;
        this.f854O = true;
        n(false, true);
        x();
        Object obj = this.f872j;
        if (obj instanceof Activity) {
            try {
                Activity activity = (Activity) obj;
                try {
                    strD = o.e.d(activity, activity.getComponentName());
                } catch (PackageManager.NameNotFoundException e2) {
                    throw new IllegalArgumentException(e2);
                }
            } catch (IllegalArgumentException unused) {
                strD = null;
            }
            if (strD != null) {
                D.g gVar = this.f877o;
                if (gVar == null) {
                    this.f867b0 = true;
                } else {
                    gVar.Z(true);
                }
            }
            synchronized (o.f993h) {
                o.f(this);
                o.f992g.add(new WeakReference(this));
            }
        }
        this.f857R = new Configuration(this.f873k.getResources().getConfiguration());
        this.f855P = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x004d  */
    @Override // e.o
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void e() {
        /*
            r3 = this;
            java.lang.Object r0 = r3.f872j
            boolean r0 = r0 instanceof android.app.Activity
            if (r0 == 0) goto L11
            java.lang.Object r0 = e.o.f993h
            monitor-enter(r0)
            e.o.f(r3)     // Catch: java.lang.Throwable -> Le
            monitor-exit(r0)     // Catch: java.lang.Throwable -> Le
            goto L11
        Le:
            r1 = move-exception
            monitor-exit(r0)     // Catch: java.lang.Throwable -> Le
            throw r1
        L11:
            boolean r0 = r3.f864Y
            if (r0 == 0) goto L20
            android.view.Window r0 = r3.f874l
            android.view.View r0 = r0.getDecorView()
            e.p r1 = r3.f866a0
            r0.removeCallbacks(r1)
        L20:
            r0 = 1
            r3.f856Q = r0
            int r0 = r3.f858S
            r1 = -100
            if (r0 == r1) goto L4d
            java.lang.Object r0 = r3.f872j
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L4d
            android.app.Activity r0 = (android.app.Activity) r0
            boolean r0 = r0.isChangingConfigurations()
            if (r0 == 0) goto L4d
            l.k r0 = e.LayoutInflaterFactory2C0012B.f838h0
            java.lang.Object r1 = r3.f872j
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            int r2 = r3.f858S
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r0.put(r1, r2)
            goto L5c
        L4d:
            l.k r0 = e.LayoutInflaterFactory2C0012B.f838h0
            java.lang.Object r1 = r3.f872j
            java.lang.Class r1 = r1.getClass()
            java.lang.String r1 = r1.getName()
            r0.remove(r1)
        L5c:
            D.g r0 = r3.f877o
            if (r0 == 0) goto L63
            r0.L()
        L63:
            e.w r0 = r3.f862W
            if (r0 == 0) goto L6a
            r0.c()
        L6a:
            e.w r0 = r3.f863X
            if (r0 == 0) goto L71
            r0.c()
        L71:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: e.LayoutInflaterFactory2C0012B.e():void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0048, code lost:
    
        if (r6.h() != false) goto L20;
     */
    @Override // h.l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void g(h.n r6) {
        /*
            Method dump skipped, instruction units count: 225
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: e.LayoutInflaterFactory2C0012B.g(h.n):void");
    }

    @Override // h.l
    public final boolean h(h.n nVar, MenuItem menuItem) {
        C0011A c0011a;
        Window.Callback callback = this.f874l.getCallback();
        if (callback != null && !this.f856Q) {
            h.n nVarK = nVar.k();
            C0011A[] c0011aArr = this.f851L;
            int length = c0011aArr != null ? c0011aArr.length : 0;
            int i2 = 0;
            while (true) {
                if (i2 < length) {
                    c0011a = c0011aArr[i2];
                    if (c0011a != null && c0011a.f829h == nVarK) {
                        break;
                    }
                    i2++;
                } else {
                    c0011a = null;
                    break;
                }
            }
            if (c0011a != null) {
                return callback.onMenuItemSelected(c0011a.f824a, menuItem);
            }
        }
        return false;
    }

    @Override // e.o
    public final boolean i(int i2) {
        if (i2 == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            i2 = 108;
        } else if (i2 == 9) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            i2 = 109;
        }
        if (this.f849J && i2 == 108) {
            return false;
        }
        if (this.f845F && i2 == 1) {
            this.f845F = false;
        }
        if (i2 == 1) {
            H();
            this.f849J = true;
            return true;
        }
        if (i2 == 2) {
            H();
            this.f843D = true;
            return true;
        }
        if (i2 == 5) {
            H();
            this.f844E = true;
            return true;
        }
        if (i2 == 10) {
            H();
            this.f847H = true;
            return true;
        }
        if (i2 == 108) {
            H();
            this.f845F = true;
            return true;
        }
        if (i2 != 109) {
            return this.f874l.requestFeature(i2);
        }
        H();
        this.f846G = true;
        return true;
    }

    @Override // e.o
    public final void j(int i2) {
        w();
        ViewGroup viewGroup = (ViewGroup) this.f840A.findViewById(R.id.content);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f873k).inflate(i2, viewGroup);
        this.f875m.a(this.f874l.getCallback());
    }

    @Override // e.o
    public final void k(View view) {
        w();
        ViewGroup viewGroup = (ViewGroup) this.f840A.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f875m.a(this.f874l.getCallback());
    }

    @Override // e.o
    public final void l(View view, ViewGroup.LayoutParams layoutParams) {
        w();
        ViewGroup viewGroup = (ViewGroup) this.f840A.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f875m.a(this.f874l.getCallback());
    }

    @Override // e.o
    public final void m(CharSequence charSequence) {
        this.f879q = charSequence;
        InterfaceC0070l0 interfaceC0070l0 = this.f880r;
        if (interfaceC0070l0 != null) {
            interfaceC0070l0.setWindowTitle(charSequence);
            return;
        }
        D.g gVar = this.f877o;
        if (gVar != null) {
            gVar.g0(charSequence);
            return;
        }
        TextView textView = this.f841B;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0194  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00fd  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean n(boolean r17, boolean r18) throws java.lang.IllegalAccessException {
        /*
            Method dump skipped, instruction units count: 622
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: e.LayoutInflaterFactory2C0012B.n(boolean, boolean):boolean");
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0074  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void o(android.view.Window r8) {
        /*
            r7 = this;
            android.view.Window r0 = r7.f874l
            java.lang.String r1 = "AppCompat has already installed itself into the Window"
            if (r0 != 0) goto L80
            android.view.Window$Callback r0 = r8.getCallback()
            boolean r2 = r0 instanceof e.v
            if (r2 != 0) goto L7a
            e.v r1 = new e.v
            r1.<init>(r7, r0)
            r7.f875m = r1
            r8.setCallback(r1)
            int[] r0 = e.LayoutInflaterFactory2C0012B.f839i0
            android.content.Context r1 = r7.f873k
            r2 = 0
            android.content.res.TypedArray r0 = r1.obtainStyledAttributes(r2, r0)
            r3 = 0
            boolean r4 = r0.hasValue(r3)
            if (r4 == 0) goto L3f
            int r3 = r0.getResourceId(r3, r3)
            if (r3 == 0) goto L3f
            i.v r4 = i.C0088v.a()
            monitor-enter(r4)
            i.N0 r5 = r4.f1450a     // Catch: java.lang.Throwable -> L3c
            r6 = 1
            android.graphics.drawable.Drawable r1 = r5.d(r1, r3, r6)     // Catch: java.lang.Throwable -> L3c
            monitor-exit(r4)
            goto L40
        L3c:
            r8 = move-exception
            monitor-exit(r4)     // Catch: java.lang.Throwable -> L3c
            throw r8
        L3f:
            r1 = r2
        L40:
            if (r1 == 0) goto L45
            r8.setBackgroundDrawable(r1)
        L45:
            r0.recycle()
            r7.f874l = r8
            int r8 = android.os.Build.VERSION.SDK_INT
            r0 = 33
            if (r8 < r0) goto L79
            android.window.OnBackInvokedDispatcher r8 = r7.f870f0
            if (r8 != 0) goto L79
            if (r8 == 0) goto L5f
            android.window.OnBackInvokedCallback r0 = r7.f871g0
            if (r0 == 0) goto L5f
            e.u.c(r8, r0)
            r7.f871g0 = r2
        L5f:
            java.lang.Object r8 = r7.f872j
            boolean r0 = r8 instanceof android.app.Activity
            if (r0 == 0) goto L74
            android.app.Activity r8 = (android.app.Activity) r8
            android.view.Window r0 = r8.getWindow()
            if (r0 == 0) goto L74
            android.window.OnBackInvokedDispatcher r8 = e.u.a(r8)
            r7.f870f0 = r8
            goto L76
        L74:
            r7.f870f0 = r2
        L76:
            r7.I()
        L79:
            return
        L7a:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            r8.<init>(r1)
            throw r8
        L80:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            r8.<init>(r1)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: e.LayoutInflaterFactory2C0012B.o(android.view.Window):void");
    }

    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        Context c0030c;
        View appCompatRatingBar;
        String attributeValue = str;
        View view2 = null;
        if (this.f869e0 == null) {
            int[] iArr = AbstractC0010a.f807j;
            Context context2 = this.f873k;
            TypedArray typedArrayObtainStyledAttributes = context2.obtainStyledAttributes(iArr);
            String string = typedArrayObtainStyledAttributes.getString(116);
            typedArrayObtainStyledAttributes.recycle();
            if (string == null) {
                this.f869e0 = new D();
            } else {
                try {
                    this.f869e0 = (D) context2.getClassLoader().loadClass(string).getDeclaredConstructor(null).newInstance(null);
                } catch (Throwable th) {
                    Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + string + ". Falling back to default.", th);
                    this.f869e0 = new D();
                }
            }
        }
        D d2 = this.f869e0;
        int i2 = j1.f1385a;
        d2.getClass();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, AbstractC0010a.f821x, 0, 0);
        int resourceId = typedArrayObtainStyledAttributes2.getResourceId(4, 0);
        if (resourceId != 0) {
            Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
        }
        typedArrayObtainStyledAttributes2.recycle();
        c0030c = (resourceId == 0 || ((context instanceof C0030c) && ((C0030c) context).f1013a == resourceId)) ? context : new C0030c(context, resourceId);
        attributeValue.getClass();
        switch (attributeValue) {
            case "RatingBar":
                appCompatRatingBar = new AppCompatRatingBar(c0030c, attributeSet);
                break;
            case "CheckedTextView":
                appCompatRatingBar = new C0084t(c0030c, attributeSet);
                break;
            case "MultiAutoCompleteTextView":
                appCompatRatingBar = new i.C(c0030c, attributeSet);
                break;
            case "TextView":
                appCompatRatingBar = new C0054d0(c0030c, attributeSet);
                break;
            case "ImageButton":
                appCompatRatingBar = new C0096z(c0030c, attributeSet, com.warppaiwarden.tictactoe.R.attr.imageButtonStyle);
                break;
            case "SeekBar":
                appCompatRatingBar = new i.H(c0030c, attributeSet);
                break;
            case "Spinner":
                appCompatRatingBar = new S(c0030c, attributeSet);
                break;
            case "RadioButton":
                appCompatRatingBar = new i.F(c0030c, attributeSet);
                break;
            case "ToggleButton":
                appCompatRatingBar = new C0066j0(c0030c, attributeSet);
                break;
            case "ImageView":
                appCompatRatingBar = new i.B(c0030c, attributeSet, 0);
                break;
            case "AutoCompleteTextView":
                appCompatRatingBar = new C0077p(c0030c, attributeSet);
                break;
            case "CheckBox":
                appCompatRatingBar = new C0082s(c0030c, attributeSet);
                break;
            case "EditText":
                appCompatRatingBar = new C0092x(c0030c, attributeSet);
                break;
            case "Button":
                appCompatRatingBar = new i.r(c0030c, attributeSet);
                break;
            default:
                appCompatRatingBar = null;
                break;
        }
        if (appCompatRatingBar == null && context != c0030c) {
            Object[] objArr = d2.f895a;
            if (attributeValue.equals("view")) {
                attributeValue = attributeSet.getAttributeValue(null, "class");
            }
            try {
                objArr[0] = c0030c;
                objArr[1] = attributeSet;
                if (-1 == attributeValue.indexOf(46)) {
                    int i3 = 0;
                    while (true) {
                        String[] strArr = D.f893g;
                        if (i3 < 3) {
                            View viewA = d2.a(c0030c, attributeValue, strArr[i3]);
                            if (viewA != null) {
                                objArr[0] = null;
                                objArr[1] = null;
                                view2 = viewA;
                            } else {
                                i3++;
                            }
                        }
                    }
                } else {
                    View viewA2 = d2.a(c0030c, attributeValue, null);
                    objArr[0] = null;
                    objArr[1] = null;
                    view2 = viewA2;
                }
            } catch (Exception unused) {
            } finally {
                objArr[0] = null;
                objArr[1] = null;
            }
            appCompatRatingBar = view2;
        }
        if (appCompatRatingBar != null) {
            Context context3 = appCompatRatingBar.getContext();
            if ((context3 instanceof ContextWrapper) && appCompatRatingBar.hasOnClickListeners()) {
                TypedArray typedArrayObtainStyledAttributes3 = context3.obtainStyledAttributes(attributeSet, D.f890c);
                String string2 = typedArrayObtainStyledAttributes3.getString(0);
                if (string2 != null) {
                    appCompatRatingBar.setOnClickListener(new W.h(appCompatRatingBar, string2));
                }
                typedArrayObtainStyledAttributes3.recycle();
            }
            if (Build.VERSION.SDK_INT <= 28) {
                TypedArray typedArrayObtainStyledAttributes4 = c0030c.obtainStyledAttributes(attributeSet, D.f891d);
                if (typedArrayObtainStyledAttributes4.hasValue(0)) {
                    boolean z2 = typedArrayObtainStyledAttributes4.getBoolean(0, false);
                    WeakHashMap weakHashMap = y.K.f1647a;
                    new C0178w(com.warppaiwarden.tictactoe.R.id.tag_accessibility_heading, Boolean.class, 0, 28, 2).d(appCompatRatingBar, Boolean.valueOf(z2));
                }
                typedArrayObtainStyledAttributes4.recycle();
                TypedArray typedArrayObtainStyledAttributes5 = c0030c.obtainStyledAttributes(attributeSet, D.f892e);
                if (typedArrayObtainStyledAttributes5.hasValue(0)) {
                    y.K.i(appCompatRatingBar, typedArrayObtainStyledAttributes5.getString(0));
                }
                typedArrayObtainStyledAttributes5.recycle();
                TypedArray typedArrayObtainStyledAttributes6 = c0030c.obtainStyledAttributes(attributeSet, D.f);
                if (typedArrayObtainStyledAttributes6.hasValue(0)) {
                    boolean z3 = typedArrayObtainStyledAttributes6.getBoolean(0, false);
                    WeakHashMap weakHashMap2 = y.K.f1647a;
                    new C0178w(com.warppaiwarden.tictactoe.R.id.tag_screen_reader_focusable, Boolean.class, 0, 28, 0).d(appCompatRatingBar, Boolean.valueOf(z3));
                }
                typedArrayObtainStyledAttributes6.recycle();
            }
        }
        return appCompatRatingBar;
    }

    public final void q(int i2, C0011A c0011a, h.n nVar) {
        if (nVar == null) {
            if (c0011a == null && i2 >= 0) {
                C0011A[] c0011aArr = this.f851L;
                if (i2 < c0011aArr.length) {
                    c0011a = c0011aArr[i2];
                }
            }
            if (c0011a != null) {
                nVar = c0011a.f829h;
            }
        }
        if ((c0011a == null || c0011a.f834m) && !this.f856Q) {
            v vVar = this.f875m;
            Window.Callback callback = this.f874l.getCallback();
            vVar.getClass();
            try {
                vVar.f1001e = true;
                callback.onPanelClosed(i2, nVar);
            } finally {
                vVar.f1001e = false;
            }
        }
    }

    public final void r(h.n nVar) {
        C0069l c0069l;
        if (this.f850K) {
            return;
        }
        this.f850K = true;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) this.f880r;
        actionBarOverlayLayout.k();
        ActionMenuView actionMenuView = ((e1) actionBarOverlayLayout.f424e).f1339a.f489a;
        if (actionMenuView != null && (c0069l = actionMenuView.f450t) != null) {
            c0069l.f();
            C0061h c0061h = c0069l.f1404t;
            if (c0061h != null && c0061h.b()) {
                c0061h.f1207i.dismiss();
            }
        }
        Window.Callback callback = this.f874l.getCallback();
        if (callback != null && !this.f856Q) {
            callback.onPanelClosed(108, nVar);
        }
        this.f850K = false;
    }

    public final void s(C0011A c0011a, boolean z2) {
        z zVar;
        InterfaceC0070l0 interfaceC0070l0;
        if (z2 && c0011a.f824a == 0 && (interfaceC0070l0 = this.f880r) != null) {
            ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC0070l0;
            actionBarOverlayLayout.k();
            if (((e1) actionBarOverlayLayout.f424e).f1339a.o()) {
                r(c0011a.f829h);
                return;
            }
        }
        WindowManager windowManager = (WindowManager) this.f873k.getSystemService("window");
        if (windowManager != null && c0011a.f834m && (zVar = c0011a.f827e) != null) {
            windowManager.removeView(zVar);
            if (z2) {
                q(c0011a.f824a, c0011a, null);
            }
        }
        c0011a.f832k = false;
        c0011a.f833l = false;
        c0011a.f834m = false;
        c0011a.f = null;
        c0011a.f835n = true;
        if (this.f852M == c0011a) {
            this.f852M = null;
        }
        if (c0011a.f824a == 0) {
            I();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x003f  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x00f3  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x011b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean u(android.view.KeyEvent r7) {
        /*
            Method dump skipped, instruction units count: 317
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: e.LayoutInflaterFactory2C0012B.u(android.view.KeyEvent):boolean");
    }

    public final void v(int i2) {
        C0011A c0011aZ = z(i2);
        if (c0011aZ.f829h != null) {
            Bundle bundle = new Bundle();
            c0011aZ.f829h.t(bundle);
            if (bundle.size() > 0) {
                c0011aZ.f837p = bundle;
            }
            c0011aZ.f829h.w();
            c0011aZ.f829h.clear();
        }
        c0011aZ.f836o = true;
        c0011aZ.f835n = true;
        if ((i2 == 108 || i2 == 0) && this.f880r != null) {
            C0011A c0011aZ2 = z(0);
            c0011aZ2.f832k = false;
            G(c0011aZ2, null);
        }
    }

    public final void w() {
        ViewGroup viewGroup;
        int i2 = 1;
        int i3 = 0;
        if (this.f888z) {
            return;
        }
        int[] iArr = AbstractC0010a.f807j;
        Context context = this.f873k;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(iArr);
        if (!typedArrayObtainStyledAttributes.hasValue(117)) {
            typedArrayObtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
        if (typedArrayObtainStyledAttributes.getBoolean(126, false)) {
            i(1);
        } else if (typedArrayObtainStyledAttributes.getBoolean(117, false)) {
            i(108);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(118, false)) {
            i(109);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(119, false)) {
            i(10);
        }
        this.f848I = typedArrayObtainStyledAttributes.getBoolean(0, false);
        typedArrayObtainStyledAttributes.recycle();
        x();
        this.f874l.getDecorView();
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(context);
        if (this.f849J) {
            viewGroup = this.f847H ? (ViewGroup) layoutInflaterFrom.inflate(com.warppaiwarden.tictactoe.R.layout.abc_screen_simple_overlay_action_mode, (ViewGroup) null) : (ViewGroup) layoutInflaterFrom.inflate(com.warppaiwarden.tictactoe.R.layout.abc_screen_simple, (ViewGroup) null);
        } else if (this.f848I) {
            viewGroup = (ViewGroup) layoutInflaterFrom.inflate(com.warppaiwarden.tictactoe.R.layout.abc_dialog_title_material, (ViewGroup) null);
            this.f846G = false;
            this.f845F = false;
        } else if (this.f845F) {
            TypedValue typedValue = new TypedValue();
            context.getTheme().resolveAttribute(com.warppaiwarden.tictactoe.R.attr.actionBarTheme, typedValue, true);
            viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new C0030c(context, typedValue.resourceId) : context).inflate(com.warppaiwarden.tictactoe.R.layout.abc_screen_toolbar, (ViewGroup) null);
            InterfaceC0070l0 interfaceC0070l0 = (InterfaceC0070l0) viewGroup.findViewById(com.warppaiwarden.tictactoe.R.id.decor_content_parent);
            this.f880r = interfaceC0070l0;
            interfaceC0070l0.setWindowCallback(this.f874l.getCallback());
            if (this.f846G) {
                ((ActionBarOverlayLayout) this.f880r).j(109);
            }
            if (this.f843D) {
                ((ActionBarOverlayLayout) this.f880r).j(2);
            }
            if (this.f844E) {
                ((ActionBarOverlayLayout) this.f880r).j(5);
            }
        } else {
            viewGroup = null;
        }
        if (viewGroup == null) {
            throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.f845F + ", windowActionBarOverlay: " + this.f846G + ", android:windowIsFloating: " + this.f848I + ", windowActionModeOverlay: " + this.f847H + ", windowNoTitle: " + this.f849J + " }");
        }
        q qVar = new q(this, i3);
        WeakHashMap weakHashMap = y.K.f1647a;
        AbstractC0150A.u(viewGroup, qVar);
        if (this.f880r == null) {
            this.f841B = (TextView) viewGroup.findViewById(com.warppaiwarden.tictactoe.R.id.title);
        }
        boolean z2 = m1.f1408a;
        try {
            Method method = viewGroup.getClass().getMethod("makeOptionalFitsSystemWindows", null);
            if (!method.isAccessible()) {
                method.setAccessible(true);
            }
            method.invoke(viewGroup, null);
        } catch (IllegalAccessException e2) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e2);
        } catch (NoSuchMethodException unused) {
            Log.d("ViewUtils", "Could not find method makeOptionalFitsSystemWindows. Oh well...");
        } catch (InvocationTargetException e3) {
            Log.d("ViewUtils", "Could not invoke makeOptionalFitsSystemWindows", e3);
        }
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(com.warppaiwarden.tictactoe.R.id.action_bar_activity_content);
        ViewGroup viewGroup2 = (ViewGroup) this.f874l.findViewById(R.id.content);
        if (viewGroup2 != null) {
            while (viewGroup2.getChildCount() > 0) {
                View childAt = viewGroup2.getChildAt(0);
                viewGroup2.removeViewAt(0);
                contentFrameLayout.addView(childAt);
            }
            viewGroup2.setId(-1);
            contentFrameLayout.setId(R.id.content);
            if (viewGroup2 instanceof FrameLayout) {
                ((FrameLayout) viewGroup2).setForeground(null);
            }
        }
        this.f874l.setContentView(viewGroup);
        contentFrameLayout.setAttachListener(new q(this, i2));
        this.f840A = viewGroup;
        Object obj = this.f872j;
        CharSequence title = obj instanceof Activity ? ((Activity) obj).getTitle() : this.f879q;
        if (!TextUtils.isEmpty(title)) {
            InterfaceC0070l0 interfaceC0070l02 = this.f880r;
            if (interfaceC0070l02 != null) {
                interfaceC0070l02.setWindowTitle(title);
            } else {
                D.g gVar = this.f877o;
                if (gVar != null) {
                    gVar.g0(title);
                } else {
                    TextView textView = this.f841B;
                    if (textView != null) {
                        textView.setText(title);
                    }
                }
            }
        }
        ContentFrameLayout contentFrameLayout2 = (ContentFrameLayout) this.f840A.findViewById(R.id.content);
        View decorView = this.f874l.getDecorView();
        contentFrameLayout2.f465g.set(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        if (contentFrameLayout2.isLaidOut()) {
            contentFrameLayout2.requestLayout();
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(iArr);
        typedArrayObtainStyledAttributes2.getValue(124, contentFrameLayout2.getMinWidthMajor());
        typedArrayObtainStyledAttributes2.getValue(125, contentFrameLayout2.getMinWidthMinor());
        if (typedArrayObtainStyledAttributes2.hasValue(122)) {
            typedArrayObtainStyledAttributes2.getValue(122, contentFrameLayout2.getFixedWidthMajor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(123)) {
            typedArrayObtainStyledAttributes2.getValue(123, contentFrameLayout2.getFixedWidthMinor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(120)) {
            typedArrayObtainStyledAttributes2.getValue(120, contentFrameLayout2.getFixedHeightMajor());
        }
        if (typedArrayObtainStyledAttributes2.hasValue(121)) {
            typedArrayObtainStyledAttributes2.getValue(121, contentFrameLayout2.getFixedHeightMinor());
        }
        typedArrayObtainStyledAttributes2.recycle();
        contentFrameLayout2.requestLayout();
        this.f888z = true;
        C0011A c0011aZ = z(0);
        if (this.f856Q || c0011aZ.f829h != null) {
            return;
        }
        B(108);
    }

    public final void x() {
        if (this.f874l == null) {
            Object obj = this.f872j;
            if (obj instanceof Activity) {
                o(((Activity) obj).getWindow());
            }
        }
        if (this.f874l == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    public final y y(Context context) {
        if (this.f862W == null) {
            if (C.h.f5d == null) {
                Context applicationContext = context.getApplicationContext();
                C.h.f5d = new C.h(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
            }
            this.f862W = new w(this, C.h.f5d);
        }
        return this.f862W;
    }

    public final C0011A z(int i2) {
        C0011A[] c0011aArr = this.f851L;
        if (c0011aArr == null || c0011aArr.length <= i2) {
            C0011A[] c0011aArr2 = new C0011A[i2 + 1];
            if (c0011aArr != null) {
                System.arraycopy(c0011aArr, 0, c0011aArr2, 0, c0011aArr.length);
            }
            this.f851L = c0011aArr2;
            c0011aArr = c0011aArr2;
        }
        C0011A c0011a = c0011aArr[i2];
        if (c0011a != null) {
            return c0011a;
        }
        C0011A c0011a2 = new C0011A();
        c0011a2.f824a = i2;
        c0011a2.f835n = false;
        c0011aArr[i2] = c0011a2;
        return c0011a2;
    }

    @Override // android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }
}
