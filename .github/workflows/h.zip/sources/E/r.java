package e;

import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import java.util.WeakHashMap;
import y.AbstractC0180y;

/* JADX INFO: loaded from: classes.dex */
public final class r extends z.i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f997a;
    public final /* synthetic */ Object b;

    public /* synthetic */ r(int i2, Object obj) {
        this.f997a = i2;
        this.b = obj;
    }

    @Override // y.S
    public final void a() {
        Object obj = this.b;
        switch (this.f997a) {
            case 0:
                LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = ((p) obj).b;
                layoutInflaterFactory2C0012B.f884v.setAlpha(1.0f);
                layoutInflaterFactory2C0012B.f887y.d(null);
                layoutInflaterFactory2C0012B.f887y = null;
                break;
            case 1:
                LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B2 = (LayoutInflaterFactory2C0012B) obj;
                layoutInflaterFactory2C0012B2.f884v.setAlpha(1.0f);
                layoutInflaterFactory2C0012B2.f887y.d(null);
                layoutInflaterFactory2C0012B2.f887y = null;
                break;
            default:
                G.a aVar = (G.a) obj;
                ((LayoutInflaterFactory2C0012B) aVar.b).f884v.setVisibility(8);
                LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B3 = (LayoutInflaterFactory2C0012B) aVar.b;
                PopupWindow popupWindow = layoutInflaterFactory2C0012B3.f885w;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (layoutInflaterFactory2C0012B3.f884v.getParent() instanceof View) {
                    View view = (View) layoutInflaterFactory2C0012B3.f884v.getParent();
                    WeakHashMap weakHashMap = y.K.f1647a;
                    AbstractC0180y.c(view);
                }
                layoutInflaterFactory2C0012B3.f884v.e();
                layoutInflaterFactory2C0012B3.f887y.d(null);
                layoutInflaterFactory2C0012B3.f887y = null;
                ViewGroup viewGroup = layoutInflaterFactory2C0012B3.f840A;
                WeakHashMap weakHashMap2 = y.K.f1647a;
                AbstractC0180y.c(viewGroup);
                break;
        }
    }

    @Override // z.i, y.S
    public void c() {
        Object obj = this.b;
        switch (this.f997a) {
            case 0:
                ((p) obj).b.f884v.setVisibility(0);
                break;
            case 1:
                LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = (LayoutInflaterFactory2C0012B) obj;
                layoutInflaterFactory2C0012B.f884v.setVisibility(0);
                if (layoutInflaterFactory2C0012B.f884v.getParent() instanceof View) {
                    View view = (View) layoutInflaterFactory2C0012B.f884v.getParent();
                    WeakHashMap weakHashMap = y.K.f1647a;
                    AbstractC0180y.c(view);
                }
                break;
        }
    }
}
