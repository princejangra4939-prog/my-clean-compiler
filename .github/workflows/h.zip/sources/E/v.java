package e;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SearchEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.PopupWindow;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ViewStubCompat;
import com.warppaiwarden.tictactoe.R;
import g.AbstractC0028a;
import g.AbstractC0038k;
import g.C0030c;
import g.C0031d;
import java.util.List;
import java.util.WeakHashMap;
import y.AbstractC0180y;
import y.Q;

/* JADX INFO: loaded from: classes.dex */
public final class v implements Window.Callback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Window.Callback f998a;
    public G b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f999c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1000d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1001e;
    public final /* synthetic */ LayoutInflaterFactory2C0012B f;

    public v(LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B, Window.Callback callback) {
        this.f = layoutInflaterFactory2C0012B;
        if (callback == null) {
            throw new IllegalArgumentException("Window callback may not be null");
        }
        this.f998a = callback;
    }

    public final void a(Window.Callback callback) {
        try {
            this.f999c = true;
            callback.onContentChanged();
        } finally {
            this.f999c = false;
        }
    }

    public final boolean b(int i2, Menu menu) {
        return this.f998a.onMenuOpened(i2, menu);
    }

    public final void c(int i2, Menu menu) {
        this.f998a.onPanelClosed(i2, menu);
    }

    public final void d(List list, Menu menu, int i2) {
        g.l.a(this.f998a, list, menu, i2);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        return this.f998a.dispatchGenericMotionEvent(motionEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean z2 = this.f1000d;
        Window.Callback callback = this.f998a;
        return z2 ? callback.dispatchKeyEvent(keyEvent) : this.f.u(keyEvent) || callback.dispatchKeyEvent(keyEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        if (!this.f998a.dispatchKeyShortcutEvent(keyEvent)) {
            int keyCode = keyEvent.getKeyCode();
            LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = this.f;
            layoutInflaterFactory2C0012B.A();
            D.g gVar = layoutInflaterFactory2C0012B.f877o;
            if (gVar == null || !gVar.N(keyCode, keyEvent)) {
                C0011A c0011a = layoutInflaterFactory2C0012B.f852M;
                if (c0011a == null || !layoutInflaterFactory2C0012B.F(c0011a, keyEvent.getKeyCode(), keyEvent)) {
                    if (layoutInflaterFactory2C0012B.f852M == null) {
                        C0011A c0011aZ = layoutInflaterFactory2C0012B.z(0);
                        layoutInflaterFactory2C0012B.G(c0011aZ, keyEvent);
                        boolean zF = layoutInflaterFactory2C0012B.F(c0011aZ, keyEvent.getKeyCode(), keyEvent);
                        c0011aZ.f832k = false;
                        if (zF) {
                        }
                    }
                    return false;
                }
                C0011A c0011a2 = layoutInflaterFactory2C0012B.f852M;
                if (c0011a2 != null) {
                    c0011a2.f833l = true;
                    return true;
                }
            }
        }
        return true;
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return this.f998a.dispatchPopulateAccessibilityEvent(accessibilityEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        return this.f998a.dispatchTouchEvent(motionEvent);
    }

    @Override // android.view.Window.Callback
    public final boolean dispatchTrackballEvent(MotionEvent motionEvent) {
        return this.f998a.dispatchTrackballEvent(motionEvent);
    }

    @Override // android.view.Window.Callback
    public final void onActionModeFinished(ActionMode actionMode) {
        this.f998a.onActionModeFinished(actionMode);
    }

    @Override // android.view.Window.Callback
    public final void onActionModeStarted(ActionMode actionMode) {
        this.f998a.onActionModeStarted(actionMode);
    }

    @Override // android.view.Window.Callback
    public final void onAttachedToWindow() {
        this.f998a.onAttachedToWindow();
    }

    @Override // android.view.Window.Callback
    public final void onContentChanged() {
        if (this.f999c) {
            this.f998a.onContentChanged();
        }
    }

    @Override // android.view.Window.Callback
    public final boolean onCreatePanelMenu(int i2, Menu menu) {
        if (i2 != 0 || (menu instanceof h.n)) {
            return this.f998a.onCreatePanelMenu(i2, menu);
        }
        return false;
    }

    @Override // android.view.Window.Callback
    public final View onCreatePanelView(int i2) {
        G g2 = this.b;
        if (g2 != null) {
            View view = i2 == 0 ? new View(g2.f897a.f899o.f1339a.getContext()) : null;
            if (view != null) {
                return view;
            }
        }
        return this.f998a.onCreatePanelView(i2);
    }

    @Override // android.view.Window.Callback
    public final void onDetachedFromWindow() {
        this.f998a.onDetachedFromWindow();
    }

    @Override // android.view.Window.Callback
    public final boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        return this.f998a.onMenuItemSelected(i2, menuItem);
    }

    @Override // android.view.Window.Callback
    public final boolean onMenuOpened(int i2, Menu menu) {
        b(i2, menu);
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = this.f;
        if (i2 == 108) {
            layoutInflaterFactory2C0012B.A();
            D.g gVar = layoutInflaterFactory2C0012B.f877o;
            if (gVar != null) {
                gVar.r(true);
            }
        } else {
            layoutInflaterFactory2C0012B.getClass();
        }
        return true;
    }

    @Override // android.view.Window.Callback
    public final void onPanelClosed(int i2, Menu menu) {
        if (this.f1001e) {
            this.f998a.onPanelClosed(i2, menu);
            return;
        }
        c(i2, menu);
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = this.f;
        if (i2 == 108) {
            layoutInflaterFactory2C0012B.A();
            D.g gVar = layoutInflaterFactory2C0012B.f877o;
            if (gVar != null) {
                gVar.r(false);
                return;
            }
            return;
        }
        if (i2 != 0) {
            layoutInflaterFactory2C0012B.getClass();
            return;
        }
        C0011A c0011aZ = layoutInflaterFactory2C0012B.z(i2);
        if (c0011aZ.f834m) {
            layoutInflaterFactory2C0012B.s(c0011aZ, false);
        }
    }

    @Override // android.view.Window.Callback
    public final void onPointerCaptureChanged(boolean z2) {
        g.m.a(this.f998a, z2);
    }

    @Override // android.view.Window.Callback
    public final boolean onPreparePanel(int i2, View view, Menu menu) {
        h.n nVar = menu instanceof h.n ? (h.n) menu : null;
        if (i2 == 0 && nVar == null) {
            return false;
        }
        if (nVar != null) {
            nVar.f1162x = true;
        }
        G g2 = this.b;
        if (g2 != null && i2 == 0) {
            I i3 = g2.f897a;
            if (!i3.f902r) {
                i3.f899o.f1348l = true;
                i3.f902r = true;
            }
        }
        boolean zOnPreparePanel = this.f998a.onPreparePanel(i2, view, menu);
        if (nVar != null) {
            nVar.f1162x = false;
        }
        return zOnPreparePanel;
    }

    @Override // android.view.Window.Callback
    public final void onProvideKeyboardShortcuts(List list, Menu menu, int i2) {
        h.n nVar = this.f.z(0).f829h;
        if (nVar != null) {
            d(list, nVar, i2);
        } else {
            d(list, menu, i2);
        }
    }

    @Override // android.view.Window.Callback
    public final boolean onSearchRequested(SearchEvent searchEvent) {
        return AbstractC0038k.a(this.f998a, searchEvent);
    }

    @Override // android.view.Window.Callback
    public final void onWindowAttributesChanged(WindowManager.LayoutParams layoutParams) {
        this.f998a.onWindowAttributesChanged(layoutParams);
    }

    @Override // android.view.Window.Callback
    public final void onWindowFocusChanged(boolean z2) {
        this.f998a.onWindowFocusChanged(z2);
    }

    @Override // android.view.Window.Callback
    public final ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i2) {
        ViewGroup viewGroup;
        boolean z2 = false;
        int i3 = 1;
        LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = this.f;
        layoutInflaterFactory2C0012B.getClass();
        if (i2 != 0) {
            return AbstractC0038k.b(this.f998a, callback, i2);
        }
        T.t tVar = new T.t(layoutInflaterFactory2C0012B.f873k, callback);
        AbstractC0028a abstractC0028a = layoutInflaterFactory2C0012B.f883u;
        if (abstractC0028a != null) {
            abstractC0028a.a();
        }
        G.a aVar = new G.a(layoutInflaterFactory2C0012B, tVar, z2);
        layoutInflaterFactory2C0012B.A();
        D.g gVar = layoutInflaterFactory2C0012B.f877o;
        if (gVar != null) {
            layoutInflaterFactory2C0012B.f883u = gVar.h0(aVar);
        }
        if (layoutInflaterFactory2C0012B.f883u == null) {
            Q q2 = layoutInflaterFactory2C0012B.f887y;
            if (q2 != null) {
                q2.b();
            }
            AbstractC0028a abstractC0028a2 = layoutInflaterFactory2C0012B.f883u;
            if (abstractC0028a2 != null) {
                abstractC0028a2.a();
            }
            if (layoutInflaterFactory2C0012B.f884v == null) {
                boolean z3 = layoutInflaterFactory2C0012B.f848I;
                Context context = layoutInflaterFactory2C0012B.f873k;
                if (z3) {
                    TypedValue typedValue = new TypedValue();
                    Resources.Theme theme = context.getTheme();
                    theme.resolveAttribute(R.attr.actionBarTheme, typedValue, true);
                    if (typedValue.resourceId != 0) {
                        Resources.Theme themeNewTheme = context.getResources().newTheme();
                        themeNewTheme.setTo(theme);
                        themeNewTheme.applyStyle(typedValue.resourceId, true);
                        C0030c c0030c = new C0030c(context, 0);
                        c0030c.getTheme().setTo(themeNewTheme);
                        context = c0030c;
                    }
                    layoutInflaterFactory2C0012B.f884v = new ActionBarContextView(context, null);
                    PopupWindow popupWindow = new PopupWindow(context, (AttributeSet) null, R.attr.actionModePopupWindowStyle);
                    layoutInflaterFactory2C0012B.f885w = popupWindow;
                    D.o.d(popupWindow, 2);
                    layoutInflaterFactory2C0012B.f885w.setContentView(layoutInflaterFactory2C0012B.f884v);
                    layoutInflaterFactory2C0012B.f885w.setWidth(-1);
                    context.getTheme().resolveAttribute(R.attr.actionBarSize, typedValue, true);
                    layoutInflaterFactory2C0012B.f884v.setContentHeight(TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics()));
                    layoutInflaterFactory2C0012B.f885w.setHeight(-2);
                    layoutInflaterFactory2C0012B.f886x = new p(layoutInflaterFactory2C0012B, i3);
                } else {
                    ViewStubCompat viewStubCompat = (ViewStubCompat) layoutInflaterFactory2C0012B.f840A.findViewById(R.id.action_mode_bar_stub);
                    if (viewStubCompat != null) {
                        layoutInflaterFactory2C0012B.A();
                        D.g gVar2 = layoutInflaterFactory2C0012B.f877o;
                        Context contextD = gVar2 != null ? gVar2.D() : null;
                        if (contextD != null) {
                            context = contextD;
                        }
                        viewStubCompat.setLayoutInflater(LayoutInflater.from(context));
                        layoutInflaterFactory2C0012B.f884v = (ActionBarContextView) viewStubCompat.a();
                    }
                }
            }
            if (layoutInflaterFactory2C0012B.f884v != null) {
                Q q3 = layoutInflaterFactory2C0012B.f887y;
                if (q3 != null) {
                    q3.b();
                }
                layoutInflaterFactory2C0012B.f884v.e();
                Context context2 = layoutInflaterFactory2C0012B.f884v.getContext();
                ActionBarContextView actionBarContextView = layoutInflaterFactory2C0012B.f884v;
                C0031d c0031d = new C0031d();
                c0031d.f1017c = context2;
                c0031d.f1018d = actionBarContextView;
                c0031d.f1019e = aVar;
                h.n nVar = new h.n(actionBarContextView.getContext());
                nVar.f1150l = 1;
                c0031d.f1021h = nVar;
                nVar.f1144e = c0031d;
                if (((T.t) aVar.f57a).g(c0031d, nVar)) {
                    c0031d.i();
                    layoutInflaterFactory2C0012B.f884v.c(c0031d);
                    layoutInflaterFactory2C0012B.f883u = c0031d;
                    if (layoutInflaterFactory2C0012B.f888z && (viewGroup = layoutInflaterFactory2C0012B.f840A) != null && viewGroup.isLaidOut()) {
                        layoutInflaterFactory2C0012B.f884v.setAlpha(0.0f);
                        Q qA = y.K.a(layoutInflaterFactory2C0012B.f884v);
                        qA.a(1.0f);
                        layoutInflaterFactory2C0012B.f887y = qA;
                        qA.d(new r(i3, layoutInflaterFactory2C0012B));
                    } else {
                        layoutInflaterFactory2C0012B.f884v.setAlpha(1.0f);
                        layoutInflaterFactory2C0012B.f884v.setVisibility(0);
                        if (layoutInflaterFactory2C0012B.f884v.getParent() instanceof View) {
                            View view = (View) layoutInflaterFactory2C0012B.f884v.getParent();
                            WeakHashMap weakHashMap = y.K.f1647a;
                            AbstractC0180y.c(view);
                        }
                    }
                    if (layoutInflaterFactory2C0012B.f885w != null) {
                        layoutInflaterFactory2C0012B.f874l.getDecorView().post(layoutInflaterFactory2C0012B.f886x);
                    }
                } else {
                    layoutInflaterFactory2C0012B.f883u = null;
                }
            }
            layoutInflaterFactory2C0012B.I();
            layoutInflaterFactory2C0012B.f883u = layoutInflaterFactory2C0012B.f883u;
        }
        layoutInflaterFactory2C0012B.I();
        AbstractC0028a abstractC0028a3 = layoutInflaterFactory2C0012B.f883u;
        if (abstractC0028a3 != null) {
            return tVar.b(abstractC0028a3);
        }
        return null;
    }

    @Override // android.view.Window.Callback
    public final boolean onSearchRequested() {
        return this.f998a.onSearchRequested();
    }

    @Override // android.view.Window.Callback
    public final ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
        return null;
    }
}
