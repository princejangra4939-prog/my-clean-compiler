package e;

import android.R;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import d.AbstractC0010a;
import g.AbstractC0028a;
import g.C0036i;
import g.C0037j;
import i.InterfaceC0055e;
import i.InterfaceC0072m0;
import i.Z0;
import i.e1;
import java.util.ArrayList;
import java.util.WeakHashMap;
import y.AbstractC0150A;
import y.AbstractC0180y;
import y.Q;

/* JADX INFO: loaded from: classes.dex */
public final class N extends D.g implements InterfaceC0055e {

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public static final AccelerateInterpolator f916M = new AccelerateInterpolator();

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public static final DecelerateInterpolator f917N = new DecelerateInterpolator();

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final ArrayList f918A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f919B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f920C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public boolean f921D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f922E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public boolean f923F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public C0037j f924G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public boolean f925H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f926I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final L f927J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final L f928K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final C.j f929L;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public Context f930o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public Context f931p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public ActionBarOverlayLayout f932q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public ActionBarContainer f933r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public InterfaceC0072m0 f934s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public ActionBarContextView f935t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final View f936u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f937v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public M f938w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public M f939x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public G.a f940y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f941z;

    public N(Activity activity, boolean z2) {
        new ArrayList();
        this.f918A = new ArrayList();
        this.f919B = 0;
        this.f920C = true;
        this.f923F = true;
        this.f927J = new L(this, 0);
        this.f928K = new L(this, 1);
        this.f929L = new C.j(14, this);
        View decorView = activity.getWindow().getDecorView();
        l0(decorView);
        if (z2) {
            return;
        }
        this.f936u = decorView.findViewById(R.id.content);
    }

    @Override // D.g
    public final Context D() {
        if (this.f931p == null) {
            TypedValue typedValue = new TypedValue();
            this.f930o.getTheme().resolveAttribute(com.warppaiwarden.tictactoe.R.attr.actionBarWidgetTheme, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 != 0) {
                this.f931p = new ContextThemeWrapper(this.f930o, i2);
            } else {
                this.f931p = this.f930o;
            }
        }
        return this.f931p;
    }

    @Override // D.g
    public final void J() {
        m0(this.f930o.getResources().getBoolean(com.warppaiwarden.tictactoe.R.bool.abc_action_bar_embed_tabs));
    }

    @Override // D.g
    public final boolean N(int i2, KeyEvent keyEvent) {
        h.n nVar;
        M m2 = this.f938w;
        if (m2 == null || (nVar = m2.f913d) == null) {
            return false;
        }
        nVar.setQwertyMode(KeyCharacterMap.load(keyEvent.getDeviceId()).getKeyboardType() != 1);
        return nVar.performShortcut(i2, keyEvent, 0);
    }

    @Override // D.g
    public final void Z(boolean z2) {
        if (this.f937v) {
            return;
        }
        int i2 = z2 ? 4 : 0;
        e1 e1Var = (e1) this.f934s;
        int i3 = e1Var.b;
        this.f937v = true;
        e1Var.a((i2 & 4) | (i3 & (-5)));
    }

    @Override // D.g
    public final void e0(boolean z2) {
        C0037j c0037j;
        this.f925H = z2;
        if (z2 || (c0037j = this.f924G) == null) {
            return;
        }
        c0037j.a();
    }

    @Override // D.g
    public final void g0(CharSequence charSequence) {
        e1 e1Var = (e1) this.f934s;
        if (e1Var.f1343g) {
            return;
        }
        e1Var.f1344h = charSequence;
        if ((e1Var.b & 8) != 0) {
            Toolbar toolbar = e1Var.f1339a;
            toolbar.setTitle(charSequence);
            if (e1Var.f1343g) {
                y.K.i(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // D.g
    public final boolean h() {
        Z0 z0;
        InterfaceC0072m0 interfaceC0072m0 = this.f934s;
        if (interfaceC0072m0 == null || (z0 = ((e1) interfaceC0072m0).f1339a.f481M) == null || z0.b == null) {
            return false;
        }
        Z0 z02 = ((e1) interfaceC0072m0).f1339a.f481M;
        h.p pVar = z02 == null ? null : z02.b;
        if (pVar == null) {
            return true;
        }
        pVar.collapseActionView();
        return true;
    }

    @Override // D.g
    public final AbstractC0028a h0(G.a aVar) {
        M m2 = this.f938w;
        if (m2 != null) {
            m2.a();
        }
        this.f932q.setHideOnContentScrollEnabled(false);
        this.f935t.e();
        M m3 = new M(this, this.f935t.getContext(), aVar);
        h.n nVar = m3.f913d;
        nVar.w();
        try {
            if (!((T.t) m3.f914e.f57a).g(m3, nVar)) {
                return null;
            }
            this.f938w = m3;
            m3.i();
            this.f935t.c(m3);
            k0(true);
            return m3;
        } finally {
            nVar.v();
        }
    }

    public final void k0(boolean z2) {
        Q qI;
        Q qI2;
        if (z2) {
            if (!this.f922E) {
                this.f922E = true;
                ActionBarOverlayLayout actionBarOverlayLayout = this.f932q;
                if (actionBarOverlayLayout != null) {
                    actionBarOverlayLayout.setShowingForActionMode(true);
                }
                n0(false);
            }
        } else if (this.f922E) {
            this.f922E = false;
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f932q;
            if (actionBarOverlayLayout2 != null) {
                actionBarOverlayLayout2.setShowingForActionMode(false);
            }
            n0(false);
        }
        if (!this.f933r.isLaidOut()) {
            if (z2) {
                ((e1) this.f934s).f1339a.setVisibility(4);
                this.f935t.setVisibility(0);
                return;
            } else {
                ((e1) this.f934s).f1339a.setVisibility(0);
                this.f935t.setVisibility(8);
                return;
            }
        }
        if (z2) {
            e1 e1Var = (e1) this.f934s;
            qI = y.K.a(e1Var.f1339a);
            qI.a(0.0f);
            qI.c(100L);
            qI.d(new C0036i(e1Var, 4));
            qI2 = this.f935t.i(0, 200L);
        } else {
            e1 e1Var2 = (e1) this.f934s;
            Q qA = y.K.a(e1Var2.f1339a);
            qA.a(1.0f);
            qA.c(200L);
            qA.d(new C0036i(e1Var2, 0));
            qI = this.f935t.i(8, 100L);
            qI2 = qA;
        }
        C0037j c0037j = new C0037j();
        ArrayList arrayList = c0037j.f1061a;
        arrayList.add(qI);
        View view = (View) qI.f1653a.get();
        long duration = view != null ? view.animate().getDuration() : 0L;
        View view2 = (View) qI2.f1653a.get();
        if (view2 != null) {
            view2.animate().setStartDelay(duration);
        }
        arrayList.add(qI2);
        c0037j.b();
    }

    public final void l0(View view) {
        InterfaceC0072m0 wrapper;
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(com.warppaiwarden.tictactoe.R.id.decor_content_parent);
        this.f932q = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        KeyEvent.Callback callbackFindViewById = view.findViewById(com.warppaiwarden.tictactoe.R.id.action_bar);
        if (callbackFindViewById instanceof InterfaceC0072m0) {
            wrapper = (InterfaceC0072m0) callbackFindViewById;
        } else {
            if (!(callbackFindViewById instanceof Toolbar)) {
                throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById != null ? callbackFindViewById.getClass().getSimpleName() : "null"));
            }
            wrapper = ((Toolbar) callbackFindViewById).getWrapper();
        }
        this.f934s = wrapper;
        this.f935t = (ActionBarContextView) view.findViewById(com.warppaiwarden.tictactoe.R.id.action_context_bar);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(com.warppaiwarden.tictactoe.R.id.action_bar_container);
        this.f933r = actionBarContainer;
        InterfaceC0072m0 interfaceC0072m0 = this.f934s;
        if (interfaceC0072m0 == null || this.f935t == null || actionBarContainer == null) {
            throw new IllegalStateException(N.class.getSimpleName().concat(" can only be used with a compatible window decor layout"));
        }
        Context context = ((e1) interfaceC0072m0).f1339a.getContext();
        this.f930o = context;
        if ((((e1) this.f934s).b & 4) != 0) {
            this.f937v = true;
        }
        int i2 = context.getApplicationInfo().targetSdkVersion;
        this.f934s.getClass();
        m0(context.getResources().getBoolean(com.warppaiwarden.tictactoe.R.bool.abc_action_bar_embed_tabs));
        TypedArray typedArrayObtainStyledAttributes = this.f930o.obtainStyledAttributes(null, AbstractC0010a.f800a, com.warppaiwarden.tictactoe.R.attr.actionBarStyle, 0);
        if (typedArrayObtainStyledAttributes.getBoolean(14, false)) {
            ActionBarOverlayLayout actionBarOverlayLayout2 = this.f932q;
            if (!actionBarOverlayLayout2.f425g) {
                throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
            }
            this.f926I = true;
            actionBarOverlayLayout2.setHideOnContentScrollEnabled(true);
        }
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(12, 0);
        if (dimensionPixelSize != 0) {
            ActionBarContainer actionBarContainer2 = this.f933r;
            WeakHashMap weakHashMap = y.K.f1647a;
            AbstractC0150A.s(actionBarContainer2, dimensionPixelSize);
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    public final void m0(boolean z2) {
        if (z2) {
            this.f933r.setTabContainer(null);
            ((e1) this.f934s).getClass();
        } else {
            ((e1) this.f934s).getClass();
            this.f933r.setTabContainer(null);
        }
        this.f934s.getClass();
        ((e1) this.f934s).f1339a.setCollapsible(false);
        this.f932q.setHasNonEmbeddedTabs(false);
    }

    public final void n0(boolean z2) {
        boolean z3 = this.f922E || !this.f921D;
        View view = this.f936u;
        final C.j jVar = this.f929L;
        if (!z3) {
            if (this.f923F) {
                this.f923F = false;
                C0037j c0037j = this.f924G;
                if (c0037j != null) {
                    c0037j.a();
                }
                int i2 = this.f919B;
                L l2 = this.f927J;
                if (i2 != 0 || (!this.f925H && !z2)) {
                    l2.a();
                    return;
                }
                this.f933r.setAlpha(1.0f);
                this.f933r.setTransitioning(true);
                C0037j c0037j2 = new C0037j();
                float f = -this.f933r.getHeight();
                if (z2) {
                    this.f933r.getLocationInWindow(new int[]{0, 0});
                    f -= r12[1];
                }
                Q qA = y.K.a(this.f933r);
                qA.e(f);
                final View view2 = (View) qA.f1653a.get();
                if (view2 != null) {
                    view2.animate().setUpdateListener(jVar != null ? new ValueAnimator.AnimatorUpdateListener(view2) { // from class: y.P
                        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                        public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                            ((View) ((e.N) this.f1652a.b).f933r.getParent()).invalidate();
                        }
                    } : null);
                }
                boolean z4 = c0037j2.f1064e;
                ArrayList arrayList = c0037j2.f1061a;
                if (!z4) {
                    arrayList.add(qA);
                }
                if (this.f920C && view != null) {
                    Q qA2 = y.K.a(view);
                    qA2.e(f);
                    if (!c0037j2.f1064e) {
                        arrayList.add(qA2);
                    }
                }
                AccelerateInterpolator accelerateInterpolator = f916M;
                boolean z5 = c0037j2.f1064e;
                if (!z5) {
                    c0037j2.f1062c = accelerateInterpolator;
                }
                if (!z5) {
                    c0037j2.b = 250L;
                }
                if (!z5) {
                    c0037j2.f1063d = l2;
                }
                this.f924G = c0037j2;
                c0037j2.b();
                return;
            }
            return;
        }
        if (this.f923F) {
            return;
        }
        this.f923F = true;
        C0037j c0037j3 = this.f924G;
        if (c0037j3 != null) {
            c0037j3.a();
        }
        this.f933r.setVisibility(0);
        int i3 = this.f919B;
        L l3 = this.f928K;
        if (i3 == 0 && (this.f925H || z2)) {
            this.f933r.setTranslationY(0.0f);
            float f2 = -this.f933r.getHeight();
            if (z2) {
                this.f933r.getLocationInWindow(new int[]{0, 0});
                f2 -= r12[1];
            }
            this.f933r.setTranslationY(f2);
            C0037j c0037j4 = new C0037j();
            Q qA3 = y.K.a(this.f933r);
            qA3.e(0.0f);
            final View view3 = (View) qA3.f1653a.get();
            if (view3 != null) {
                view3.animate().setUpdateListener(jVar != null ? new ValueAnimator.AnimatorUpdateListener(view3) { // from class: y.P
                    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                        ((View) ((e.N) this.f1652a.b).f933r.getParent()).invalidate();
                    }
                } : null);
            }
            boolean z6 = c0037j4.f1064e;
            ArrayList arrayList2 = c0037j4.f1061a;
            if (!z6) {
                arrayList2.add(qA3);
            }
            if (this.f920C && view != null) {
                view.setTranslationY(f2);
                Q qA4 = y.K.a(view);
                qA4.e(0.0f);
                if (!c0037j4.f1064e) {
                    arrayList2.add(qA4);
                }
            }
            DecelerateInterpolator decelerateInterpolator = f917N;
            boolean z7 = c0037j4.f1064e;
            if (!z7) {
                c0037j4.f1062c = decelerateInterpolator;
            }
            if (!z7) {
                c0037j4.b = 250L;
            }
            if (!z7) {
                c0037j4.f1063d = l3;
            }
            this.f924G = c0037j4;
            c0037j4.b();
        } else {
            this.f933r.setAlpha(1.0f);
            this.f933r.setTranslationY(0.0f);
            if (this.f920C && view != null) {
                view.setTranslationY(0.0f);
            }
            l3.a();
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f932q;
        if (actionBarOverlayLayout != null) {
            WeakHashMap weakHashMap = y.K.f1647a;
            AbstractC0180y.c(actionBarOverlayLayout);
        }
    }

    @Override // D.g
    public final void r(boolean z2) {
        if (z2 == this.f941z) {
            return;
        }
        this.f941z = z2;
        ArrayList arrayList = this.f918A;
        if (arrayList.size() <= 0) {
            return;
        }
        arrayList.get(0).getClass();
        throw new ClassCastException();
    }

    @Override // D.g
    public final int u() {
        return ((e1) this.f934s).b;
    }

    public N(Dialog dialog) {
        new ArrayList();
        this.f918A = new ArrayList();
        this.f919B = 0;
        this.f920C = true;
        this.f923F = true;
        this.f927J = new L(this, 0);
        this.f928K = new L(this, 1);
        this.f929L = new C.j(14, this);
        l0(dialog.getWindow().getDecorView());
    }
}
