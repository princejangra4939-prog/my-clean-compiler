package L;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.profileinstaller.ProfileInstallerInitializer;
import e.ExecutorC0026m;
import i.U;
import java.util.Random;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class h implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f102a;
    public final /* synthetic */ Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f103c;

    public /* synthetic */ h(Object obj, int i2, Object obj2) {
        this.f102a = i2;
        this.b = obj;
        this.f103c = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f102a) {
            case 0:
                ((ProfileInstallerInitializer) this.b).getClass();
                (Build.VERSION.SDK_INT >= 28 ? l.a(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new i((Context) this.f103c, 0), new Random().nextInt(Math.max(1000, 1)) + 5000);
                return;
            case 1:
                Runnable runnable = (Runnable) this.f103c;
                ExecutorC0026m executorC0026m = (ExecutorC0026m) this.b;
                executorC0026m.getClass();
                try {
                    runnable.run();
                    return;
                } finally {
                    executorC0026m.a();
                }
            default:
                ((U) this.b).b((Typeface) this.f103c);
                return;
        }
    }
}
