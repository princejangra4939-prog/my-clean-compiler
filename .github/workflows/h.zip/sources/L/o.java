package L;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import java.io.File;
import java.io.IOException;
import m.AbstractFutureC0119g;

/* JADX INFO: loaded from: classes.dex */
public abstract class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final m.h f109a = new m.h();
    public static final Object b = new Object();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static F.d f110c = null;

    public static long a(Context context) {
        PackageManager packageManager = context.getApplicationContext().getPackageManager();
        return Build.VERSION.SDK_INT >= 33 ? m.a(packageManager, context).lastUpdateTime : packageManager.getPackageInfo(context.getPackageName(), 0).lastUpdateTime;
    }

    public static F.d b() {
        F.d dVar = new F.d(7);
        f110c = dVar;
        m.h hVar = f109a;
        hVar.getClass();
        if (AbstractFutureC0119g.f.b(hVar, null, dVar)) {
            AbstractFutureC0119g.b(hVar);
        }
        return f110c;
    }

    public static void c(Context context, boolean z2) {
        n nVarA;
        int i2;
        if (z2 || f110c == null) {
            synchronized (b) {
                if (!z2) {
                    try {
                        if (f110c != null) {
                            return;
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                int i3 = Build.VERSION.SDK_INT;
                if (i3 >= 28 && i3 != 30) {
                    File file = new File(new File("/data/misc/profiles/ref/", context.getPackageName()), "primary.prof");
                    long length = file.length();
                    int i4 = 0;
                    boolean z3 = file.exists() && length > 0;
                    File file2 = new File(new File("/data/misc/profiles/cur/0/", context.getPackageName()), "primary.prof");
                    long length2 = file2.length();
                    boolean z4 = file2.exists() && length2 > 0;
                    try {
                        long jA = a(context);
                        File file3 = new File(context.getFilesDir(), "profileInstalled");
                        if (file3.exists()) {
                            try {
                                nVarA = n.a(file3);
                            } catch (IOException unused) {
                                b();
                                return;
                            }
                        } else {
                            nVarA = null;
                        }
                        if (nVarA != null && nVarA.f107c == jA && (i2 = nVarA.b) != 2) {
                            i4 = i2;
                        } else if (z3) {
                            i4 = 1;
                        } else if (z4) {
                            i4 = 2;
                        }
                        if (z2 && z4 && i4 != 1) {
                            i4 = 2;
                        }
                        if (nVarA != null && nVarA.b == 2 && i4 == 1 && length < nVarA.f108d) {
                            i4 = 3;
                        }
                        n nVar = new n(1, i4, jA, length2);
                        if (nVarA == null || !nVarA.equals(nVar)) {
                            try {
                                nVar.b(file3);
                            } catch (IOException unused2) {
                            }
                        }
                        b();
                        return;
                    } catch (PackageManager.NameNotFoundException unused3) {
                        b();
                        return;
                    }
                }
                b();
            }
        }
    }
}
