package l;

import java.util.Collection;
import java.util.Iterator;

/* JADX INFO: renamed from: l.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0110j implements Collection {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0101a f1525a;

    public C0110j(C0101a c0101a) {
        this.f1525a = c0101a;
    }

    @Override // java.util.Collection
    public final boolean add(Object obj) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Collection
    public final boolean addAll(Collection collection) {
        throw new UnsupportedOperationException();
    }

    @Override // java.util.Collection
    public final void clear() {
        this.f1525a.a();
    }

    @Override // java.util.Collection
    public final boolean contains(Object obj) {
        return this.f1525a.f(obj) >= 0;
    }

    @Override // java.util.Collection
    public final boolean containsAll(Collection collection) {
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            if (!contains(it.next())) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.Collection
    public final boolean isEmpty() {
        return this.f1525a.d() == 0;
    }

    @Override // java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        return new C0107g(this.f1525a, 1);
    }

    @Override // java.util.Collection
    public final boolean remove(Object obj) {
        C0101a c0101a = this.f1525a;
        int iF = c0101a.f(obj);
        if (iF < 0) {
            return false;
        }
        c0101a.g(iF);
        return true;
    }

    @Override // java.util.Collection
    public final boolean removeAll(Collection collection) {
        C0101a c0101a = this.f1525a;
        int iD = c0101a.d();
        int i2 = 0;
        boolean z2 = false;
        while (i2 < iD) {
            if (collection.contains(c0101a.b(i2, 1))) {
                c0101a.g(i2);
                i2--;
                iD--;
                z2 = true;
            }
            i2++;
        }
        return z2;
    }

    @Override // java.util.Collection
    public final boolean retainAll(Collection collection) {
        C0101a c0101a = this.f1525a;
        int iD = c0101a.d();
        int i2 = 0;
        boolean z2 = false;
        while (i2 < iD) {
            if (!collection.contains(c0101a.b(i2, 1))) {
                c0101a.g(i2);
                i2--;
                iD--;
                z2 = true;
            }
            i2++;
        }
        return z2;
    }

    @Override // java.util.Collection
    public final int size() {
        return this.f1525a.d();
    }

    @Override // java.util.Collection
    public final Object[] toArray() {
        C0101a c0101a = this.f1525a;
        int iD = c0101a.d();
        Object[] objArr = new Object[iD];
        for (int i2 = 0; i2 < iD; i2++) {
            objArr[i2] = c0101a.b(i2, 1);
        }
        return objArr;
    }

    @Override // java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        return this.f1525a.i(objArr, 1);
    }
}
