package l;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Map;
import java.util.Set;

/* JADX INFO: renamed from: l.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0102b extends C0111k implements Map {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public C0101a f1499h;

    @Override // java.util.Map
    public final Set entrySet() {
        if (this.f1499h == null) {
            this.f1499h = new C0101a(0, this);
        }
        C0101a c0101a = this.f1499h;
        if (c0101a.f1495a == null) {
            c0101a.f1495a = new C0108h(c0101a, 0);
        }
        return c0101a.f1495a;
    }

    @Override // java.util.Map
    public final Set keySet() {
        if (this.f1499h == null) {
            this.f1499h = new C0101a(0, this);
        }
        C0101a c0101a = this.f1499h;
        if (c0101a.b == null) {
            c0101a.b = new C0108h(c0101a, 1);
        }
        return c0101a.b;
    }

    @Override // java.util.Map
    public final void putAll(Map map) {
        int size = map.size() + this.f1530c;
        int i2 = this.f1530c;
        int[] iArr = this.f1529a;
        if (iArr.length < size) {
            Object[] objArr = this.b;
            a(size);
            if (this.f1530c > 0) {
                System.arraycopy(iArr, 0, this.f1529a, 0, i2);
                System.arraycopy(objArr, 0, this.b, 0, i2 << 1);
            }
            C0111k.b(iArr, objArr, i2);
        }
        if (this.f1530c != i2) {
            throw new ConcurrentModificationException();
        }
        for (Map.Entry entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    @Override // java.util.Map
    public final Collection values() {
        if (this.f1499h == null) {
            this.f1499h = new C0101a(0, this);
        }
        C0101a c0101a = this.f1499h;
        if (c0101a.f1496c == null) {
            c0101a.f1496c = new C0110j(c0101a);
        }
        return c0101a.f1496c;
    }
}
