package L;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public interface f {
    void l(int i2, Serializable serializable);

    void q();
}
