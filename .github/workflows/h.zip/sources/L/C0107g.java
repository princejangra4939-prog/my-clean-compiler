package l;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: l.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0107g implements Iterator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f1517a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1518c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1519d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C0101a f1520e;

    public C0107g(C0101a c0101a, int i2) {
        this.f1520e = c0101a;
        this.f1517a = i2;
        this.b = c0101a.d();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f1518c < this.b;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        Object objB = this.f1520e.b(this.f1518c, this.f1517a);
        this.f1518c++;
        this.f1519d = true;
        return objB;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f1519d) {
            throw new IllegalStateException();
        }
        int i2 = this.f1518c - 1;
        this.f1518c = i2;
        this.b--;
        this.f1519d = false;
        this.f1520e.g(i2);
    }
}
