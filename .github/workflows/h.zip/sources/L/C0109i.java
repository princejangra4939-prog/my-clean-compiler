package l;

import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

/* JADX INFO: renamed from: l.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0109i implements Iterator, Map.Entry {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1522a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C0101a f1524d;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1523c = false;
    public int b = -1;

    public C0109i(C0101a c0101a) {
        this.f1524d = c0101a;
        this.f1522a = c0101a.d() - 1;
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (!this.f1523c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        Map.Entry entry = (Map.Entry) obj;
        Object key = entry.getKey();
        int i2 = this.b;
        C0101a c0101a = this.f1524d;
        Object objB = c0101a.b(i2, 0);
        if (key != objB && (key == null || !key.equals(objB))) {
            return false;
        }
        Object value = entry.getValue();
        Object objB2 = c0101a.b(this.b, 1);
        return value == objB2 || (value != null && value.equals(objB2));
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        if (!this.f1523c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        return this.f1524d.b(this.b, 0);
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        if (!this.f1523c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        return this.f1524d.b(this.b, 1);
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.b < this.f1522a;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        if (!this.f1523c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        int i2 = this.b;
        C0101a c0101a = this.f1524d;
        Object objB = c0101a.b(i2, 0);
        Object objB2 = c0101a.b(this.b, 1);
        return (objB == null ? 0 : objB.hashCode()) ^ (objB2 != null ? objB2.hashCode() : 0);
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        this.b++;
        this.f1523c = true;
        return this;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f1523c) {
            throw new IllegalStateException();
        }
        this.f1524d.g(this.b);
        this.b--;
        this.f1522a--;
        this.f1523c = false;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        if (!this.f1523c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        C0101a c0101a = this.f1524d;
        int i2 = this.b;
        switch (c0101a.f1497d) {
            case 0:
                int i3 = (i2 << 1) + 1;
                Object[] objArr = ((C0102b) c0101a.f1498e).b;
                Object obj2 = objArr[i3];
                objArr[i3] = obj;
                return obj2;
            default:
                throw new UnsupportedOperationException("not a map");
        }
    }

    public final String toString() {
        return getKey() + "=" + getValue();
    }
}
