package l;

import java.lang.reflect.Array;
import java.util.Map;
import java.util.Set;

/* JADX INFO: renamed from: l.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0101a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public C0108h f1495a;
    public C0108h b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C0110j f1496c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f1497d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f1498e;

    public /* synthetic */ C0101a(int i2, Object obj) {
        this.f1497d = i2;
        this.f1498e = obj;
    }

    public static boolean h(Set set, Object obj) {
        if (set == obj) {
            return true;
        }
        if (!(obj instanceof Set)) {
            return false;
        }
        Set set2 = (Set) obj;
        try {
            if (set.size() == set2.size()) {
                return set.containsAll(set2);
            }
            return false;
        } catch (ClassCastException | NullPointerException unused) {
            return false;
        }
    }

    public final void a() {
        switch (this.f1497d) {
            case 0:
                ((C0102b) this.f1498e).clear();
                break;
            default:
                ((C0103c) this.f1498e).clear();
                break;
        }
    }

    public final Object b(int i2, int i3) {
        switch (this.f1497d) {
            case 0:
                return ((C0102b) this.f1498e).b[(i2 << 1) + i3];
            default:
                return ((C0103c) this.f1498e).b[i2];
        }
    }

    public final Map c() {
        switch (this.f1497d) {
            case 0:
                return (C0102b) this.f1498e;
            default:
                throw new UnsupportedOperationException("not a map");
        }
    }

    public final int d() {
        switch (this.f1497d) {
            case 0:
                return ((C0102b) this.f1498e).f1530c;
            default:
                return ((C0103c) this.f1498e).f1506c;
        }
    }

    public final int e(Object obj) {
        switch (this.f1497d) {
            case 0:
                return ((C0102b) this.f1498e).d(obj);
            default:
                C0103c c0103c = (C0103c) this.f1498e;
                return obj == null ? c0103c.d() : c0103c.c(obj.hashCode(), obj);
        }
    }

    public final int f(Object obj) {
        switch (this.f1497d) {
            case 0:
                return ((C0102b) this.f1498e).f(obj);
            default:
                C0103c c0103c = (C0103c) this.f1498e;
                return obj == null ? c0103c.d() : c0103c.c(obj.hashCode(), obj);
        }
    }

    public final void g(int i2) {
        switch (this.f1497d) {
            case 0:
                ((C0102b) this.f1498e).h(i2);
                break;
            default:
                ((C0103c) this.f1498e).e(i2);
                break;
        }
    }

    public final Object[] i(Object[] objArr, int i2) {
        int iD = d();
        if (objArr.length < iD) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), iD);
        }
        for (int i3 = 0; i3 < iD; i3++) {
            objArr[i3] = b(i3, i2);
        }
        if (objArr.length > iD) {
            objArr[iD] = null;
        }
        return objArr;
    }
}
