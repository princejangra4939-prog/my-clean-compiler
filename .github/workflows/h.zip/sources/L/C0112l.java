package l;

/* JADX INFO: renamed from: l.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0112l implements Cloneable {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Object f1531d = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int[] f1532a;
    public Object[] b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1533c;

    public C0112l() {
        int i2;
        int i3 = 4;
        while (true) {
            i2 = 40;
            if (i3 >= 32) {
                break;
            }
            int i4 = (1 << i3) - 12;
            if (40 <= i4) {
                i2 = i4;
                break;
            }
            i3++;
        }
        int i5 = i2 / 4;
        this.f1532a = new int[i5];
        this.b = new Object[i5];
    }

    public final void a(int i2, Object obj) {
        int i3 = this.f1533c;
        if (i3 == 0 || i2 > this.f1532a[i3 - 1]) {
            if (i3 >= this.f1532a.length) {
                int i4 = (i3 + 1) * 4;
                int i5 = 4;
                while (true) {
                    if (i5 >= 32) {
                        break;
                    }
                    int i6 = (1 << i5) - 12;
                    if (i4 <= i6) {
                        i4 = i6;
                        break;
                    }
                    i5++;
                }
                int i7 = i4 / 4;
                int[] iArr = new int[i7];
                Object[] objArr = new Object[i7];
                int[] iArr2 = this.f1532a;
                System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
                Object[] objArr2 = this.b;
                System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
                this.f1532a = iArr;
                this.b = objArr;
            }
            this.f1532a[i3] = i2;
            this.b[i3] = obj;
            this.f1533c = i3 + 1;
            return;
        }
        int iA = AbstractC0104d.a(this.f1533c, i2, this.f1532a);
        if (iA >= 0) {
            this.b[iA] = obj;
            return;
        }
        int i8 = ~iA;
        int i9 = this.f1533c;
        if (i8 < i9) {
            Object[] objArr3 = this.b;
            if (objArr3[i8] == f1531d) {
                this.f1532a[i8] = i2;
                objArr3[i8] = obj;
                return;
            }
        }
        if (i9 >= this.f1532a.length) {
            int i10 = (i9 + 1) * 4;
            int i11 = 4;
            while (true) {
                if (i11 >= 32) {
                    break;
                }
                int i12 = (1 << i11) - 12;
                if (i10 <= i12) {
                    i10 = i12;
                    break;
                }
                i11++;
            }
            int i13 = i10 / 4;
            int[] iArr3 = new int[i13];
            Object[] objArr4 = new Object[i13];
            int[] iArr4 = this.f1532a;
            System.arraycopy(iArr4, 0, iArr3, 0, iArr4.length);
            Object[] objArr5 = this.b;
            System.arraycopy(objArr5, 0, objArr4, 0, objArr5.length);
            this.f1532a = iArr3;
            this.b = objArr4;
        }
        int i14 = this.f1533c - i8;
        if (i14 != 0) {
            int[] iArr5 = this.f1532a;
            int i15 = i8 + 1;
            System.arraycopy(iArr5, i8, iArr5, i15, i14);
            Object[] objArr6 = this.b;
            System.arraycopy(objArr6, i8, objArr6, i15, this.f1533c - i8);
        }
        this.f1532a[i8] = i2;
        this.b[i8] = obj;
        this.f1533c++;
    }

    public final Object clone() {
        try {
            C0112l c0112l = (C0112l) super.clone();
            c0112l.f1532a = (int[]) this.f1532a.clone();
            c0112l.b = (Object[]) this.b.clone();
            return c0112l;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public final String toString() {
        int i2 = this.f1533c;
        if (i2 <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(i2 * 28);
        sb.append('{');
        for (int i3 = 0; i3 < this.f1533c; i3++) {
            if (i3 > 0) {
                sb.append(", ");
            }
            sb.append(this.f1532a[i3]);
            sb.append('=');
            Object obj = this.b[i3];
            if (obj != this) {
                sb.append(obj);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
