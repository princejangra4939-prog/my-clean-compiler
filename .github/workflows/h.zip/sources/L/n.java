package L;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Objects;

/* JADX INFO: loaded from: classes.dex */
public final class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f106a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f107c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final long f108d;

    public n(int i2, int i3, long j2, long j3) {
        this.f106a = i2;
        this.b = i3;
        this.f107c = j2;
        this.f108d = j3;
    }

    public static n a(File file) throws IOException {
        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
        try {
            n nVar = new n(dataInputStream.readInt(), dataInputStream.readInt(), dataInputStream.readLong(), dataInputStream.readLong());
            dataInputStream.close();
            return nVar;
        } finally {
        }
    }

    public final void b(File file) throws IOException {
        file.delete();
        DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(file));
        try {
            dataOutputStream.writeInt(this.f106a);
            dataOutputStream.writeInt(this.b);
            dataOutputStream.writeLong(this.f107c);
            dataOutputStream.writeLong(this.f108d);
            dataOutputStream.close();
        } catch (Throwable th) {
            try {
                dataOutputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && (obj instanceof n)) {
            n nVar = (n) obj;
            if (this.b == nVar.b && this.f107c == nVar.f107c && this.f106a == nVar.f106a && this.f108d == nVar.f108d) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Objects.hash(Integer.valueOf(this.b), Long.valueOf(this.f107c), Integer.valueOf(this.f106a), Long.valueOf(this.f108d));
    }
}
