package F;

import android.os.Build;
import android.view.View;
import java.nio.ByteBuffer;
import y.C0157a;
import y.C0158b;
import y.K;

/* JADX INFO: loaded from: classes.dex */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f53a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f54c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f55d;

    public c() {
        if (d.b == null) {
            d.b = new d(0);
        }
    }

    public int a(int i2) {
        if (i2 < this.f54c) {
            return ((ByteBuffer) this.f55d).getShort(this.b + i2);
        }
        return 0;
    }

    public abstract Object b(View view);

    public abstract void c(View view, Object obj);

    public void d(View view, Object obj) {
        Object tag;
        if (Build.VERSION.SDK_INT >= this.b) {
            c(view, obj);
            return;
        }
        if (Build.VERSION.SDK_INT >= this.b) {
            tag = b(view);
        } else {
            tag = view.getTag(this.f53a);
            if (!((Class) this.f55d).isInstance(tag)) {
                tag = null;
            }
        }
        if (e(tag, obj)) {
            View.AccessibilityDelegate accessibilityDelegateC = K.c(view);
            C0158b c0158b = accessibilityDelegateC == null ? null : accessibilityDelegateC instanceof C0157a ? ((C0157a) accessibilityDelegateC).f1672a : new C0158b(accessibilityDelegateC);
            if (c0158b == null) {
                c0158b = new C0158b();
            }
            K.h(view, c0158b);
            view.setTag(this.f53a, obj);
            K.e(view, this.f54c);
        }
    }

    public abstract boolean e(Object obj, Object obj2);
}
