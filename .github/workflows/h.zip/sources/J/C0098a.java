package j;

import D.g;
import java.util.concurrent.Executors;

/* JADX INFO: renamed from: j.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0098a extends g {

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public static volatile C0098a f1481p;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Object f1482o;

    public C0098a(int i2) {
        switch (i2) {
            case 1:
                this.f1482o = new Object();
                Executors.newFixedThreadPool(4, new ThreadFactoryC0099b());
                break;
            default:
                this.f1482o = new C0098a(1);
                break;
        }
    }
}
