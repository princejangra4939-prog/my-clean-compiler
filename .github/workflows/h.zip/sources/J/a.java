package J;

/* JADX INFO: loaded from: classes.dex */
public final class a extends b {
    public static final a b = new a();
}
