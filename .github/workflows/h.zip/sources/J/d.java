package J;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Class f76a;

    public d(Class cls) {
        this.f76a = cls;
    }
}
