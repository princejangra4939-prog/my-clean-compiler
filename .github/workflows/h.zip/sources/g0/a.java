package g0;

import e0.c;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/* JADX INFO: loaded from: classes.dex */
public final class a extends f0.a {
    @Override // f0.a
    public final Random a() {
        ThreadLocalRandom threadLocalRandomCurrent = ThreadLocalRandom.current();
        c.d(threadLocalRandomCurrent, "current()");
        return threadLocalRandomCurrent;
    }
}
