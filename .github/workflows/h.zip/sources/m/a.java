package M;

import android.os.Bundle;
import com.warppaiwarden.tictactoe.MainActivity;
import java.util.ArrayList;
import java.util.LinkedHashSet;

/* JADX INFO: loaded from: classes.dex */
public final class a implements d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f113a = 0;
    public final Object b;

    public a(e eVar) {
        e0.c.e(eVar, "registry");
        this.b = new LinkedHashSet();
        eVar.e("androidx.savedstate.Restarter", this);
    }

    @Override // M.d
    public final Bundle a() {
        switch (this.f113a) {
            case 0:
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("classes_to_restore", new ArrayList<>((LinkedHashSet) this.b));
                return bundle;
            default:
                Bundle bundle2 = new Bundle();
                ((MainActivity) this.b).i().getClass();
                return bundle2;
        }
    }

    public a(MainActivity mainActivity) {
        this.b = mainActivity;
    }
}
