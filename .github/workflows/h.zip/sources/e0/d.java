package e0;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public abstract class d implements Serializable {
    public final String toString() {
        f.f1010a.getClass();
        String string = getClass().getGenericInterfaces()[0].toString();
        if (string.startsWith("kotlin.jvm.functions.")) {
            string = string.substring(21);
        }
        c.d(string, "renderLambdaToString(this)");
        return string;
    }
}
