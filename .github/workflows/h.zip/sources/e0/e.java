package e0;

import androidx.activity.v;

/* JADX INFO: loaded from: classes.dex */
public final class e implements a {
    @Override // e0.a
    public final Class a() {
        return v.class;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof e)) {
            return false;
        }
        ((e) obj).getClass();
        return v.class.equals(v.class);
    }

    public final int hashCode() {
        return v.class.hashCode();
    }

    public final String toString() {
        return v.class.toString() + " (Kotlin reflection is not available)";
    }
}
