package D;

import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public abstract class s {
    public static void a(TextView textView, int i2, float f) {
        textView.setLineHeight(i2, f);
    }
}
