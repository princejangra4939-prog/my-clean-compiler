package androidx.savedstate;

import M.a;
import M.c;
import M.e;
import M.g;
import android.os.Bundle;
import androidx.lifecycle.C0008h;
import androidx.lifecycle.E;
import androidx.lifecycle.G;
import androidx.lifecycle.H;
import androidx.lifecycle.SavedStateHandleController;
import androidx.lifecycle.k;
import androidx.lifecycle.o;
import androidx.lifecycle.q;
import androidx.lifecycle.s;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;

/* JADX INFO: loaded from: classes.dex */
public final class Recreator implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f749a;

    public Recreator(g gVar) {
        this.f749a = gVar;
    }

    /* JADX WARN: Type inference failed for: r13v3, types: [M.g, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v2, types: [M.g, androidx.lifecycle.q, java.lang.Object] */
    @Override // androidx.lifecycle.o
    public final void b(q qVar, k kVar) {
        Object obj;
        boolean z2;
        if (kVar != k.ON_CREATE) {
            throw new AssertionError("Next event must be ON_CREATE");
        }
        qVar.c().f(this);
        Bundle bundleC = this.f749a.a().c("androidx.savedstate.Restarter");
        if (bundleC == null) {
            return;
        }
        ArrayList<String> stringArrayList = bundleC.getStringArrayList("classes_to_restore");
        if (stringArrayList == null) {
            throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
        }
        int size = stringArrayList.size();
        int i2 = 0;
        while (i2 < size) {
            String str = stringArrayList.get(i2);
            i2++;
            String str2 = str;
            try {
                Class<? extends U> clsAsSubclass = Class.forName(str2, false, Recreator.class.getClassLoader()).asSubclass(c.class);
                e0.c.d(clsAsSubclass, "{\n                Class.…class.java)\n            }");
                try {
                    Constructor declaredConstructor = clsAsSubclass.getDeclaredConstructor(null);
                    declaredConstructor.setAccessible(true);
                    try {
                        Object objNewInstance = declaredConstructor.newInstance(null);
                        e0.c.d(objNewInstance, "{\n                constr…wInstance()\n            }");
                        ?? r2 = this.f749a;
                        if (!(r2 instanceof H)) {
                            throw new IllegalStateException("Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner");
                        }
                        G gB = ((H) r2).b();
                        e eVarA = r2.a();
                        gB.getClass();
                        for (String str3 : new HashSet(gB.f719a.keySet())) {
                            e0.c.e(str3, "key");
                            E e2 = (E) gB.f719a.get(str3);
                            e0.c.b(e2);
                            s sVarC = r2.c();
                            e0.c.e(eVarA, "registry");
                            e0.c.e(sVarC, "lifecycle");
                            HashMap map = e2.f717a;
                            if (map == null) {
                                obj = null;
                            } else {
                                synchronized (map) {
                                    obj = e2.f717a.get("androidx.lifecycle.savedstate.vm.tag");
                                }
                            }
                            SavedStateHandleController savedStateHandleController = (SavedStateHandleController) obj;
                            if (savedStateHandleController != null && !(z2 = savedStateHandleController.f722a)) {
                                if (z2) {
                                    throw new IllegalStateException("Already attached to lifecycleOwner");
                                }
                                savedStateHandleController.f722a = true;
                                sVarC.a(savedStateHandleController);
                                throw null;
                            }
                        }
                        if (!new HashSet(gB.f719a.keySet()).isEmpty()) {
                            if (!eVarA.f116c) {
                                throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
                            }
                            a aVar = (a) eVarA.f;
                            if (aVar == null) {
                                aVar = new a(eVarA);
                            }
                            eVarA.f = aVar;
                            try {
                                C0008h.class.getDeclaredConstructor(null);
                                a aVar2 = (a) eVarA.f;
                                if (aVar2 != null) {
                                    ((LinkedHashSet) aVar2.b).add(C0008h.class.getName());
                                }
                            } catch (NoSuchMethodException e3) {
                                throw new IllegalArgumentException("Class " + C0008h.class.getSimpleName() + " must have default constructor in order to be automatically recreated", e3);
                            }
                        }
                    } catch (Exception e4) {
                        throw new RuntimeException("Failed to instantiate " + str2, e4);
                    }
                } catch (NoSuchMethodException e5) {
                    throw new IllegalStateException("Class " + clsAsSubclass.getSimpleName() + " must have default constructor in order to be automatically recreated", e5);
                }
            } catch (ClassNotFoundException e6) {
                throw new RuntimeException("Class " + str2 + " wasn't found", e6);
            }
        }
    }
}
