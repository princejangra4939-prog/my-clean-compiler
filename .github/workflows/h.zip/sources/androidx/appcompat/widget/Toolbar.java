package androidx.appcompat.widget;

import C.h;
import D.b;
import D.g;
import W.c;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import com.warppaiwarden.tictactoe.R;
import d.AbstractC0010a;
import e.G;
import e.H;
import g.C0035h;
import h.n;
import h.p;
import i.B;
import i.C0054d0;
import i.C0069l;
import i.C0096z;
import i.InterfaceC0072m0;
import i.P0;
import i.W0;
import i.X0;
import i.Y0;
import i.Z0;
import i.a1;
import i.b1;
import i.c1;
import i.e1;
import i.m1;
import java.util.ArrayList;
import y.K;

/* JADX INFO: loaded from: classes.dex */
public class Toolbar extends ViewGroup {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public ColorStateList f469A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public boolean f470B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f471C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final ArrayList f472D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final ArrayList f473E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final int[] f474F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final h f475G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public ArrayList f476H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public b1 f477I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final X0 f478J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public e1 f479K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public C0069l f480L;

    /* JADX INFO: renamed from: M, reason: collision with root package name */
    public Z0 f481M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public H f482N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public G f483O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public boolean f484P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public OnBackInvokedCallback f485Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public OnBackInvokedDispatcher f486R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public boolean f487S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public final b f488T;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ActionMenuView f489a;
    public C0054d0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C0054d0 f490c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C0096z f491d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public B f492e;
    public final Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final CharSequence f493g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public C0096z f494h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public View f495i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Context f496j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f497k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f498l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f499m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f500n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final int f501o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f502p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f503q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f504r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f505s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public P0 f506t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f507u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f508v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f509w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public CharSequence f510x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public CharSequence f511y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public ColorStateList f512z;

    public Toolbar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.toolbarStyle);
        this.f509w = 8388627;
        this.f472D = new ArrayList();
        this.f473E = new ArrayList();
        this.f474F = new int[2];
        this.f475G = new h(new W0(this, 1));
        this.f476H = new ArrayList();
        this.f478J = new X0(this);
        this.f488T = new b(8, this);
        Context context2 = getContext();
        int[] iArr = AbstractC0010a.f820w;
        h hVarM = h.m(context2, attributeSet, iArr, R.attr.toolbarStyle);
        K.g(this, context, iArr, attributeSet, (TypedArray) hVarM.b, R.attr.toolbarStyle);
        TypedArray typedArray = (TypedArray) hVarM.b;
        this.f498l = typedArray.getResourceId(28, 0);
        this.f499m = typedArray.getResourceId(19, 0);
        this.f509w = typedArray.getInteger(0, 8388627);
        this.f500n = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f505s = dimensionPixelOffset;
        this.f504r = dimensionPixelOffset;
        this.f503q = dimensionPixelOffset;
        this.f502p = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f502p = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f503q = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f504r = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f505s = dimensionPixelOffset5;
        }
        this.f501o = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        P0 p0 = this.f506t;
        p0.f1286h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            p0.f1284e = dimensionPixelSize;
            p0.f1281a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            p0.f = dimensionPixelSize2;
            p0.b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            p0.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f507u = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f508v = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f = hVarM.i(4);
        this.f493g = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f496j = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable drawableI = hVarM.i(16);
        if (drawableI != null) {
            setNavigationIcon(drawableI);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable drawableI2 = hVarM.i(11);
        if (drawableI2 != null) {
            setLogo(drawableI2);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(hVarM.h(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(hVarM.h(20));
        }
        if (typedArray.hasValue(14)) {
            getMenuInflater().inflate(typedArray.getResourceId(14, 0), getMenu());
        }
        hVarM.r();
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i2 = 0; i2 < menu.size(); i2++) {
            arrayList.add(menu.getItem(i2));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new C0035h(getContext());
    }

    public static a1 h() {
        a1 a1Var = new a1(-2, -2);
        a1Var.b = 0;
        a1Var.f1325a = 8388627;
        return a1Var;
    }

    public static a1 i(ViewGroup.LayoutParams layoutParams) {
        boolean z2 = layoutParams instanceof a1;
        if (z2) {
            a1 a1Var = (a1) layoutParams;
            a1 a1Var2 = new a1(a1Var);
            a1Var2.b = 0;
            a1Var2.b = a1Var.b;
            return a1Var2;
        }
        if (z2) {
            a1 a1Var3 = new a1((a1) layoutParams);
            a1Var3.b = 0;
            return a1Var3;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            a1 a1Var4 = new a1(layoutParams);
            a1Var4.b = 0;
            return a1Var4;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        a1 a1Var5 = new a1(marginLayoutParams);
        a1Var5.b = 0;
        ((ViewGroup.MarginLayoutParams) a1Var5).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) a1Var5).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) a1Var5).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) a1Var5).bottomMargin = marginLayoutParams.bottomMargin;
        return a1Var5;
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(ArrayList arrayList, int i2) {
        boolean z2 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i2, getLayoutDirection());
        arrayList.clear();
        if (!z2) {
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = getChildAt(i3);
                a1 a1Var = (a1) childAt.getLayoutParams();
                if (a1Var.b == 0 && t(childAt)) {
                    int i4 = a1Var.f1325a;
                    int layoutDirection = getLayoutDirection();
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i4, layoutDirection) & 7;
                    if (absoluteGravity2 != 1 && absoluteGravity2 != 3 && absoluteGravity2 != 5) {
                        absoluteGravity2 = layoutDirection == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i5 = childCount - 1; i5 >= 0; i5--) {
            View childAt2 = getChildAt(i5);
            a1 a1Var2 = (a1) childAt2.getLayoutParams();
            if (a1Var2.b == 0 && t(childAt2)) {
                int i6 = a1Var2.f1325a;
                int layoutDirection2 = getLayoutDirection();
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i6, layoutDirection2) & 7;
                if (absoluteGravity3 != 1 && absoluteGravity3 != 3 && absoluteGravity3 != 5) {
                    absoluteGravity3 = layoutDirection2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        a1 a1VarH = layoutParams == null ? h() : !checkLayoutParams(layoutParams) ? i(layoutParams) : (a1) layoutParams;
        a1VarH.b = 1;
        if (!z2 || this.f495i == null) {
            addView(view, a1VarH);
        } else {
            view.setLayoutParams(a1VarH);
            this.f473E.add(view);
        }
    }

    public final void c() {
        if (this.f494h == null) {
            C0096z c0096z = new C0096z(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            this.f494h = c0096z;
            c0096z.setImageDrawable(this.f);
            this.f494h.setContentDescription(this.f493g);
            a1 a1VarH = h();
            a1VarH.f1325a = (this.f500n & 112) | 8388611;
            a1VarH.b = 2;
            this.f494h.setLayoutParams(a1VarH);
            this.f494h.setOnClickListener(new c(3, this));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof a1);
    }

    public final void d() {
        if (this.f506t == null) {
            P0 p0 = new P0();
            p0.f1281a = 0;
            p0.b = 0;
            p0.f1282c = Integer.MIN_VALUE;
            p0.f1283d = Integer.MIN_VALUE;
            p0.f1284e = 0;
            p0.f = 0;
            p0.f1285g = false;
            p0.f1286h = false;
            this.f506t = p0;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f489a;
        if (actionMenuView.f446p == null) {
            n nVar = (n) actionMenuView.getMenu();
            if (this.f481M == null) {
                this.f481M = new Z0(this);
            }
            this.f489a.setExpandedActionViewsExclusive(true);
            nVar.b(this.f481M, this.f496j);
            v();
        }
    }

    public final void f() {
        if (this.f489a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.f489a = actionMenuView;
            actionMenuView.setPopupTheme(this.f497k);
            this.f489a.setOnMenuItemClickListener(this.f478J);
            ActionMenuView actionMenuView2 = this.f489a;
            H h2 = this.f482N;
            X0 x0 = new X0(this);
            actionMenuView2.f451u = h2;
            actionMenuView2.f452v = x0;
            a1 a1VarH = h();
            a1VarH.f1325a = (this.f500n & 112) | 8388613;
            this.f489a.setLayoutParams(a1VarH);
            b(this.f489a, false);
        }
    }

    public final void g() {
        if (this.f491d == null) {
            this.f491d = new C0096z(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            a1 a1VarH = h();
            a1VarH.f1325a = (this.f500n & 112) | 8388611;
            this.f491d.setLayoutParams(a1VarH);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        C0096z c0096z = this.f494h;
        if (c0096z != null) {
            return c0096z.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        C0096z c0096z = this.f494h;
        if (c0096z != null) {
            return c0096z.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        P0 p0 = this.f506t;
        if (p0 != null) {
            return p0.f1285g ? p0.f1281a : p0.b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i2 = this.f508v;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        P0 p0 = this.f506t;
        if (p0 != null) {
            return p0.f1281a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        P0 p0 = this.f506t;
        if (p0 != null) {
            return p0.b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        P0 p0 = this.f506t;
        if (p0 != null) {
            return p0.f1285g ? p0.b : p0.f1281a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i2 = this.f507u;
        return i2 != Integer.MIN_VALUE ? i2 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        n nVar;
        ActionMenuView actionMenuView = this.f489a;
        return (actionMenuView == null || (nVar = actionMenuView.f446p) == null || !nVar.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f508v, 0));
    }

    public int getCurrentContentInsetLeft() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f507u, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        B b = this.f492e;
        if (b != null) {
            return b.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        B b = this.f492e;
        if (b != null) {
            return b.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f489a.getMenu();
    }

    public View getNavButtonView() {
        return this.f491d;
    }

    public CharSequence getNavigationContentDescription() {
        C0096z c0096z = this.f491d;
        if (c0096z != null) {
            return c0096z.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        C0096z c0096z = this.f491d;
        if (c0096z != null) {
            return c0096z.getDrawable();
        }
        return null;
    }

    public C0069l getOuterActionMenuPresenter() {
        return this.f480L;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f489a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f496j;
    }

    public int getPopupTheme() {
        return this.f497k;
    }

    public CharSequence getSubtitle() {
        return this.f511y;
    }

    public final TextView getSubtitleTextView() {
        return this.f490c;
    }

    public CharSequence getTitle() {
        return this.f510x;
    }

    public int getTitleMarginBottom() {
        return this.f505s;
    }

    public int getTitleMarginEnd() {
        return this.f503q;
    }

    public int getTitleMarginStart() {
        return this.f502p;
    }

    public int getTitleMarginTop() {
        return this.f504r;
    }

    public final TextView getTitleTextView() {
        return this.b;
    }

    public InterfaceC0072m0 getWrapper() {
        if (this.f479K == null) {
            this.f479K = new e1(this, true);
        }
        return this.f479K;
    }

    public final int j(View view, int i2) {
        a1 a1Var = (a1) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i3 = i2 > 0 ? (measuredHeight - i2) / 2 : 0;
        int i4 = a1Var.f1325a & 112;
        if (i4 != 16 && i4 != 48 && i4 != 80) {
            i4 = this.f509w & 112;
        }
        if (i4 == 48) {
            return getPaddingTop() - i3;
        }
        if (i4 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) a1Var).bottomMargin) - i3;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i5 = ((ViewGroup.MarginLayoutParams) a1Var).topMargin;
        if (iMax < i5) {
            iMax = i5;
        } else {
            int i6 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i7 = ((ViewGroup.MarginLayoutParams) a1Var).bottomMargin;
            if (i6 < i7) {
                iMax = Math.max(0, iMax - (i7 - i6));
            }
        }
        return paddingTop + iMax;
    }

    public final void m() {
        ArrayList arrayList = this.f476H;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            getMenu().removeItem(((MenuItem) obj).getItemId());
        }
        getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        getMenuInflater();
        this.f475G.n();
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.f476H = currentMenuItems2;
    }

    public final boolean n(View view) {
        return view.getParent() == this || this.f473E.contains(view);
    }

    public final boolean o() {
        C0069l c0069l;
        ActionMenuView actionMenuView = this.f489a;
        return (actionMenuView == null || (c0069l = actionMenuView.f450t) == null || !c0069l.h()) ? false : true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        v();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f488T);
        v();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f471C = false;
        }
        if (!this.f471C) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f471C = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f471C = false;
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:103:0x028f A[LOOP:0: B:102:0x028d->B:103:0x028f, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:106:0x02a7 A[LOOP:1: B:105:0x02a5->B:106:0x02a7, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:109:0x02c8 A[LOOP:2: B:108:0x02c6->B:109:0x02c8, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:113:0x030b  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x0318 A[LOOP:3: B:117:0x0316->B:118:0x0318, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0106  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x011f  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0125  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0127  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x012a  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x012e  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0131  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0164  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x019d  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x01aa  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x0218  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onLayout(boolean r19, int r20, int r21, int r22, int r23) {
        /*
            Method dump skipped, instruction units count: 809
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        char c2;
        Object[] objArr;
        int iK;
        int iMax;
        int iCombineMeasuredStates;
        int iK2;
        int iL;
        int iCombineMeasuredStates2;
        int iMax2;
        boolean z2 = m1.f1408a;
        int i4 = 0;
        if (getLayoutDirection() == 1) {
            objArr = true;
            c2 = 0;
        } else {
            c2 = 1;
            objArr = false;
        }
        if (t(this.f491d)) {
            s(this.f491d, i2, 0, i3, this.f501o);
            iK = k(this.f491d) + this.f491d.getMeasuredWidth();
            iMax = Math.max(0, l(this.f491d) + this.f491d.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.f491d.getMeasuredState());
        } else {
            iK = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (t(this.f494h)) {
            s(this.f494h, i2, 0, i3, this.f501o);
            iK = k(this.f494h) + this.f494h.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f494h) + this.f494h.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f494h.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, iK);
        int iMax4 = Math.max(0, currentContentInsetStart - iK);
        Object[] objArr2 = objArr;
        int[] iArr = this.f474F;
        iArr[objArr2 == true ? 1 : 0] = iMax4;
        if (t(this.f489a)) {
            s(this.f489a, i2, iMax3, i3, this.f501o);
            iK2 = k(this.f489a) + this.f489a.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f489a) + this.f489a.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f489a.getMeasuredState());
        } else {
            iK2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax5 = iMax3 + Math.max(currentContentInsetEnd, iK2);
        iArr[c2] = Math.max(0, currentContentInsetEnd - iK2);
        if (t(this.f495i)) {
            iMax5 += r(this.f495i, i2, iMax5, i3, 0, iArr);
            iMax = Math.max(iMax, l(this.f495i) + this.f495i.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f495i.getMeasuredState());
        }
        if (t(this.f492e)) {
            iMax5 += r(this.f492e, i2, iMax5, i3, 0, iArr);
            iMax = Math.max(iMax, l(this.f492e) + this.f492e.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f492e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (((a1) childAt.getLayoutParams()).b == 0 && t(childAt)) {
                iMax5 += r(childAt, i2, iMax5, i3, 0, iArr);
                int iMax6 = Math.max(iMax, l(childAt) + childAt.getMeasuredHeight());
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
                iMax = iMax6;
            } else {
                iMax5 = iMax5;
            }
        }
        int i6 = iMax5;
        int i7 = this.f504r + this.f505s;
        int i8 = this.f502p + this.f503q;
        if (t(this.b)) {
            r(this.b, i2, i6 + i8, i3, i7, iArr);
            int iK3 = k(this.b) + this.b.getMeasuredWidth();
            iL = l(this.b) + this.b.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.b.getMeasuredState());
            iMax2 = iK3;
        } else {
            iL = 0;
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
        }
        if (t(this.f490c)) {
            iMax2 = Math.max(iMax2, r(this.f490c, i2, i6 + i8, i3, i7 + iL, iArr));
            iL += l(this.f490c) + this.f490c.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.f490c.getMeasuredState());
        }
        int iMax7 = Math.max(iMax, iL);
        int paddingRight = getPaddingRight() + getPaddingLeft() + i6 + iMax2;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + iMax7;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i2, (-16777216) & iCombineMeasuredStates2);
        int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i3, iCombineMeasuredStates2 << 16);
        if (!this.f484P) {
            i4 = iResolveSizeAndState2;
            break;
        }
        int childCount2 = getChildCount();
        for (int i9 = 0; i9 < childCount2; i9++) {
            View childAt2 = getChildAt(i9);
            if (t(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                i4 = iResolveSizeAndState2;
                break;
            }
        }
        setMeasuredDimension(iResolveSizeAndState, i4);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof c1)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        c1 c1Var = (c1) parcelable;
        super.onRestoreInstanceState(c1Var.f52a);
        ActionMenuView actionMenuView = this.f489a;
        n nVar = actionMenuView != null ? actionMenuView.f446p : null;
        int i2 = c1Var.f1330c;
        if (i2 != 0 && this.f481M != null && nVar != null && (menuItemFindItem = nVar.findItem(i2)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (c1Var.f1331d) {
            b bVar = this.f488T;
            removeCallbacks(bVar);
            post(bVar);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i2) {
        super.onRtlPropertiesChanged(i2);
        d();
        P0 p0 = this.f506t;
        boolean z2 = i2 == 1;
        if (z2 == p0.f1285g) {
            return;
        }
        p0.f1285g = z2;
        if (!p0.f1286h) {
            p0.f1281a = p0.f1284e;
            p0.b = p0.f;
            return;
        }
        if (z2) {
            int i3 = p0.f1283d;
            if (i3 == Integer.MIN_VALUE) {
                i3 = p0.f1284e;
            }
            p0.f1281a = i3;
            int i4 = p0.f1282c;
            if (i4 == Integer.MIN_VALUE) {
                i4 = p0.f;
            }
            p0.b = i4;
            return;
        }
        int i5 = p0.f1282c;
        if (i5 == Integer.MIN_VALUE) {
            i5 = p0.f1284e;
        }
        p0.f1281a = i5;
        int i6 = p0.f1283d;
        if (i6 == Integer.MIN_VALUE) {
            i6 = p0.f;
        }
        p0.b = i6;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        p pVar;
        c1 c1Var = new c1(super.onSaveInstanceState());
        Z0 z0 = this.f481M;
        if (z0 != null && (pVar = z0.b) != null) {
            c1Var.f1330c = pVar.f1168a;
        }
        c1Var.f1331d = o();
        return c1Var;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f470B = false;
        }
        if (!this.f470B) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f470B = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f470B = false;
        return true;
    }

    public final int p(View view, int i2, int i3, int[] iArr) {
        a1 a1Var = (a1) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) a1Var).leftMargin - iArr[0];
        int iMax = Math.max(0, i4) + i2;
        iArr[0] = Math.max(0, -i4);
        int iJ = j(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iJ, iMax + measuredWidth, view.getMeasuredHeight() + iJ);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) a1Var).rightMargin + iMax;
    }

    public final int q(View view, int i2, int i3, int[] iArr) {
        a1 a1Var = (a1) view.getLayoutParams();
        int i4 = ((ViewGroup.MarginLayoutParams) a1Var).rightMargin - iArr[1];
        int iMax = i2 - Math.max(0, i4);
        iArr[1] = Math.max(0, -i4);
        int iJ = j(view, i3);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iJ, iMax, view.getMeasuredHeight() + iJ);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) a1Var).leftMargin);
    }

    public final int r(View view, int i2, int i3, int i4, int i5, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i6 = marginLayoutParams.leftMargin - iArr[0];
        int i7 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i7) + Math.max(0, i6);
        iArr[0] = Math.max(0, -i6);
        iArr[1] = Math.max(0, -i7);
        view.measure(ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + iMax + i3, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i5, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    public final void s(View view, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i3, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i4, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public void setBackInvokedCallbackEnabled(boolean z2) {
        if (this.f487S != z2) {
            this.f487S = z2;
            v();
        }
    }

    public void setCollapseContentDescription(int i2) {
        setCollapseContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setCollapseIcon(int i2) {
        setCollapseIcon(g.w(getContext(), i2));
    }

    public void setCollapsible(boolean z2) {
        this.f484P = z2;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f508v) {
            this.f508v = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i2) {
        if (i2 < 0) {
            i2 = Integer.MIN_VALUE;
        }
        if (i2 != this.f507u) {
            this.f507u = i2;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i2) {
        setLogo(g.w(getContext(), i2));
    }

    public void setLogoDescription(int i2) {
        setLogoDescription(getContext().getText(i2));
    }

    public void setNavigationContentDescription(int i2) {
        setNavigationContentDescription(i2 != 0 ? getContext().getText(i2) : null);
    }

    public void setNavigationIcon(int i2) {
        setNavigationIcon(g.w(getContext(), i2));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.f491d.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(b1 b1Var) {
        this.f477I = b1Var;
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f489a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i2) {
        if (this.f497k != i2) {
            this.f497k = i2;
            if (i2 == 0) {
                this.f496j = getContext();
            } else {
                this.f496j = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setSubtitle(int i2) {
        setSubtitle(getContext().getText(i2));
    }

    public void setSubtitleTextColor(int i2) {
        setSubtitleTextColor(ColorStateList.valueOf(i2));
    }

    public void setTitle(int i2) {
        setTitle(getContext().getText(i2));
    }

    public void setTitleMarginBottom(int i2) {
        this.f505s = i2;
        requestLayout();
    }

    public void setTitleMarginEnd(int i2) {
        this.f503q = i2;
        requestLayout();
    }

    public void setTitleMarginStart(int i2) {
        this.f502p = i2;
        requestLayout();
    }

    public void setTitleMarginTop(int i2) {
        this.f504r = i2;
        requestLayout();
    }

    public void setTitleTextColor(int i2) {
        setTitleTextColor(ColorStateList.valueOf(i2));
    }

    public final boolean t(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public final boolean u() {
        C0069l c0069l;
        ActionMenuView actionMenuView = this.f489a;
        return (actionMenuView == null || (c0069l = actionMenuView.f450t) == null || !c0069l.l()) ? false : true;
    }

    public final void v() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcherA = Y0.a(this);
            Z0 z0 = this.f481M;
            boolean z2 = (z0 == null || z0.b == null || onBackInvokedDispatcherA == null || !isAttachedToWindow() || !this.f487S) ? false : true;
            if (z2 && this.f486R == null) {
                if (this.f485Q == null) {
                    this.f485Q = Y0.b(new W0(this, 0));
                }
                Y0.c(onBackInvokedDispatcherA, this.f485Q);
                this.f486R = onBackInvokedDispatcherA;
                return;
            }
            if (z2 || (onBackInvokedDispatcher = this.f486R) == null) {
                return;
            }
            Y0.d(onBackInvokedDispatcher, this.f485Q);
            this.f486R = null;
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        a1 a1Var = new a1(context, attributeSet);
        a1Var.f1325a = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0010a.b);
        a1Var.f1325a = typedArrayObtainStyledAttributes.getInt(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        a1Var.b = 0;
        return a1Var;
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        C0096z c0096z = this.f494h;
        if (c0096z != null) {
            c0096z.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f494h.setImageDrawable(drawable);
        } else {
            C0096z c0096z = this.f494h;
            if (c0096z != null) {
                c0096z.setImageDrawable(this.f);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f492e == null) {
                this.f492e = new B(getContext(), null, 0);
            }
            if (!n(this.f492e)) {
                b(this.f492e, true);
            }
        } else {
            B b = this.f492e;
            if (b != null && n(b)) {
                removeView(this.f492e);
                this.f473E.remove(this.f492e);
            }
        }
        B b2 = this.f492e;
        if (b2 != null) {
            b2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f492e == null) {
            this.f492e = new B(getContext(), null, 0);
        }
        B b = this.f492e;
        if (b != null) {
            b.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        C0096z c0096z = this.f491d;
        if (c0096z != null) {
            c0096z.setContentDescription(charSequence);
            g.f0(this.f491d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!n(this.f491d)) {
                b(this.f491d, true);
            }
        } else {
            C0096z c0096z = this.f491d;
            if (c0096z != null && n(c0096z)) {
                removeView(this.f491d);
                this.f473E.remove(this.f491d);
            }
        }
        C0096z c0096z2 = this.f491d;
        if (c0096z2 != null) {
            c0096z2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0054d0 c0054d0 = this.f490c;
            if (c0054d0 != null && n(c0054d0)) {
                removeView(this.f490c);
                this.f473E.remove(this.f490c);
            }
        } else {
            if (this.f490c == null) {
                Context context = getContext();
                C0054d0 c0054d02 = new C0054d0(context, null);
                this.f490c = c0054d02;
                c0054d02.setSingleLine();
                this.f490c.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f499m;
                if (i2 != 0) {
                    this.f490c.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f469A;
                if (colorStateList != null) {
                    this.f490c.setTextColor(colorStateList);
                }
            }
            if (!n(this.f490c)) {
                b(this.f490c, true);
            }
        }
        C0054d0 c0054d03 = this.f490c;
        if (c0054d03 != null) {
            c0054d03.setText(charSequence);
        }
        this.f511y = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f469A = colorStateList;
        C0054d0 c0054d0 = this.f490c;
        if (c0054d0 != null) {
            c0054d0.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C0054d0 c0054d0 = this.b;
            if (c0054d0 != null && n(c0054d0)) {
                removeView(this.b);
                this.f473E.remove(this.b);
            }
        } else {
            if (this.b == null) {
                Context context = getContext();
                C0054d0 c0054d02 = new C0054d0(context, null);
                this.b = c0054d02;
                c0054d02.setSingleLine();
                this.b.setEllipsize(TextUtils.TruncateAt.END);
                int i2 = this.f498l;
                if (i2 != 0) {
                    this.b.setTextAppearance(context, i2);
                }
                ColorStateList colorStateList = this.f512z;
                if (colorStateList != null) {
                    this.b.setTextColor(colorStateList);
                }
            }
            if (!n(this.b)) {
                b(this.b, true);
            }
        }
        C0054d0 c0054d03 = this.b;
        if (c0054d03 != null) {
            c0054d03.setText(charSequence);
        }
        this.f510x = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f512z = colorStateList;
        C0054d0 c0054d0 = this.b;
        if (c0054d0 != null) {
            c0054d0.setTextColor(colorStateList);
        }
    }
}
