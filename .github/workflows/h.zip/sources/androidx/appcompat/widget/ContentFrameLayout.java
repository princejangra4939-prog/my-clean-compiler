package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import e.LayoutInflaterFactory2C0012B;
import e.q;
import h.n;
import i.C0061h;
import i.C0069l;
import i.InterfaceC0068k0;
import i.InterfaceC0070l0;
import i.e1;
import y.Q;

/* JADX INFO: loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public TypedValue f461a;
    public TypedValue b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TypedValue f462c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TypedValue f463d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public TypedValue f464e;
    public TypedValue f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Rect f465g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public InterfaceC0068k0 f466h;

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f465g = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f464e == null) {
            this.f464e = new TypedValue();
        }
        return this.f464e;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f == null) {
            this.f = new TypedValue();
        }
        return this.f;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f462c == null) {
            this.f462c = new TypedValue();
        }
        return this.f462c;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f463d == null) {
            this.f463d = new TypedValue();
        }
        return this.f463d;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f461a == null) {
            this.f461a = new TypedValue();
        }
        return this.f461a;
    }

    public TypedValue getMinWidthMinor() {
        if (this.b == null) {
            this.b = new TypedValue();
        }
        return this.b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        InterfaceC0068k0 interfaceC0068k0 = this.f466h;
        if (interfaceC0068k0 != null) {
            interfaceC0068k0.getClass();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        C0069l c0069l;
        super.onDetachedFromWindow();
        InterfaceC0068k0 interfaceC0068k0 = this.f466h;
        if (interfaceC0068k0 != null) {
            LayoutInflaterFactory2C0012B layoutInflaterFactory2C0012B = ((q) interfaceC0068k0).b;
            InterfaceC0070l0 interfaceC0070l0 = layoutInflaterFactory2C0012B.f880r;
            if (interfaceC0070l0 != null) {
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC0070l0;
                actionBarOverlayLayout.k();
                ActionMenuView actionMenuView = ((e1) actionBarOverlayLayout.f424e).f1339a.f489a;
                if (actionMenuView != null && (c0069l = actionMenuView.f450t) != null) {
                    c0069l.f();
                    C0061h c0061h = c0069l.f1404t;
                    if (c0061h != null && c0061h.b()) {
                        c0061h.f1207i.dismiss();
                    }
                }
            }
            if (layoutInflaterFactory2C0012B.f885w != null) {
                layoutInflaterFactory2C0012B.f874l.getDecorView().removeCallbacks(layoutInflaterFactory2C0012B.f886x);
                if (layoutInflaterFactory2C0012B.f885w.isShowing()) {
                    try {
                        layoutInflaterFactory2C0012B.f885w.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                layoutInflaterFactory2C0012B.f885w = null;
            }
            Q q2 = layoutInflaterFactory2C0012B.f887y;
            if (q2 != null) {
                q2.b();
            }
            n nVar = layoutInflaterFactory2C0012B.z(0).f829h;
            if (nVar != null) {
                nVar.c(true);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x00d1  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x00d9  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x00de  */
    @Override // android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onMeasure(int r17, int r18) {
        /*
            Method dump skipped, instruction units count: 229
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ContentFrameLayout.onMeasure(int, int):void");
    }

    public void setAttachListener(InterfaceC0068k0 interfaceC0068k0) {
        this.f466h = interfaceC0068k0;
    }
}
