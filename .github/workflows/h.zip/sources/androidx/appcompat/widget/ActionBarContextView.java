package androidx.appcompat.widget;

import D.g;
import W.c;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.warppaiwarden.tictactoe.R;
import d.AbstractC0010a;
import g.AbstractC0028a;
import h.B;
import h.n;
import i.C0047a;
import i.C0061h;
import i.C0069l;
import i.m1;
import y.K;
import y.Q;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0047a f398a;
    public final Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ActionMenuView f399c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C0069l f400d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f401e;
    public Q f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f402g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f403h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public CharSequence f404i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f405j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public View f406k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public View f407l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public View f408m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public LinearLayout f409n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public TextView f410o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public TextView f411p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final int f412q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f413r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f414s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f415t;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        int resourceId;
        super(context, attributeSet, R.attr.actionModeStyle);
        this.f398a = new C0047a(this);
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.b = context;
        } else {
            this.b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0010a.f802d, R.attr.actionModeStyle, 0);
        setBackground((!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : g.w(context, resourceId));
        this.f412q = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f413r = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        this.f401e = typedArrayObtainStyledAttributes.getLayoutDimension(3, 0);
        this.f415t = typedArrayObtainStyledAttributes.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static int f(View view, int i2, int i3) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i2, Integer.MIN_VALUE), i3);
        return Math.max(0, i2 - view.getMeasuredWidth());
    }

    public static int g(View view, int i2, int i3, int i4, boolean z2) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i5 = ((i4 - measuredHeight) / 2) + i3;
        if (z2) {
            view.layout(i2 - measuredWidth, i5, i2, measuredHeight + i5);
        } else {
            view.layout(i2, i5, i2 + measuredWidth, measuredHeight + i5);
        }
        return z2 ? -measuredWidth : measuredWidth;
    }

    public final void c(AbstractC0028a abstractC0028a) {
        View view = this.f406k;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.f415t, (ViewGroup) this, false);
            this.f406k = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.f406k);
        }
        View viewFindViewById = this.f406k.findViewById(R.id.action_mode_close_button);
        this.f407l = viewFindViewById;
        viewFindViewById.setOnClickListener(new c(2, abstractC0028a));
        n nVarC = abstractC0028a.c();
        C0069l c0069l = this.f400d;
        if (c0069l != null) {
            c0069l.f();
            C0061h c0061h = c0069l.f1404t;
            if (c0061h != null && c0061h.b()) {
                c0061h.f1207i.dismiss();
            }
        }
        C0069l c0069l2 = new C0069l(getContext());
        this.f400d = c0069l2;
        c0069l2.f1396l = true;
        c0069l2.f1397m = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        nVarC.b(this.f400d, this.b);
        C0069l c0069l3 = this.f400d;
        B b = c0069l3.f1392h;
        if (b == null) {
            B b2 = (B) c0069l3.f1389d.inflate(c0069l3.f, (ViewGroup) this, false);
            c0069l3.f1392h = b2;
            b2.a(c0069l3.f1388c);
            c0069l3.c();
        }
        B b3 = c0069l3.f1392h;
        if (b != b3) {
            ((ActionMenuView) b3).setPresenter(c0069l3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) b3;
        this.f399c = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.f399c, layoutParams);
    }

    public final void d() {
        if (this.f409n == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f409n = linearLayout;
            this.f410o = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f411p = (TextView) this.f409n.findViewById(R.id.action_bar_subtitle);
            int i2 = this.f412q;
            if (i2 != 0) {
                this.f410o.setTextAppearance(getContext(), i2);
            }
            int i3 = this.f413r;
            if (i3 != 0) {
                this.f411p.setTextAppearance(getContext(), i3);
            }
        }
        this.f410o.setText(this.f404i);
        this.f411p.setText(this.f405j);
        boolean zIsEmpty = TextUtils.isEmpty(this.f404i);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.f405j);
        this.f411p.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.f409n.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.f409n.getParent() == null) {
            addView(this.f409n);
        }
    }

    public final void e() {
        removeAllViews();
        this.f408m = null;
        this.f399c = null;
        this.f400d = null;
        View view = this.f407l;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return this.f != null ? this.f398a.b : getVisibility();
    }

    public int getContentHeight() {
        return this.f401e;
    }

    public CharSequence getSubtitle() {
        return this.f405j;
    }

    public CharSequence getTitle() {
        return this.f404i;
    }

    @Override // android.view.View
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public final void setVisibility(int i2) {
        if (i2 != getVisibility()) {
            Q q2 = this.f;
            if (q2 != null) {
                q2.b();
            }
            super.setVisibility(i2);
        }
    }

    public final Q i(int i2, long j2) {
        Q q2 = this.f;
        if (q2 != null) {
            q2.b();
        }
        C0047a c0047a = this.f398a;
        if (i2 != 0) {
            Q qA = K.a(this);
            qA.a(0.0f);
            qA.c(j2);
            c0047a.f1324c.f = qA;
            c0047a.b = i2;
            qA.d(c0047a);
            return qA;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        Q qA2 = K.a(this);
        qA2.a(1.0f);
        qA2.c(j2);
        c0047a.f1324c.f = qA2;
        c0047a.b = i2;
        qA2.d(c0047a);
        return qA2;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, AbstractC0010a.f800a, R.attr.actionBarStyle, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(13, 0));
        typedArrayObtainStyledAttributes.recycle();
        C0069l c0069l = this.f400d;
        if (c0069l != null) {
            Configuration configuration2 = c0069l.b.getResources().getConfiguration();
            int i2 = configuration2.screenWidthDp;
            int i3 = configuration2.screenHeightDp;
            c0069l.f1400p = (configuration2.smallestScreenWidthDp > 600 || i2 > 600 || (i2 > 960 && i3 > 720) || (i2 > 720 && i3 > 960)) ? 5 : (i2 >= 500 || (i2 > 640 && i3 > 480) || (i2 > 480 && i3 > 640)) ? 4 : i2 >= 360 ? 3 : 2;
            n nVar = c0069l.f1388c;
            if (nVar != null) {
                nVar.p(true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0069l c0069l = this.f400d;
        if (c0069l != null) {
            c0069l.f();
            C0061h c0061h = this.f400d.f1404t;
            if (c0061h == null || !c0061h.b()) {
                return;
            }
            c0061h.f1207i.dismiss();
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f403h = false;
        }
        if (!this.f403h) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f403h = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f403h = false;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        boolean z3 = m1.f1408a;
        boolean z4 = getLayoutDirection() == 1;
        int paddingRight = z4 ? (i4 - i2) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i5 - i3) - getPaddingTop()) - getPaddingBottom();
        View view = this.f406k;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f406k.getLayoutParams();
            int i6 = z4 ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i7 = z4 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i8 = z4 ? paddingRight - i6 : paddingRight + i6;
            int iG = g(this.f406k, i8, paddingTop, paddingTop2, z4) + i8;
            paddingRight = z4 ? iG - i7 : iG + i7;
        }
        LinearLayout linearLayout = this.f409n;
        if (linearLayout != null && this.f408m == null && linearLayout.getVisibility() != 8) {
            paddingRight += g(this.f409n, paddingRight, paddingTop, paddingTop2, z4);
        }
        View view2 = this.f408m;
        if (view2 != null) {
            g(view2, paddingRight, paddingTop, paddingTop2, z4);
        }
        int paddingLeft = z4 ? getPaddingLeft() : (i4 - i2) - getPaddingRight();
        ActionMenuView actionMenuView = this.f399c;
        if (actionMenuView != null) {
            g(actionMenuView, paddingLeft, paddingTop, paddingTop2, !z4);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        if (View.MeasureSpec.getMode(i2) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
        }
        if (View.MeasureSpec.getMode(i3) == 0) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
        int size = View.MeasureSpec.getSize(i2);
        int size2 = this.f401e;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i3);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.f406k;
        if (view != null) {
            int iF = f(view, paddingLeft, iMakeMeasureSpec);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f406k.getLayoutParams();
            paddingLeft = iF - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f399c;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = f(this.f399c, paddingLeft, iMakeMeasureSpec);
        }
        LinearLayout linearLayout = this.f409n;
        if (linearLayout != null && this.f408m == null) {
            if (this.f414s) {
                this.f409n.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f409n.getMeasuredWidth();
                boolean z2 = measuredWidth <= paddingLeft;
                if (z2) {
                    paddingLeft -= measuredWidth;
                }
                this.f409n.setVisibility(z2 ? 0 : 8);
            } else {
                paddingLeft = f(linearLayout, paddingLeft, iMakeMeasureSpec);
            }
        }
        View view2 = this.f408m;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i4 = layoutParams.width;
            int i5 = i4 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i4 >= 0) {
                paddingLeft = Math.min(i4, paddingLeft);
            }
            int i6 = layoutParams.height;
            int i7 = i6 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i6 >= 0) {
                iMin = Math.min(i6, iMin);
            }
            this.f408m.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i5), View.MeasureSpec.makeMeasureSpec(iMin, i7));
        }
        if (this.f401e > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i8 = 0;
        for (int i9 = 0; i9 < childCount; i9++) {
            int measuredHeight = getChildAt(i9).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i8) {
                i8 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i8);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f402g = false;
        }
        if (!this.f402g) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f402g = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f402g = false;
        return true;
    }

    public void setContentHeight(int i2) {
        this.f401e = i2;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f408m;
        if (view2 != null) {
            removeView(view2);
        }
        this.f408m = view;
        if (view != null && (linearLayout = this.f409n) != null) {
            removeView(linearLayout);
            this.f409n = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f405j = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.f404i = charSequence;
        d();
        K.i(this, charSequence);
    }

    public void setTitleOptional(boolean z2) {
        if (z2 != this.f414s) {
            requestLayout();
        }
        this.f414s = z2;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
