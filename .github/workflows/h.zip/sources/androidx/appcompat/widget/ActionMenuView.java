package androidx.appcompat.widget;

import C.j;
import F.d;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import e.H;
import h.B;
import h.l;
import h.m;
import h.n;
import h.p;
import h.y;
import i.AbstractC0095y0;
import i.C0061h;
import i.C0067k;
import i.C0069l;
import i.C0073n;
import i.C0093x0;
import i.InterfaceC0071m;
import i.InterfaceC0075o;
import i.m1;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuView extends AbstractC0095y0 implements m, B {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public InterfaceC0075o f445A;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public n f446p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Context f447q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f448r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f449s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public C0069l f450t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public H f451u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public l f452v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f453w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f454x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f455y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f456z;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.f455y = (int) (56.0f * f);
        this.f456z = (int) (f * 4.0f);
        this.f447q = context;
        this.f448r = 0;
    }

    public static C0073n i() {
        C0073n c0073n = new C0073n(-2, -2);
        c0073n.f1410a = false;
        ((LinearLayout.LayoutParams) c0073n).gravity = 16;
        return c0073n;
    }

    public static C0073n j(ViewGroup.LayoutParams layoutParams) {
        C0073n c0073n;
        if (layoutParams == null) {
            return i();
        }
        if (layoutParams instanceof C0073n) {
            C0073n c0073n2 = (C0073n) layoutParams;
            c0073n = new C0073n(c0073n2);
            c0073n.f1410a = c0073n2.f1410a;
        } else {
            c0073n = new C0073n(layoutParams);
        }
        if (((LinearLayout.LayoutParams) c0073n).gravity <= 0) {
            ((LinearLayout.LayoutParams) c0073n).gravity = 16;
        }
        return c0073n;
    }

    @Override // h.B
    public final void a(n nVar) {
        this.f446p = nVar;
    }

    @Override // h.m
    public final boolean b(p pVar) {
        return this.f446p.q(pVar, null, 0);
    }

    @Override // i.AbstractC0095y0, android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0073n;
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    @Override // i.AbstractC0095y0
    /* JADX INFO: renamed from: e */
    public final /* bridge */ /* synthetic */ C0093x0 generateDefaultLayoutParams() {
        return i();
    }

    @Override // i.AbstractC0095y0
    /* JADX INFO: renamed from: f */
    public final C0093x0 generateLayoutParams(AttributeSet attributeSet) {
        return new C0073n(getContext(), attributeSet);
    }

    @Override // i.AbstractC0095y0
    /* JADX INFO: renamed from: g */
    public final /* bridge */ /* synthetic */ C0093x0 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return j(layoutParams);
    }

    @Override // i.AbstractC0095y0, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return i();
    }

    @Override // i.AbstractC0095y0, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return j(layoutParams);
    }

    public Menu getMenu() {
        if (this.f446p == null) {
            Context context = getContext();
            n nVar = new n(context);
            this.f446p = nVar;
            nVar.f1144e = new j(18, this);
            C0069l c0069l = new C0069l(context);
            this.f450t = c0069l;
            c0069l.f1396l = true;
            c0069l.f1397m = true;
            y dVar = this.f451u;
            if (dVar == null) {
                dVar = new d(19);
            }
            c0069l.f1390e = dVar;
            this.f446p.b(c0069l, this.f447q);
            C0069l c0069l2 = this.f450t;
            c0069l2.f1392h = this;
            this.f446p = c0069l2.f1388c;
        }
        return this.f446p;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        C0069l c0069l = this.f450t;
        C0067k c0067k = c0069l.f1393i;
        if (c0067k != null) {
            return c0067k.getDrawable();
        }
        if (c0069l.f1395k) {
            return c0069l.f1394j;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f448r;
    }

    public int getWindowAnimations() {
        return 0;
    }

    public final boolean k(int i2) {
        boolean zB = false;
        if (i2 == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i2 - 1);
        KeyEvent.Callback childAt2 = getChildAt(i2);
        if (i2 < getChildCount() && (childAt instanceof InterfaceC0071m)) {
            zB = ((InterfaceC0071m) childAt).b();
        }
        return (i2 <= 0 || !(childAt2 instanceof InterfaceC0071m)) ? zB : ((InterfaceC0071m) childAt2).a() | zB;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0069l c0069l = this.f450t;
        if (c0069l != null) {
            c0069l.c();
            if (this.f450t.h()) {
                this.f450t.f();
                this.f450t.l();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0069l c0069l = this.f450t;
        if (c0069l != null) {
            c0069l.f();
            C0061h c0061h = c0069l.f1404t;
            if (c0061h == null || !c0061h.b()) {
                return;
            }
            c0061h.f1207i.dismiss();
        }
    }

    @Override // i.AbstractC0095y0, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int width;
        int paddingLeft;
        if (!this.f453w) {
            super.onLayout(z2, i2, i3, i4, i5);
            return;
        }
        int childCount = getChildCount();
        int i6 = (i5 - i3) / 2;
        int dividerWidth = getDividerWidth();
        int i7 = i4 - i2;
        int paddingRight = (i7 - getPaddingRight()) - getPaddingLeft();
        boolean z3 = m1.f1408a;
        boolean z4 = getLayoutDirection() == 1;
        int i8 = 0;
        int i9 = 0;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                C0073n c0073n = (C0073n) childAt.getLayoutParams();
                if (c0073n.f1410a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (k(i10)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (z4) {
                        paddingLeft = getPaddingLeft() + ((LinearLayout.LayoutParams) c0073n).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) c0073n).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i11 = i6 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i11, width, measuredHeight + i11);
                    paddingRight -= measuredWidth;
                    i8 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) c0073n).leftMargin) + ((LinearLayout.LayoutParams) c0073n).rightMargin;
                    k(i10);
                    i9++;
                }
            }
        }
        if (childCount == 1 && i8 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i12 = (i7 / 2) - (measuredWidth2 / 2);
            int i13 = i6 - (measuredHeight2 / 2);
            childAt2.layout(i12, i13, measuredWidth2 + i12, measuredHeight2 + i13);
            return;
        }
        int i14 = i9 - (i8 ^ 1);
        int iMax = Math.max(0, i14 > 0 ? paddingRight / i14 : 0);
        if (z4) {
            int width2 = getWidth() - getPaddingRight();
            for (int i15 = 0; i15 < childCount; i15++) {
                View childAt3 = getChildAt(i15);
                C0073n c0073n2 = (C0073n) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !c0073n2.f1410a) {
                    int i16 = width2 - ((LinearLayout.LayoutParams) c0073n2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i17 = i6 - (measuredHeight3 / 2);
                    childAt3.layout(i16 - measuredWidth3, i17, i16, measuredHeight3 + i17);
                    width2 = i16 - ((measuredWidth3 + ((LinearLayout.LayoutParams) c0073n2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i18 = 0; i18 < childCount; i18++) {
            View childAt4 = getChildAt(i18);
            C0073n c0073n3 = (C0073n) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !c0073n3.f1410a) {
                int i19 = paddingLeft2 + ((LinearLayout.LayoutParams) c0073n3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i20 = i6 - (measuredHeight4 / 2);
                childAt4.layout(i19, i20, i19 + measuredWidth4, measuredHeight4 + i20);
                paddingLeft2 = measuredWidth4 + ((LinearLayout.LayoutParams) c0073n3).rightMargin + iMax + i19;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r11v14 */
    /* JADX WARN: Type inference failed for: r11v15, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r11v17 */
    /* JADX WARN: Type inference failed for: r11v40 */
    @Override // i.AbstractC0095y0, android.view.View
    public final void onMeasure(int i2, int i3) {
        int i4;
        int i5;
        ?? r11;
        int i6;
        int i7;
        n nVar;
        boolean z2 = this.f453w;
        boolean z3 = View.MeasureSpec.getMode(i2) == 1073741824;
        this.f453w = z3;
        if (z2 != z3) {
            this.f454x = 0;
        }
        int size = View.MeasureSpec.getSize(i2);
        if (this.f453w && (nVar = this.f446p) != null && size != this.f454x) {
            this.f454x = size;
            nVar.p(true);
        }
        int childCount = getChildCount();
        if (!this.f453w || childCount <= 0) {
            for (int i8 = 0; i8 < childCount; i8++) {
                C0073n c0073n = (C0073n) getChildAt(i8).getLayoutParams();
                ((LinearLayout.LayoutParams) c0073n).rightMargin = 0;
                ((LinearLayout.LayoutParams) c0073n).leftMargin = 0;
            }
            super.onMeasure(i2, i3);
            return;
        }
        int mode = View.MeasureSpec.getMode(i3);
        int size2 = View.MeasureSpec.getSize(i2);
        int size3 = View.MeasureSpec.getSize(i3);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i3, paddingBottom, -2);
        int i9 = size2 - paddingRight;
        int i10 = this.f455y;
        int i11 = i9 / i10;
        int i12 = i9 % i10;
        if (i11 == 0) {
            setMeasuredDimension(i9, 0);
            return;
        }
        int i13 = (i12 / i11) + i10;
        int childCount2 = getChildCount();
        int iMax = 0;
        int i14 = 0;
        int iMax2 = 0;
        int i15 = 0;
        boolean z4 = false;
        int i16 = 0;
        long j2 = 0;
        while (true) {
            i4 = this.f456z;
            if (i15 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i15);
            int i17 = size3;
            int i18 = paddingBottom;
            if (childAt.getVisibility() == 8) {
                i6 = i13;
            } else {
                boolean z5 = childAt instanceof ActionMenuItemView;
                i14++;
                if (z5) {
                    childAt.setPadding(i4, 0, i4, 0);
                }
                C0073n c0073n2 = (C0073n) childAt.getLayoutParams();
                c0073n2.f = false;
                c0073n2.f1411c = 0;
                c0073n2.b = 0;
                c0073n2.f1412d = false;
                ((LinearLayout.LayoutParams) c0073n2).leftMargin = 0;
                ((LinearLayout.LayoutParams) c0073n2).rightMargin = 0;
                c0073n2.f1413e = z5 && !TextUtils.isEmpty(((ActionMenuItemView) childAt).getText());
                int i19 = c0073n2.f1410a ? 1 : i11;
                C0073n c0073n3 = (C0073n) childAt.getLayoutParams();
                int i20 = i11;
                i6 = i13;
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - i18, View.MeasureSpec.getMode(childMeasureSpec));
                ActionMenuItemView actionMenuItemView = z5 ? (ActionMenuItemView) childAt : null;
                boolean z6 = (actionMenuItemView == null || TextUtils.isEmpty(actionMenuItemView.getText())) ? false : true;
                boolean z7 = z6;
                if (i19 <= 0 || (z6 && i19 < 2)) {
                    i7 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i6 * i19, Integer.MIN_VALUE), iMakeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i7 = measuredWidth / i6;
                    if (measuredWidth % i6 != 0) {
                        i7++;
                    }
                    if (z7 && i7 < 2) {
                        i7 = 2;
                    }
                }
                c0073n3.f1412d = !c0073n3.f1410a && z7;
                c0073n3.b = i7;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i7 * i6, 1073741824), iMakeMeasureSpec);
                iMax2 = Math.max(iMax2, i7);
                if (c0073n2.f1412d) {
                    i16++;
                }
                if (c0073n2.f1410a) {
                    z4 = true;
                }
                i11 = i20 - i7;
                iMax = Math.max(iMax, childAt.getMeasuredHeight());
                if (i7 == 1) {
                    j2 |= (long) (1 << i15);
                }
            }
            i15++;
            size3 = i17;
            paddingBottom = i18;
            i13 = i6;
        }
        int i21 = size3;
        int i22 = i11;
        int i23 = i13;
        boolean z8 = z4 && i14 == 2;
        int i24 = i22;
        boolean z9 = false;
        while (i16 > 0 && i24 > 0) {
            int i25 = Integer.MAX_VALUE;
            long j3 = 0;
            int i26 = 0;
            int i27 = 0;
            while (i27 < childCount2) {
                boolean z10 = z8;
                C0073n c0073n4 = (C0073n) getChildAt(i27).getLayoutParams();
                int i28 = iMax;
                if (c0073n4.f1412d) {
                    int i29 = c0073n4.b;
                    if (i29 < i25) {
                        j3 = 1 << i27;
                        i25 = i29;
                        i26 = 1;
                    } else if (i29 == i25) {
                        j3 |= 1 << i27;
                        i26++;
                    }
                }
                i27++;
                iMax = i28;
                z8 = z10;
            }
            boolean z11 = z8;
            i5 = iMax;
            j2 |= j3;
            if (i26 > i24) {
                break;
            }
            int i30 = i25 + 1;
            int i31 = 0;
            while (i31 < childCount2) {
                View childAt2 = getChildAt(i31);
                C0073n c0073n5 = (C0073n) childAt2.getLayoutParams();
                boolean z12 = z4;
                long j4 = 1 << i31;
                if ((j3 & j4) != 0) {
                    if (z11 && c0073n5.f1413e) {
                        r11 = 1;
                        r11 = 1;
                        if (i24 == 1) {
                            childAt2.setPadding(i4 + i23, 0, i4, 0);
                        }
                    } else {
                        r11 = 1;
                    }
                    c0073n5.b += r11;
                    c0073n5.f = r11;
                    i24--;
                } else if (c0073n5.b == i30) {
                    j2 |= j4;
                }
                i31++;
                z4 = z12;
            }
            iMax = i5;
            z8 = z11;
            z9 = true;
        }
        i5 = iMax;
        boolean z13 = !z4 && i14 == 1;
        if (i24 > 0 && j2 != 0 && (i24 < i14 - 1 || z13 || iMax2 > 1)) {
            float fBitCount = Long.bitCount(j2);
            if (!z13) {
                if ((j2 & 1) != 0 && !((C0073n) getChildAt(0).getLayoutParams()).f1413e) {
                    fBitCount -= 0.5f;
                }
                int i32 = childCount2 - 1;
                if ((j2 & ((long) (1 << i32))) != 0 && !((C0073n) getChildAt(i32).getLayoutParams()).f1413e) {
                    fBitCount -= 0.5f;
                }
            }
            int i33 = fBitCount > 0.0f ? (int) ((i24 * i23) / fBitCount) : 0;
            boolean z14 = z9;
            for (int i34 = 0; i34 < childCount2; i34++) {
                if ((j2 & ((long) (1 << i34))) != 0) {
                    View childAt3 = getChildAt(i34);
                    C0073n c0073n6 = (C0073n) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        c0073n6.f1411c = i33;
                        c0073n6.f = true;
                        if (i34 == 0 && !c0073n6.f1413e) {
                            ((LinearLayout.LayoutParams) c0073n6).leftMargin = (-i33) / 2;
                        }
                        z14 = true;
                    } else if (c0073n6.f1410a) {
                        c0073n6.f1411c = i33;
                        c0073n6.f = true;
                        ((LinearLayout.LayoutParams) c0073n6).rightMargin = (-i33) / 2;
                        z14 = true;
                    } else {
                        if (i34 != 0) {
                            ((LinearLayout.LayoutParams) c0073n6).leftMargin = i33 / 2;
                        }
                        if (i34 != childCount2 - 1) {
                            ((LinearLayout.LayoutParams) c0073n6).rightMargin = i33 / 2;
                        }
                    }
                }
            }
            z9 = z14;
        }
        if (z9) {
            for (int i35 = 0; i35 < childCount2; i35++) {
                View childAt4 = getChildAt(i35);
                C0073n c0073n7 = (C0073n) childAt4.getLayoutParams();
                if (c0073n7.f) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((c0073n7.b * i23) + c0073n7.f1411c, 1073741824), childMeasureSpec);
                }
            }
        }
        setMeasuredDimension(i9, mode != 1073741824 ? i5 : i21);
    }

    public void setExpandedActionViewsExclusive(boolean z2) {
        this.f450t.f1401q = z2;
    }

    public void setOnMenuItemClickListener(InterfaceC0075o interfaceC0075o) {
        this.f445A = interfaceC0075o;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        C0069l c0069l = this.f450t;
        C0067k c0067k = c0069l.f1393i;
        if (c0067k != null) {
            c0067k.setImageDrawable(drawable);
        } else {
            c0069l.f1395k = true;
            c0069l.f1394j = drawable;
        }
    }

    public void setOverflowReserved(boolean z2) {
        this.f449s = z2;
    }

    public void setPopupTheme(int i2) {
        if (this.f448r != i2) {
            this.f448r = i2;
            if (i2 == 0) {
                this.f447q = getContext();
            } else {
                this.f447q = new ContextThemeWrapper(getContext(), i2);
            }
        }
    }

    public void setPresenter(C0069l c0069l) {
        this.f450t = c0069l;
        c0069l.f1392h = this;
        this.f446p = c0069l.f1388c;
    }

    @Override // i.AbstractC0095y0, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0073n(getContext(), attributeSet);
    }
}
