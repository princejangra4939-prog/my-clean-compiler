package androidx.appcompat.widget;

import D.g;
import T.f;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import com.warppaiwarden.tictactoe.R;
import e.N;
import g.C0037j;
import h.n;
import h.y;
import i.C0051c;
import i.C0057f;
import i.C0059g;
import i.C0069l;
import i.InterfaceC0055e;
import i.InterfaceC0070l0;
import i.InterfaceC0072m0;
import i.RunnableC0053d;
import i.Z0;
import i.e1;
import java.util.WeakHashMap;
import r.c;
import y.AbstractC0150A;
import y.AbstractC0180y;
import y.InterfaceC0170n;
import y.InterfaceC0171o;
import y.K;
import y.U;
import y.V;
import y.W;
import y.X;
import y.d0;
import y.f0;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements InterfaceC0070l0, InterfaceC0170n, InterfaceC0171o {

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public static final int[] f416C = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public static final f0 f417D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public static final Rect f418E;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final f f419A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final C0059g f420B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f421a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ContentFrameLayout f422c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ActionBarContainer f423d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public InterfaceC0072m0 f424e;
    public Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f425g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f426h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f427i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f428j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f429k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f430l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Rect f431m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Rect f432n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Rect f433o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final Rect f434p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public f0 f435q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public f0 f436r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public f0 f437s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public f0 f438t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public InterfaceC0055e f439u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public OverScroller f440v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public ViewPropertyAnimator f441w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final C0051c f442x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final RunnableC0053d f443y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final RunnableC0053d f444z;

    static {
        int i2 = Build.VERSION.SDK_INT;
        X w2 = i2 >= 30 ? new W() : i2 >= 29 ? new V() : new U();
        w2.d(c.a(0, 1, 0, 1));
        f417D = w2.b();
        f418E = new Rect();
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.b = 0;
        this.f431m = new Rect();
        this.f432n = new Rect();
        this.f433o = new Rect();
        this.f434p = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        f0 f0Var = f0.b;
        this.f435q = f0Var;
        this.f436r = f0Var;
        this.f437s = f0Var;
        this.f438t = f0Var;
        this.f442x = new C0051c(this);
        this.f443y = new RunnableC0053d(this, 0);
        this.f444z = new RunnableC0053d(this, 1);
        i(context);
        this.f419A = new f();
        C0059g c0059g = new C0059g(context);
        c0059g.setWillNotDraw(true);
        this.f420B = c0059g;
        addView(c0059g);
    }

    public static boolean g(View view, Rect rect, boolean z2) {
        boolean z3;
        C0057f c0057f = (C0057f) view.getLayoutParams();
        int i2 = ((ViewGroup.MarginLayoutParams) c0057f).leftMargin;
        int i3 = rect.left;
        if (i2 != i3) {
            ((ViewGroup.MarginLayoutParams) c0057f).leftMargin = i3;
            z3 = true;
        } else {
            z3 = false;
        }
        int i4 = ((ViewGroup.MarginLayoutParams) c0057f).topMargin;
        int i5 = rect.top;
        if (i4 != i5) {
            ((ViewGroup.MarginLayoutParams) c0057f).topMargin = i5;
            z3 = true;
        }
        int i6 = ((ViewGroup.MarginLayoutParams) c0057f).rightMargin;
        int i7 = rect.right;
        if (i6 != i7) {
            ((ViewGroup.MarginLayoutParams) c0057f).rightMargin = i7;
            z3 = true;
        }
        if (z2) {
            int i8 = ((ViewGroup.MarginLayoutParams) c0057f).bottomMargin;
            int i9 = rect.bottom;
            if (i8 != i9) {
                ((ViewGroup.MarginLayoutParams) c0057f).bottomMargin = i9;
                return true;
            }
        }
        return z3;
    }

    @Override // y.InterfaceC0170n
    public final void a(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // y.InterfaceC0171o
    public final void b(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        c((ViewGroup) view, i2, i3, i4, i5, i6);
    }

    @Override // y.InterfaceC0170n
    public final void c(ViewGroup viewGroup, int i2, int i3, int i4, int i5, int i6) {
        if (i6 == 0) {
            onNestedScroll(viewGroup, i2, i3, i4, i5);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0057f;
    }

    @Override // y.InterfaceC0170n
    public final void d(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int translationY;
        super.draw(canvas);
        if (this.f != null) {
            if (this.f423d.getVisibility() == 0) {
                translationY = (int) (this.f423d.getTranslationY() + this.f423d.getBottom() + 0.5f);
            } else {
                translationY = 0;
            }
            this.f.setBounds(0, translationY, getWidth(), this.f.getIntrinsicHeight() + translationY);
            this.f.draw(canvas);
        }
    }

    @Override // y.InterfaceC0170n
    public final boolean f(View view, View view2, int i2, int i3) {
        return i3 == 0 && onStartNestedScroll(view, view2, i2);
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0057f(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0057f(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f423d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        f fVar = this.f419A;
        return fVar.b | fVar.f182a;
    }

    public CharSequence getTitle() {
        k();
        return ((e1) this.f424e).f1339a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f443y);
        removeCallbacks(this.f444z);
        ViewPropertyAnimator viewPropertyAnimator = this.f441w;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f416C);
        this.f421a = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f440v = new OverScroller(context);
    }

    public final void j(int i2) {
        k();
        if (i2 == 2) {
            ((e1) this.f424e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else if (i2 == 5) {
            ((e1) this.f424e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else {
            if (i2 != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    public final void k() {
        InterfaceC0072m0 wrapper;
        if (this.f422c == null) {
            this.f422c = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.f423d = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback callbackFindViewById = findViewById(R.id.action_bar);
            if (callbackFindViewById instanceof InterfaceC0072m0) {
                wrapper = (InterfaceC0072m0) callbackFindViewById;
            } else {
                if (!(callbackFindViewById instanceof Toolbar)) {
                    throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById.getClass().getSimpleName()));
                }
                wrapper = ((Toolbar) callbackFindViewById).getWrapper();
            }
            this.f424e = wrapper;
        }
    }

    public final void l(n nVar, y yVar) {
        k();
        e1 e1Var = (e1) this.f424e;
        C0069l c0069l = e1Var.f1349m;
        Toolbar toolbar = e1Var.f1339a;
        if (c0069l == null) {
            e1Var.f1349m = new C0069l(toolbar.getContext());
        }
        C0069l c0069l2 = e1Var.f1349m;
        c0069l2.f1390e = yVar;
        if (nVar == null && toolbar.f489a == null) {
            return;
        }
        toolbar.f();
        n nVar2 = toolbar.f489a.f446p;
        if (nVar2 == nVar) {
            return;
        }
        if (nVar2 != null) {
            nVar2.r(toolbar.f480L);
            nVar2.r(toolbar.f481M);
        }
        if (toolbar.f481M == null) {
            toolbar.f481M = new Z0(toolbar);
        }
        c0069l2.f1401q = true;
        if (nVar != null) {
            nVar.b(c0069l2, toolbar.f496j);
            nVar.b(toolbar.f481M, toolbar.f496j);
        } else {
            c0069l2.g(toolbar.f496j, null);
            toolbar.f481M.g(toolbar.f496j, null);
            c0069l2.c();
            toolbar.f481M.c();
        }
        toolbar.f489a.setPopupTheme(toolbar.f497k);
        toolbar.f489a.setPresenter(c0069l2);
        toolbar.f480L = c0069l2;
        toolbar.v();
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k();
        f0 f0VarC = f0.c(windowInsets, this);
        d0 d0Var = f0VarC.f1684a;
        boolean zG = g(this.f423d, new Rect(d0Var.j().f1600a, d0Var.j().b, d0Var.j().f1601c, d0Var.j().f1602d), false);
        WeakHashMap weakHashMap = K.f1647a;
        Rect rect = this.f431m;
        AbstractC0150A.b(this, f0VarC, rect);
        f0 f0VarL = d0Var.l(rect.left, rect.top, rect.right, rect.bottom);
        this.f435q = f0VarL;
        boolean z2 = true;
        if (!this.f436r.equals(f0VarL)) {
            this.f436r = this.f435q;
            zG = true;
        }
        Rect rect2 = this.f432n;
        if (rect2.equals(rect)) {
            z2 = zG;
        } else {
            rect2.set(rect);
        }
        if (z2) {
            requestLayout();
        }
        return d0Var.a().f1684a.c().f1684a.b().b();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        WeakHashMap weakHashMap = K.f1647a;
        AbstractC0180y.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() != 8) {
                C0057f c0057f = (C0057f) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i7 = ((ViewGroup.MarginLayoutParams) c0057f).leftMargin + paddingLeft;
                int i8 = ((ViewGroup.MarginLayoutParams) c0057f).topMargin + paddingTop;
                childAt.layout(i7, i8, measuredWidth + i7, measuredHeight + i8);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x00aa  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onMeasure(int r13, int r14) {
        /*
            Method dump skipped, instruction units count: 403
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z2) {
        if (!this.f427i || !z2) {
            return false;
        }
        this.f440v.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f440v.getFinalY() > this.f423d.getHeight()) {
            h();
            this.f444z.run();
        } else {
            h();
            this.f443y.run();
        }
        this.f428j = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        int i6 = this.f429k + i3;
        this.f429k = i6;
        setActionBarHideOffset(i6);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i2) {
        N n2;
        C0037j c0037j;
        this.f419A.f182a = i2;
        this.f429k = getActionBarHideOffset();
        h();
        InterfaceC0055e interfaceC0055e = this.f439u;
        if (interfaceC0055e == null || (c0037j = (n2 = (N) interfaceC0055e).f924G) == null) {
            return;
        }
        c0037j.a();
        n2.f924G = null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i2) {
        if ((i2 & 2) == 0 || this.f423d.getVisibility() != 0) {
            return false;
        }
        return this.f427i;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.f427i || this.f428j) {
            return;
        }
        if (this.f429k <= this.f423d.getHeight()) {
            h();
            postDelayed(this.f443y, 600L);
        } else {
            h();
            postDelayed(this.f444z, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i2) {
        super.onWindowSystemUiVisibilityChanged(i2);
        k();
        int i3 = this.f430l ^ i2;
        this.f430l = i2;
        boolean z2 = (i2 & 4) == 0;
        boolean z3 = (i2 & 256) != 0;
        InterfaceC0055e interfaceC0055e = this.f439u;
        if (interfaceC0055e != null) {
            N n2 = (N) interfaceC0055e;
            n2.f920C = !z3;
            if (z2 || !z3) {
                if (n2.f921D) {
                    n2.f921D = false;
                    n2.n0(true);
                }
            } else if (!n2.f921D) {
                n2.f921D = true;
                n2.n0(true);
            }
        }
        if ((i3 & 256) == 0 || this.f439u == null) {
            return;
        }
        WeakHashMap weakHashMap = K.f1647a;
        AbstractC0180y.c(this);
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i2) {
        super.onWindowVisibilityChanged(i2);
        this.b = i2;
        InterfaceC0055e interfaceC0055e = this.f439u;
        if (interfaceC0055e != null) {
            ((N) interfaceC0055e).f919B = i2;
        }
    }

    public void setActionBarHideOffset(int i2) {
        h();
        this.f423d.setTranslationY(-Math.max(0, Math.min(i2, this.f423d.getHeight())));
    }

    public void setActionBarVisibilityCallback(InterfaceC0055e interfaceC0055e) {
        this.f439u = interfaceC0055e;
        if (getWindowToken() != null) {
            ((N) this.f439u).f919B = this.b;
            int i2 = this.f430l;
            if (i2 != 0) {
                onWindowSystemUiVisibilityChanged(i2);
                WeakHashMap weakHashMap = K.f1647a;
                AbstractC0180y.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z2) {
        this.f426h = z2;
    }

    public void setHideOnContentScrollEnabled(boolean z2) {
        if (z2 != this.f427i) {
            this.f427i = z2;
            if (z2) {
                return;
            }
            h();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i2) {
        k();
        e1 e1Var = (e1) this.f424e;
        e1Var.f1341d = i2 != 0 ? g.w(e1Var.f1339a.getContext(), i2) : null;
        e1Var.c();
    }

    public void setLogo(int i2) {
        k();
        e1 e1Var = (e1) this.f424e;
        e1Var.f1342e = i2 != 0 ? g.w(e1Var.f1339a.getContext(), i2) : null;
        e1Var.c();
    }

    public void setOverlayMode(boolean z2) {
        this.f425g = z2;
    }

    public void setShowingForActionMode(boolean z2) {
    }

    public void setUiOptions(int i2) {
    }

    @Override // i.InterfaceC0070l0
    public void setWindowCallback(Window.Callback callback) {
        k();
        ((e1) this.f424e).f1347k = callback;
    }

    @Override // i.InterfaceC0070l0
    public void setWindowTitle(CharSequence charSequence) {
        k();
        e1 e1Var = (e1) this.f424e;
        if (e1Var.f1343g) {
            return;
        }
        e1Var.f1344h = charSequence;
        if ((e1Var.b & 8) != 0) {
            Toolbar toolbar = e1Var.f1339a;
            toolbar.setTitle(charSequence);
            if (e1Var.f1343g) {
                K.i(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0057f(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        e1 e1Var = (e1) this.f424e;
        e1Var.f1341d = drawable;
        e1Var.c();
    }

    @Override // y.InterfaceC0170n
    public final void e(ViewGroup viewGroup, int i2, int i3, int[] iArr, int i4) {
    }
}
