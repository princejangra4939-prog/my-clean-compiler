package androidx.appcompat.view.menu;

import D.g;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import d.AbstractC0010a;
import h.AbstractC0042c;
import h.C0041b;
import h.InterfaceC0039A;
import h.m;
import h.n;
import h.p;
import i.C0054d0;
import i.InterfaceC0071m;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuItemView extends C0054d0 implements InterfaceC0039A, View.OnClickListener, InterfaceC0071m {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public p f364h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public CharSequence f365i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Drawable f366j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public m f367k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public C0041b f368l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public AbstractC0042c f369m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f370n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f371o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f372p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f373q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f374r;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f370n = h();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0010a.f801c, 0, 0);
        this.f372p = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f374r = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f373q = -1;
        setSaveEnabled(false);
    }

    @Override // i.InterfaceC0071m
    public final boolean a() {
        return !TextUtils.isEmpty(getText()) && this.f364h.getIcon() == null;
    }

    @Override // i.InterfaceC0071m
    public final boolean b() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // h.InterfaceC0039A
    public final void c(p pVar) {
        this.f364h = pVar;
        setIcon(pVar.getIcon());
        setTitle(pVar.getTitleCondensed());
        setId(pVar.f1168a);
        setVisibility(pVar.isVisible() ? 0 : 8);
        setEnabled(pVar.isEnabled());
        if (pVar.hasSubMenu() && this.f368l == null) {
            this.f368l = new C0041b(this);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // h.InterfaceC0039A
    public p getItemData() {
        return this.f364h;
    }

    public final boolean h() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i2 = configuration.screenWidthDp;
        int i3 = configuration.screenHeightDp;
        if (i2 < 480) {
            return (i2 >= 640 && i3 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    public final void i() {
        boolean z2 = true;
        boolean z3 = !TextUtils.isEmpty(this.f365i);
        if (this.f366j != null && ((this.f364h.f1190y & 4) != 4 || (!this.f370n && !this.f371o))) {
            z2 = false;
        }
        boolean z4 = z3 & z2;
        setText(z4 ? this.f365i : null);
        CharSequence charSequence = this.f364h.f1182q;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z4 ? null : this.f364h.f1171e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f364h.f1183r;
        if (TextUtils.isEmpty(charSequence2)) {
            g.f0(this, z4 ? null : this.f364h.f1171e);
        } else {
            g.f0(this, charSequence2);
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        m mVar = this.f367k;
        if (mVar != null) {
            mVar.b(this.f364h);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f370n = h();
        i();
    }

    @Override // i.C0054d0, android.widget.TextView, android.view.View
    public final void onMeasure(int i2, int i3) {
        int i4;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i4 = this.f373q) >= 0) {
            super.setPadding(i4, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i2, i3);
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        int measuredWidth = getMeasuredWidth();
        int i5 = this.f372p;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i5) : i5;
        if (mode != 1073741824 && i5 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i3);
        }
        if (!zIsEmpty || this.f366j == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f366j.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        C0041b c0041b;
        if (this.f364h.hasSubMenu() && (c0041b = this.f368l) != null && c0041b.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z2) {
    }

    public void setChecked(boolean z2) {
    }

    public void setExpandedFormat(boolean z2) {
        if (this.f371o != z2) {
            this.f371o = z2;
            p pVar = this.f364h;
            if (pVar != null) {
                n nVar = pVar.f1179n;
                nVar.f1149k = true;
                nVar.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f366j = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i2 = this.f374r;
            if (intrinsicWidth > i2) {
                intrinsicHeight = (int) (intrinsicHeight * (i2 / intrinsicWidth));
                intrinsicWidth = i2;
            }
            if (intrinsicHeight > i2) {
                intrinsicWidth = (int) (intrinsicWidth * (i2 / intrinsicHeight));
            } else {
                i2 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i2);
        }
        setCompoundDrawables(drawable, null, null, null);
        i();
    }

    public void setItemInvoker(m mVar) {
        this.f367k = mVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i2, int i3, int i4, int i5) {
        this.f373q = i2;
        super.setPadding(i2, i3, i4, i5);
    }

    public void setPopupCallback(AbstractC0042c abstractC0042c) {
        this.f369m = abstractC0042c;
    }

    public void setTitle(CharSequence charSequence) {
        this.f365i = charSequence;
        i();
    }
}
