package androidx.appcompat.view.menu;

import C.h;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import h.B;
import h.m;
import h.n;
import h.p;

/* JADX INFO: loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements m, B, AdapterView.OnItemClickListener {
    public static final int[] b = {R.attr.background, R.attr.divider};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n f375a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        h hVarM = h.m(context, attributeSet, b, R.attr.listViewStyle);
        TypedArray typedArray = (TypedArray) hVarM.b;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(hVarM.i(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(hVarM.i(1));
        }
        hVarM.r();
    }

    @Override // h.B
    public final void a(n nVar) {
        this.f375a = nVar;
    }

    @Override // h.m
    public final boolean b(p pVar) {
        return this.f375a.q(pVar, null, 0);
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        b((p) getAdapter().getItem(i2));
    }
}
