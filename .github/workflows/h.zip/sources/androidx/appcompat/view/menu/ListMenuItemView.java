package androidx.appcompat.view.menu;

import C.h;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import com.warppaiwarden.tictactoe.R;
import d.AbstractC0010a;
import h.InterfaceC0039A;
import h.p;

/* JADX INFO: loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements InterfaceC0039A, AbsListView.SelectionBoundsAdjuster {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public p f376a;
    public ImageView b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public RadioButton f377c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TextView f378d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public CheckBox f379e;
    public TextView f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ImageView f380g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ImageView f381h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public LinearLayout f382i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Drawable f383j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int f384k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final Context f385l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f386m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final Drawable f387n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final boolean f388o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public LayoutInflater f389p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f390q;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        h hVarM = h.m(getContext(), attributeSet, AbstractC0010a.f815r, R.attr.listMenuViewStyle);
        this.f383j = hVarM.i(5);
        TypedArray typedArray = (TypedArray) hVarM.b;
        this.f384k = typedArray.getResourceId(1, -1);
        this.f386m = typedArray.getBoolean(7, false);
        this.f385l = context;
        this.f387n = hVarM.i(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.f388o = typedArrayObtainStyledAttributes.hasValue(0);
        hVarM.r();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f389p == null) {
            this.f389p = LayoutInflater.from(getContext());
        }
        return this.f389p;
    }

    private void setSubMenuArrowVisible(boolean z2) {
        ImageView imageView = this.f380g;
        if (imageView != null) {
            imageView.setVisibility(z2 ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f381h;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f381h.getLayoutParams();
        rect.top = this.f381h.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x005a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x005e  */
    @Override // h.InterfaceC0039A
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void c(h.p r11) {
        /*
            Method dump skipped, instruction units count: 325
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ListMenuItemView.c(h.p):void");
    }

    @Override // h.InterfaceC0039A
    public p getItemData() {
        return this.f376a;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f383j);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f378d = textView;
        int i2 = this.f384k;
        if (i2 != -1) {
            textView.setTextAppearance(this.f385l, i2);
        }
        this.f = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f380g = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f387n);
        }
        this.f381h = (ImageView) findViewById(R.id.group_divider);
        this.f382i = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i2, int i3) {
        if (this.b != null && this.f386m) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.b.getLayoutParams();
            int i4 = layoutParams.height;
            if (i4 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i4;
            }
        }
        super.onMeasure(i2, i3);
    }

    public void setCheckable(boolean z2) {
        CompoundButton compoundButton;
        View view;
        if (!z2 && this.f377c == null && this.f379e == null) {
            return;
        }
        if ((this.f376a.f1189x & 4) != 0) {
            if (this.f377c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f377c = radioButton;
                LinearLayout linearLayout = this.f382i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f377c;
            view = this.f379e;
        } else {
            if (this.f379e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f379e = checkBox;
                LinearLayout linearLayout2 = this.f382i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f379e;
            view = this.f377c;
        }
        if (z2) {
            compoundButton.setChecked(this.f376a.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.f379e;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f377c;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z2) {
        CompoundButton compoundButton;
        if ((this.f376a.f1189x & 4) != 0) {
            if (this.f377c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f377c = radioButton;
                LinearLayout linearLayout = this.f382i;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f377c;
        } else {
            if (this.f379e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f379e = checkBox;
                LinearLayout linearLayout2 = this.f382i;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f379e;
        }
        compoundButton.setChecked(z2);
    }

    public void setForceShowIcon(boolean z2) {
        this.f390q = z2;
        this.f386m = z2;
    }

    public void setGroupDividerEnabled(boolean z2) {
        ImageView imageView = this.f381h;
        if (imageView != null) {
            imageView.setVisibility((this.f388o || !z2) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        this.f376a.f1179n.getClass();
        boolean z2 = this.f390q;
        if (z2 || this.f386m) {
            ImageView imageView = this.b;
            if (imageView == null && drawable == null && !this.f386m) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.b = imageView2;
                LinearLayout linearLayout = this.f382i;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f386m) {
                this.b.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.b;
            if (!z2) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.b.getVisibility() != 0) {
                this.b.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f378d.getVisibility() != 8) {
                this.f378d.setVisibility(8);
            }
        } else {
            this.f378d.setText(charSequence);
            if (this.f378d.getVisibility() != 0) {
                this.f378d.setVisibility(0);
            }
        }
    }
}
