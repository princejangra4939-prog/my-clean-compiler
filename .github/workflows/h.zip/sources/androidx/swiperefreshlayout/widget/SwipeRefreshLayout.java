package androidx.swiperefreshlayout.widget;

import P.a;
import P.d;
import P.e;
import P.f;
import P.g;
import P.h;
import P.i;
import P.j;
import P.k;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.DecelerateInterpolator;
import android.widget.ListView;
import java.util.WeakHashMap;
import p.AbstractC0123b;
import y.AbstractC0150A;
import y.C0169m;
import y.InterfaceC0170n;
import y.InterfaceC0171o;
import y.K;

/* JADX INFO: loaded from: classes.dex */
public class SwipeRefreshLayout extends ViewGroup implements InterfaceC0171o, InterfaceC0170n {

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public static final int[] f750K = {R.attr.enabled};

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public g f751A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public g f752B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public h f753C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public h f754D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f755E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public int f756F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public boolean f757G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final f f758H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final g f759I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final g f760J;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public View f761a;
    public j b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f762c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f763d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f764e;
    public float f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final T.f f765g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final C0169m f766h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int[] f767i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int[] f768j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final int[] f769k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f770l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f771m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f772n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public float f773o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public float f774p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f775q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f776r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final DecelerateInterpolator f777s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final a f778t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f779u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f780v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f781w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f782x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f783y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final e f784z;

    public SwipeRefreshLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f762c = false;
        this.f764e = -1.0f;
        this.f767i = new int[2];
        this.f768j = new int[2];
        this.f769k = new int[2];
        this.f776r = -1;
        this.f779u = -1;
        this.f758H = new f(this, 0);
        this.f759I = new g(this, 2);
        this.f760J = new g(this, 3);
        this.f763d = ViewConfiguration.get(context).getScaledTouchSlop();
        this.f771m = getResources().getInteger(R.integer.config_mediumAnimTime);
        setWillNotDraw(false);
        this.f777s = new DecelerateInterpolator(2.0f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.f756F = (int) (displayMetrics.density * 40.0f);
        a aVar = new a(getContext());
        float f = aVar.getContext().getResources().getDisplayMetrics().density;
        TypedArray typedArrayObtainStyledAttributes = aVar.getContext().obtainStyledAttributes(O.a.f125a);
        aVar.b = typedArrayObtainStyledAttributes.getColor(0, -328966);
        typedArrayObtainStyledAttributes.recycle();
        ShapeDrawable shapeDrawable = new ShapeDrawable(new OvalShape());
        WeakHashMap weakHashMap = K.f1647a;
        AbstractC0150A.s(aVar, f * 4.0f);
        shapeDrawable.getPaint().setColor(aVar.b);
        aVar.setBackground(shapeDrawable);
        this.f778t = aVar;
        e eVar = new e(getContext());
        this.f784z = eVar;
        eVar.c(1);
        this.f778t.setImageDrawable(this.f784z);
        this.f778t.setVisibility(8);
        addView(this.f778t);
        setChildrenDrawingOrderEnabled(true);
        int i2 = (int) (displayMetrics.density * 64.0f);
        this.f782x = i2;
        this.f764e = i2;
        this.f765g = new T.f();
        this.f766h = new C0169m(this);
        setNestedScrollingEnabled(true);
        int i3 = -this.f756F;
        this.f772n = i3;
        this.f781w = i3;
        k(1.0f);
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, f750K);
        setEnabled(typedArrayObtainStyledAttributes2.getBoolean(0, true));
        typedArrayObtainStyledAttributes2.recycle();
    }

    private void setColorViewAlpha(int i2) {
        this.f778t.getBackground().setAlpha(i2);
        this.f784z.setAlpha(i2);
    }

    @Override // y.InterfaceC0170n
    public final void a(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            onNestedScrollAccepted(view, view2, i2);
        }
    }

    @Override // y.InterfaceC0171o
    public final void b(View view, int i2, int i3, int i4, int i5, int i6, int[] iArr) {
        if (i6 != 0) {
            return;
        }
        int i7 = iArr[1];
        if (i6 == 0) {
            this.f766h.d(i2, i3, i4, i5, this.f768j, i6, iArr);
        }
        int i8 = i5 - (iArr[1] - i7);
        if ((i8 == 0 ? i5 + this.f768j[1] : i8) >= 0 || g()) {
            return;
        }
        float fAbs = this.f + Math.abs(r14);
        this.f = fAbs;
        j(fAbs);
        iArr[1] = iArr[1] + i8;
    }

    @Override // y.InterfaceC0170n
    public final void c(ViewGroup viewGroup, int i2, int i3, int i4, int i5, int i6) {
        b(viewGroup, i2, i3, i4, i5, i6, this.f769k);
    }

    @Override // y.InterfaceC0170n
    public final void d(View view, int i2) {
        if (i2 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f, float f2, boolean z2) {
        return this.f766h.a(f, f2, z2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f, float f2) {
        return this.f766h.b(f, f2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return this.f766h.c(i2, i3, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return this.f766h.d(i2, i3, i4, i5, iArr, 0, null);
    }

    @Override // y.InterfaceC0170n
    public final void e(ViewGroup viewGroup, int i2, int i3, int[] iArr, int i4) {
        if (i4 == 0) {
            onNestedPreScroll(viewGroup, i2, i3, iArr);
        }
    }

    @Override // y.InterfaceC0170n
    public final boolean f(View view, View view2, int i2, int i3) {
        if (i3 == 0) {
            return onStartNestedScroll(view, view2, i2);
        }
        return false;
    }

    public final boolean g() {
        View view = this.f761a;
        return view instanceof ListView ? ((ListView) view).canScrollList(-1) : view.canScrollVertically(-1);
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i2, int i3) {
        int i4 = this.f779u;
        return i4 < 0 ? i3 : i3 == i2 + (-1) ? i4 : i3 >= i4 ? i3 + 1 : i3;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        T.f fVar = this.f765g;
        return fVar.b | fVar.f182a;
    }

    public int getProgressCircleDiameter() {
        return this.f756F;
    }

    public int getProgressViewEndOffset() {
        return this.f782x;
    }

    public int getProgressViewStartOffset() {
        return this.f781w;
    }

    public final void h() {
        if (this.f761a == null) {
            for (int i2 = 0; i2 < getChildCount(); i2++) {
                View childAt = getChildAt(i2);
                if (!childAt.equals(this.f778t)) {
                    this.f761a = childAt;
                    return;
                }
            }
        }
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f766h.f(0);
    }

    public final void i(float f) {
        if (f > this.f764e) {
            m(true, true);
            return;
        }
        this.f762c = false;
        e eVar = this.f784z;
        d dVar = eVar.f151a;
        dVar.f132e = 0.0f;
        dVar.f = 0.0f;
        eVar.invalidateSelf();
        f fVar = new f(this, 1);
        this.f780v = this.f772n;
        g gVar = this.f760J;
        gVar.reset();
        gVar.setDuration(200L);
        gVar.setInterpolator(this.f777s);
        a aVar = this.f778t;
        aVar.f126a = fVar;
        aVar.clearAnimation();
        this.f778t.startAnimation(gVar);
        e eVar2 = this.f784z;
        d dVar2 = eVar2.f151a;
        if (dVar2.f140n) {
            dVar2.f140n = false;
        }
        eVar2.invalidateSelf();
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f766h.f1695d;
    }

    public final void j(float f) {
        h hVar;
        h hVar2;
        e eVar = this.f784z;
        d dVar = eVar.f151a;
        if (!dVar.f140n) {
            dVar.f140n = true;
        }
        eVar.invalidateSelf();
        float fMin = Math.min(1.0f, Math.abs(f / this.f764e));
        float fMax = (((float) Math.max(((double) fMin) - 0.4d, 0.0d)) * 5.0f) / 3.0f;
        float fAbs = Math.abs(f) - this.f764e;
        int i2 = this.f783y;
        if (i2 <= 0) {
            i2 = this.f782x;
        }
        float f2 = i2;
        double dMax = Math.max(0.0f, Math.min(fAbs, f2 * 2.0f) / f2) / 4.0f;
        float fPow = ((float) (dMax - Math.pow(dMax, 2.0d))) * 2.0f;
        int i3 = this.f781w + ((int) ((f2 * fMin) + (f2 * fPow * 2.0f)));
        if (this.f778t.getVisibility() != 0) {
            this.f778t.setVisibility(0);
        }
        this.f778t.setScaleX(1.0f);
        this.f778t.setScaleY(1.0f);
        if (f < this.f764e) {
            if (this.f784z.f151a.f146t > 76 && ((hVar2 = this.f753C) == null || !hVar2.hasStarted() || hVar2.hasEnded())) {
                h hVar3 = new h(this, this.f784z.f151a.f146t, 76);
                hVar3.setDuration(300L);
                a aVar = this.f778t;
                aVar.f126a = null;
                aVar.clearAnimation();
                this.f778t.startAnimation(hVar3);
                this.f753C = hVar3;
            }
        } else if (this.f784z.f151a.f146t < 255 && ((hVar = this.f754D) == null || !hVar.hasStarted() || hVar.hasEnded())) {
            h hVar4 = new h(this, this.f784z.f151a.f146t, 255);
            hVar4.setDuration(300L);
            a aVar2 = this.f778t;
            aVar2.f126a = null;
            aVar2.clearAnimation();
            this.f778t.startAnimation(hVar4);
            this.f754D = hVar4;
        }
        e eVar2 = this.f784z;
        float fMin2 = Math.min(0.8f, fMax * 0.8f);
        d dVar2 = eVar2.f151a;
        dVar2.f132e = 0.0f;
        dVar2.f = fMin2;
        eVar2.invalidateSelf();
        e eVar3 = this.f784z;
        float fMin3 = Math.min(1.0f, fMax);
        d dVar3 = eVar3.f151a;
        if (fMin3 != dVar3.f142p) {
            dVar3.f142p = fMin3;
        }
        eVar3.invalidateSelf();
        e eVar4 = this.f784z;
        eVar4.f151a.f133g = ((fPow * 2.0f) + ((fMax * 0.4f) - 0.25f)) * 0.5f;
        eVar4.invalidateSelf();
        setTargetOffsetTopAndBottom(i3 - this.f772n);
    }

    public final void k(float f) {
        setTargetOffsetTopAndBottom((this.f780v + ((int) ((this.f781w - r0) * f))) - this.f778t.getTop());
    }

    public final void l() {
        this.f778t.clearAnimation();
        this.f784z.stop();
        this.f778t.setVisibility(8);
        setColorViewAlpha(255);
        setTargetOffsetTopAndBottom(this.f781w - this.f772n);
        this.f772n = this.f778t.getTop();
    }

    public final void m(boolean z2, boolean z3) {
        if (this.f762c != z2) {
            this.f755E = z3;
            h();
            this.f762c = z2;
            f fVar = this.f758H;
            if (!z2) {
                g gVar = new g(this, 1);
                this.f752B = gVar;
                gVar.setDuration(150L);
                a aVar = this.f778t;
                aVar.f126a = fVar;
                aVar.clearAnimation();
                this.f778t.startAnimation(this.f752B);
                return;
            }
            this.f780v = this.f772n;
            g gVar2 = this.f759I;
            gVar2.reset();
            gVar2.setDuration(200L);
            gVar2.setInterpolator(this.f777s);
            if (fVar != null) {
                this.f778t.f126a = fVar;
            }
            this.f778t.clearAnimation();
            this.f778t.startAnimation(gVar2);
        }
    }

    public final void n(float f) {
        float f2 = this.f774p;
        float f3 = f - f2;
        float f4 = this.f763d;
        if (f3 <= f4 || this.f775q) {
            return;
        }
        this.f773o = f2 + f4;
        this.f775q = true;
        this.f784z.setAlpha(76);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        l();
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x005f  */
    @Override // android.view.ViewGroup
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onInterceptTouchEvent(android.view.MotionEvent r6) {
        /*
            r5 = this;
            r5.h()
            int r0 = r6.getActionMasked()
            boolean r1 = r5.isEnabled()
            r2 = 0
            if (r1 == 0) goto L88
            boolean r1 = r5.g()
            if (r1 != 0) goto L88
            boolean r1 = r5.f762c
            if (r1 != 0) goto L88
            boolean r1 = r5.f770l
            if (r1 == 0) goto L1e
            goto L88
        L1e:
            if (r0 == 0) goto L64
            r1 = 1
            r3 = -1
            if (r0 == r1) goto L5f
            r4 = 2
            if (r0 == r4) goto L44
            r4 = 3
            if (r0 == r4) goto L5f
            r3 = 6
            if (r0 == r3) goto L2e
            goto L85
        L2e:
            int r0 = r6.getActionIndex()
            int r3 = r6.getPointerId(r0)
            int r4 = r5.f776r
            if (r3 != r4) goto L85
            if (r0 != 0) goto L3d
            r2 = r1
        L3d:
            int r6 = r6.getPointerId(r2)
            r5.f776r = r6
            goto L85
        L44:
            int r0 = r5.f776r
            if (r0 != r3) goto L50
            java.lang.String r6 = "SwipeRefreshLayout"
            java.lang.String r0 = "Got ACTION_MOVE event but don't have an active pointer id."
            android.util.Log.e(r6, r0)
            return r2
        L50:
            int r0 = r6.findPointerIndex(r0)
            if (r0 >= 0) goto L57
            goto L88
        L57:
            float r6 = r6.getY(r0)
            r5.n(r6)
            goto L85
        L5f:
            r5.f775q = r2
            r5.f776r = r3
            goto L85
        L64:
            P.a r0 = r5.f778t
            int r0 = r0.getTop()
            int r1 = r5.f781w
            int r1 = r1 - r0
            r5.setTargetOffsetTopAndBottom(r1)
            int r0 = r6.getPointerId(r2)
            r5.f776r = r0
            r5.f775q = r2
            int r0 = r6.findPointerIndex(r0)
            if (r0 >= 0) goto L7f
            goto L88
        L7f:
            float r6 = r6.getY(r0)
            r5.f774p = r6
        L85:
            boolean r6 = r5.f775q
            return r6
        L88:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.swiperefreshlayout.widget.SwipeRefreshLayout.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() == 0) {
            return;
        }
        if (this.f761a == null) {
            h();
        }
        View view = this.f761a;
        if (view == null) {
            return;
        }
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
        int measuredWidth2 = this.f778t.getMeasuredWidth();
        int measuredHeight2 = this.f778t.getMeasuredHeight();
        int i6 = measuredWidth / 2;
        int i7 = measuredWidth2 / 2;
        int i8 = this.f772n;
        this.f778t.layout(i6 - i7, i8, i6 + i7, measuredHeight2 + i8);
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        super.onMeasure(i2, i3);
        if (this.f761a == null) {
            h();
        }
        View view = this.f761a;
        if (view == null) {
            return;
        }
        view.measure(View.MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
        this.f778t.measure(View.MeasureSpec.makeMeasureSpec(this.f756F, 1073741824), View.MeasureSpec.makeMeasureSpec(this.f756F, 1073741824));
        this.f779u = -1;
        for (int i4 = 0; i4 < getChildCount(); i4++) {
            if (getChildAt(i4) == this.f778t) {
                this.f779u = i4;
                return;
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f, float f2, boolean z2) {
        return this.f766h.a(f, f2, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f, float f2) {
        return this.f766h.b(f, f2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i2, int i3, int[] iArr) {
        if (i3 > 0) {
            float f = this.f;
            if (f > 0.0f) {
                float f2 = i3;
                if (f2 > f) {
                    iArr[1] = (int) f;
                    this.f = 0.0f;
                } else {
                    this.f = f - f2;
                    iArr[1] = i3;
                }
                j(this.f);
            }
        }
        int i4 = i2 - iArr[0];
        int i5 = i3 - iArr[1];
        int[] iArr2 = this.f767i;
        if (dispatchNestedPreScroll(i4, i5, iArr2, null)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr[1] + iArr2[1];
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i2, int i3, int i4, int i5) {
        b(view, i2, i3, i4, i5, 0, this.f769k);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i2) {
        this.f765g.f182a = i2;
        startNestedScroll(i2 & 2);
        this.f = 0.0f;
        this.f770l = true;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        k kVar = (k) parcelable;
        super.onRestoreInstanceState(kVar.getSuperState());
        setRefreshing(kVar.f159a);
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        return new k(super.onSaveInstanceState(), this.f762c);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i2) {
        return (!isEnabled() || this.f762c || (i2 & 2) == 0) ? false : true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        this.f765g.f182a = 0;
        this.f770l = false;
        float f = this.f;
        if (f > 0.0f) {
            i(f);
            this.f = 0.0f;
        }
        stopNestedScroll();
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (isEnabled() && !g() && !this.f762c && !this.f770l) {
            if (actionMasked == 0) {
                this.f776r = motionEvent.getPointerId(0);
                this.f775q = false;
                return true;
            }
            if (actionMasked == 1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f776r);
                if (iFindPointerIndex < 0) {
                    Log.e("SwipeRefreshLayout", "Got ACTION_UP event but don't have an active pointer id.");
                    return false;
                }
                if (this.f775q) {
                    float y2 = (motionEvent.getY(iFindPointerIndex) - this.f773o) * 0.5f;
                    this.f775q = false;
                    i(y2);
                }
                this.f776r = -1;
                return false;
            }
            if (actionMasked == 2) {
                int iFindPointerIndex2 = motionEvent.findPointerIndex(this.f776r);
                if (iFindPointerIndex2 < 0) {
                    Log.e("SwipeRefreshLayout", "Got ACTION_MOVE event but have an invalid active pointer id.");
                    return false;
                }
                float y3 = motionEvent.getY(iFindPointerIndex2);
                n(y3);
                if (this.f775q) {
                    float f = (y3 - this.f773o) * 0.5f;
                    if (f > 0.0f) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                        j(f);
                    }
                }
                return true;
            }
            if (actionMasked != 3) {
                if (actionMasked != 5) {
                    if (actionMasked == 6) {
                        int actionIndex = motionEvent.getActionIndex();
                        if (motionEvent.getPointerId(actionIndex) == this.f776r) {
                            this.f776r = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
                            return true;
                        }
                    }
                    return true;
                }
                int actionIndex2 = motionEvent.getActionIndex();
                if (actionIndex2 < 0) {
                    Log.e("SwipeRefreshLayout", "Got ACTION_POINTER_DOWN event but have an invalid action index.");
                    return false;
                }
                this.f776r = motionEvent.getPointerId(actionIndex2);
                return true;
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z2) {
        ViewParent parent;
        View view = this.f761a;
        if (view != null) {
            WeakHashMap weakHashMap = K.f1647a;
            if (!AbstractC0150A.p(view)) {
                if (this.f757G || (parent = getParent()) == null) {
                    return;
                }
                parent.requestDisallowInterceptTouchEvent(z2);
                return;
            }
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    public void setAnimationProgress(float f) {
        this.f778t.setScaleX(f);
        this.f778t.setScaleY(f);
    }

    @Deprecated
    public void setColorScheme(int... iArr) {
        setColorSchemeResources(iArr);
    }

    public void setColorSchemeColors(int... iArr) {
        h();
        e eVar = this.f784z;
        d dVar = eVar.f151a;
        dVar.f135i = iArr;
        dVar.a(0);
        dVar.a(0);
        eVar.invalidateSelf();
    }

    public void setColorSchemeResources(int... iArr) {
        Context context = getContext();
        int[] iArr2 = new int[iArr.length];
        for (int i2 = 0; i2 < iArr.length; i2++) {
            iArr2[i2] = AbstractC0123b.a(context, iArr[i2]);
        }
        setColorSchemeColors(iArr2);
    }

    public void setDistanceToTriggerSync(int i2) {
        this.f764e = i2;
    }

    @Override // android.view.View
    public void setEnabled(boolean z2) {
        super.setEnabled(z2);
        if (z2) {
            return;
        }
        l();
    }

    @Deprecated
    public void setLegacyRequestDisallowInterceptTouchEventEnabled(boolean z2) {
        this.f757G = z2;
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        C0169m c0169m = this.f766h;
        if (c0169m.f1695d) {
            WeakHashMap weakHashMap = K.f1647a;
            AbstractC0150A.z(c0169m.f1694c);
        }
        c0169m.f1695d = z2;
    }

    public void setOnRefreshListener(j jVar) {
        this.b = jVar;
    }

    @Deprecated
    public void setProgressBackgroundColor(int i2) {
        setProgressBackgroundColorSchemeResource(i2);
    }

    public void setProgressBackgroundColorSchemeColor(int i2) {
        this.f778t.setBackgroundColor(i2);
    }

    public void setProgressBackgroundColorSchemeResource(int i2) {
        setProgressBackgroundColorSchemeColor(AbstractC0123b.a(getContext(), i2));
    }

    public void setRefreshing(boolean z2) {
        if (!z2 || this.f762c == z2) {
            m(z2, false);
            return;
        }
        this.f762c = z2;
        setTargetOffsetTopAndBottom((this.f782x + this.f781w) - this.f772n);
        this.f755E = false;
        f fVar = this.f758H;
        this.f778t.setVisibility(0);
        this.f784z.setAlpha(255);
        g gVar = new g(this, 0);
        this.f751A = gVar;
        gVar.setDuration(this.f771m);
        if (fVar != null) {
            this.f778t.f126a = fVar;
        }
        this.f778t.clearAnimation();
        this.f778t.startAnimation(this.f751A);
    }

    public void setSize(int i2) {
        if (i2 == 0 || i2 == 1) {
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            if (i2 == 0) {
                this.f756F = (int) (displayMetrics.density * 56.0f);
            } else {
                this.f756F = (int) (displayMetrics.density * 40.0f);
            }
            this.f778t.setImageDrawable(null);
            this.f784z.c(i2);
            this.f778t.setImageDrawable(this.f784z);
        }
    }

    public void setSlingshotDistance(int i2) {
        this.f783y = i2;
    }

    public void setTargetOffsetTopAndBottom(int i2) {
        a aVar = this.f778t;
        aVar.bringToFront();
        WeakHashMap weakHashMap = K.f1647a;
        aVar.offsetTopAndBottom(i2);
        this.f772n = aVar.getTop();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i2) {
        return this.f766h.g(i2, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        this.f766h.h(0);
    }

    public void setOnChildScrollUpCallback(i iVar) {
    }
}
