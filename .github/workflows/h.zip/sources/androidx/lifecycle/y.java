package androidx.lifecycle;

import android.app.Activity;
import android.app.FragmentManager;
import android.os.Build;
import androidx.lifecycle.A;

/* JADX INFO: loaded from: classes.dex */
public abstract class y {
    /* JADX WARN: Multi-variable type inference failed */
    public static void a(Activity activity, k kVar) {
        s sVarC;
        e0.c.e(kVar, "event");
        if (!(activity instanceof q) || (sVarC = ((q) activity).c()) == null) {
            return;
        }
        sVarC.d(kVar);
    }

    public static void b(Activity activity) {
        if (Build.VERSION.SDK_INT >= 29) {
            A.a.Companion.getClass();
            activity.registerActivityLifecycleCallbacks(new A.a());
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new A(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }
}
