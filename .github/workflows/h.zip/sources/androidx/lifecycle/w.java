package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class w extends AbstractC0006f {
    final /* synthetic */ x this$0;

    public static final class a extends AbstractC0006f {
        final /* synthetic */ x this$0;

        public a(x xVar) {
            this.this$0 = xVar;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            e0.c.e(activity, "activity");
            this.this$0.b();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            e0.c.e(activity, "activity");
            x xVar = this.this$0;
            int i2 = xVar.f743a + 1;
            xVar.f743a = i2;
            if (i2 == 1 && xVar.f745d) {
                xVar.f.d(k.ON_START);
                xVar.f745d = false;
            }
        }
    }

    public w(x xVar) {
        this.this$0 = xVar;
    }

    @Override // androidx.lifecycle.AbstractC0006f, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        e0.c.e(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i2 = A.b;
            Fragment fragmentFindFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            e0.c.c(fragmentFindFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((A) fragmentFindFragmentByTag).f708a = this.this$0.f748h;
        }
    }

    @Override // androidx.lifecycle.AbstractC0006f, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        e0.c.e(activity, "activity");
        x xVar = this.this$0;
        int i2 = xVar.b - 1;
        xVar.b = i2;
        if (i2 == 0) {
            Handler handler = xVar.f746e;
            e0.c.b(handler);
            handler.postDelayed(xVar.f747g, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        e0.c.e(activity, "activity");
        v.a(activity, new a(this.this$0));
    }

    @Override // androidx.lifecycle.AbstractC0006f, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        e0.c.e(activity, "activity");
        x xVar = this.this$0;
        int i2 = xVar.f743a - 1;
        xVar.f743a = i2;
        if (i2 == 0 && xVar.f744c) {
            xVar.f.d(k.ON_STOP);
            xVar.f745d = true;
        }
    }
}
