package androidx.lifecycle;

import android.os.Looper;
import j.C0098a;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicReference;
import k.C0100a;

/* JADX INFO: loaded from: classes.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f735a;
    public C0100a b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public l f736c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final WeakReference f737d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f738e;
    public boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f739g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ArrayList f740h;

    public s(q qVar) {
        new AtomicReference();
        this.f735a = true;
        this.b = new C0100a();
        this.f736c = l.b;
        this.f740h = new ArrayList();
        this.f737d = new WeakReference(qVar);
    }

    public final void a(p pVar) {
        o reflectiveGenericLifecycleObserver;
        Object obj;
        q qVar;
        ArrayList arrayList = this.f740h;
        c("addObserver");
        l lVar = this.f736c;
        l lVar2 = l.f729a;
        if (lVar != lVar2) {
            lVar2 = l.b;
        }
        r rVar = new r();
        HashMap map = t.f741a;
        boolean z2 = pVar instanceof o;
        boolean z3 = pVar instanceof InterfaceC0004d;
        if (z2 && z3) {
            reflectiveGenericLifecycleObserver = new DefaultLifecycleObserverAdapter((InterfaceC0004d) pVar, (o) pVar);
        } else if (z3) {
            reflectiveGenericLifecycleObserver = new DefaultLifecycleObserverAdapter((InterfaceC0004d) pVar, null);
        } else if (z2) {
            reflectiveGenericLifecycleObserver = (o) pVar;
        } else {
            Class<?> cls = pVar.getClass();
            if (t.c(cls) == 2) {
                Object obj2 = t.b.get(cls);
                e0.c.b(obj2);
                List list = (List) obj2;
                if (list.size() == 1) {
                    t.a((Constructor) list.get(0), pVar);
                    throw null;
                }
                int size = list.size();
                InterfaceC0007g[] interfaceC0007gArr = new InterfaceC0007g[size];
                if (size > 0) {
                    t.a((Constructor) list.get(0), pVar);
                    throw null;
                }
                reflectiveGenericLifecycleObserver = new CompositeGeneratedAdaptersObserver(interfaceC0007gArr);
            } else {
                reflectiveGenericLifecycleObserver = new ReflectiveGenericLifecycleObserver(pVar);
            }
        }
        rVar.b = reflectiveGenericLifecycleObserver;
        rVar.f734a = lVar2;
        C0100a c0100a = this.b;
        k.c cVarA = c0100a.a(pVar);
        if (cVarA != null) {
            obj = cVarA.b;
        } else {
            HashMap map2 = c0100a.f1484e;
            k.c cVar = new k.c(pVar, rVar);
            c0100a.f1494d++;
            k.c cVar2 = c0100a.b;
            if (cVar2 == null) {
                c0100a.f1492a = cVar;
                c0100a.b = cVar;
            } else {
                cVar2.f1488c = cVar;
                cVar.f1489d = cVar2;
                c0100a.b = cVar;
            }
            map2.put(pVar, cVar);
            obj = null;
        }
        if (((r) obj) == null && (qVar = (q) this.f737d.get()) != null) {
            boolean z4 = this.f738e != 0 || this.f;
            l lVarB = b(pVar);
            this.f738e++;
            while (rVar.f734a.compareTo(lVarB) < 0 && this.b.f1484e.containsKey(pVar)) {
                arrayList.add(rVar.f734a);
                i iVar = k.Companion;
                l lVar3 = rVar.f734a;
                iVar.getClass();
                e0.c.e(lVar3, "state");
                int iOrdinal = lVar3.ordinal();
                k kVar = iOrdinal != 1 ? iOrdinal != 2 ? iOrdinal != 3 ? null : k.ON_RESUME : k.ON_START : k.ON_CREATE;
                if (kVar == null) {
                    throw new IllegalStateException("no event up from " + rVar.f734a);
                }
                rVar.a(qVar, kVar);
                arrayList.remove(arrayList.size() - 1);
                lVarB = b(pVar);
            }
            if (!z4) {
                g();
            }
            this.f738e--;
        }
    }

    public final l b(p pVar) {
        HashMap map = this.b.f1484e;
        k.c cVar = map.containsKey(pVar) ? ((k.c) map.get(pVar)).f1489d : null;
        l lVar = cVar != null ? ((r) cVar.b).f734a : null;
        ArrayList arrayList = this.f740h;
        l lVar2 = arrayList.isEmpty() ? null : (l) arrayList.get(arrayList.size() - 1);
        l lVar3 = this.f736c;
        e0.c.e(lVar3, "state1");
        if (lVar == null || lVar.compareTo(lVar3) >= 0) {
            lVar = lVar3;
        }
        return (lVar2 == null || lVar2.compareTo(lVar) >= 0) ? lVar : lVar2;
    }

    public final void c(String str) {
        C0098a c0098a;
        if (this.f735a) {
            if (C0098a.f1481p != null) {
                c0098a = C0098a.f1481p;
            } else {
                synchronized (C0098a.class) {
                    try {
                        if (C0098a.f1481p == null) {
                            C0098a.f1481p = new C0098a(0);
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                c0098a = C0098a.f1481p;
            }
            ((C0098a) c0098a.f1482o).getClass();
            if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
                return;
            }
            throw new IllegalStateException(("Method " + str + " must be called on the main thread").toString());
        }
    }

    public final void d(k kVar) {
        e0.c.e(kVar, "event");
        c("handleLifecycleEvent");
        e(kVar.a());
    }

    public final void e(l lVar) {
        l lVar2 = this.f736c;
        if (lVar2 == lVar) {
            return;
        }
        l lVar3 = l.b;
        l lVar4 = l.f729a;
        if (lVar2 == lVar3 && lVar == lVar4) {
            throw new IllegalStateException(("no event down from " + this.f736c + " in component " + this.f737d.get()).toString());
        }
        this.f736c = lVar;
        if (this.f || this.f738e != 0) {
            this.f739g = true;
            return;
        }
        this.f = true;
        g();
        this.f = false;
        if (this.f736c == lVar4) {
            this.b = new C0100a();
        }
    }

    public final void f(p pVar) {
        c("removeObserver");
        C0100a c0100a = this.b;
        k.c cVarA = c0100a.a(pVar);
        if (cVarA != null) {
            c0100a.f1494d--;
            WeakHashMap weakHashMap = c0100a.f1493c;
            if (!weakHashMap.isEmpty()) {
                Iterator it = weakHashMap.keySet().iterator();
                while (it.hasNext()) {
                    ((k.e) it.next()).a(cVarA);
                }
            }
            k.c cVar = cVarA.f1489d;
            if (cVar != null) {
                cVar.f1488c = cVarA.f1488c;
            } else {
                c0100a.f1492a = cVarA.f1488c;
            }
            k.c cVar2 = cVarA.f1488c;
            if (cVar2 != null) {
                cVar2.f1489d = cVar;
            } else {
                c0100a.b = cVar;
            }
            cVarA.f1488c = null;
            cVarA.f1489d = null;
        }
        c0100a.f1484e.remove(pVar);
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0030, code lost:
    
        r12.f739g = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0032, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void g() {
        /*
            Method dump skipped, instruction units count: 410
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.s.g():void");
    }
}
