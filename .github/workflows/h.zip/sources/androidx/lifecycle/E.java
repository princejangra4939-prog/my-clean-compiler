package androidx.lifecycle;

import java.util.HashMap;
import java.util.LinkedHashSet;

/* JADX INFO: loaded from: classes.dex */
public abstract class E {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f717a = new HashMap();
    public final LinkedHashSet b = new LinkedHashSet();

    public void a() {
    }
}
