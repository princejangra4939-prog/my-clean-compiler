package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class F {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final F f718a = new F();
    public static final F b = new F();
}
