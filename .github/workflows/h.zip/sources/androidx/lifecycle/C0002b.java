package androidx.lifecycle;

import java.lang.reflect.Method;

/* JADX INFO: renamed from: androidx.lifecycle.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0002b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f724a;
    public final Method b;

    public C0002b(int i2, Method method) {
        this.f724a = i2;
        this.b = method;
        method.setAccessible(true);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0002b)) {
            return false;
        }
        C0002b c0002b = (C0002b) obj;
        return this.f724a == c0002b.f724a && this.b.getName().equals(c0002b.b.getName());
    }

    public final int hashCode() {
        return this.b.getName().hashCode() + (this.f724a * 31);
    }
}
