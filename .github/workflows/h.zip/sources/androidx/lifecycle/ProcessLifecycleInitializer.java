package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements N.b {
    @Override // N.b
    public final List a() {
        return Y.d.f299a;
    }

    @Override // N.b
    public final Object b(Context context) {
        e0.c.e(context, "context");
        N.a aVarC = N.a.c(context);
        e0.c.d(aVarC, "getInstance(context)");
        if (!aVarC.b.contains(ProcessLifecycleInitializer.class)) {
            throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
        }
        if (!n.f733a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            e0.c.c(applicationContext, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new m());
        }
        x xVar = x.f742i;
        xVar.getClass();
        xVar.f746e = new Handler();
        xVar.f.d(k.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        e0.c.c(applicationContext2, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new w(xVar));
        return xVar;
    }
}
