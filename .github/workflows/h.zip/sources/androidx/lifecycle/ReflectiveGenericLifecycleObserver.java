package androidx.lifecycle;

import java.util.HashMap;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
class ReflectiveGenericLifecycleObserver implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p f720a;
    public final C0001a b;

    public ReflectiveGenericLifecycleObserver(p pVar) {
        this.f720a = pVar;
        C0003c c0003c = C0003c.f725c;
        Class<?> cls = pVar.getClass();
        C0001a c0001a = (C0001a) c0003c.f726a.get(cls);
        this.b = c0001a == null ? c0003c.a(cls, null) : c0001a;
    }

    @Override // androidx.lifecycle.o
    public final void b(q qVar, k kVar) {
        HashMap map = this.b.f723a;
        List list = (List) map.get(kVar);
        p pVar = this.f720a;
        C0001a.a(list, qVar, kVar, pVar);
        C0001a.a((List) map.get(k.ON_ANY), qVar, kVar, pVar);
    }
}
