package androidx.lifecycle;

import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class x implements q {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final x f742i = new x();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f743a;
    public int b;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Handler f746e;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f744c = true;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f745d = true;
    public final s f = new s(this);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final androidx.activity.d f747g = new androidx.activity.d(4, this);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final C.j f748h = new C.j(13, this);

    public final void b() {
        int i2 = this.b + 1;
        this.b = i2;
        if (i2 == 1) {
            if (this.f744c) {
                this.f.d(k.ON_RESUME);
                this.f744c = false;
            } else {
                Handler handler = this.f746e;
                e0.c.b(handler);
                handler.removeCallbacks(this.f747g);
            }
        }
    }

    @Override // androidx.lifecycle.q
    public final s c() {
        return this.f;
    }
}
