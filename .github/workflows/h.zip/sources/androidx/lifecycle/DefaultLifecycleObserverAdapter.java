package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class DefaultLifecycleObserverAdapter implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final InterfaceC0004d f716a;
    public final o b;

    public DefaultLifecycleObserverAdapter(InterfaceC0004d interfaceC0004d, o oVar) {
        this.f716a = interfaceC0004d;
        this.b = oVar;
    }

    @Override // androidx.lifecycle.o
    public final void b(q qVar, k kVar) {
        int i2 = AbstractC0005e.f727a[kVar.ordinal()];
        InterfaceC0004d interfaceC0004d = this.f716a;
        if (i2 == 3) {
            interfaceC0004d.a();
        } else if (i2 == 7) {
            throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        o oVar = this.b;
        if (oVar != null) {
            oVar.b(qVar, kVar);
        }
    }
}
