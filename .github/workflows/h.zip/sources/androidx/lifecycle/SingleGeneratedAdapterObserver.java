package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class SingleGeneratedAdapterObserver implements o {
    @Override // androidx.lifecycle.o
    public final void b(q qVar, k kVar) {
        throw null;
    }
}
