package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface o extends p {
    void b(q qVar, k kVar);
}
