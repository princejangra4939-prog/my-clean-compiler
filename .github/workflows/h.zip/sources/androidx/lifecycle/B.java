package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public abstract class B {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final F f709a = new F();
    public static final F b = new F();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final F f710c = new F();
}
