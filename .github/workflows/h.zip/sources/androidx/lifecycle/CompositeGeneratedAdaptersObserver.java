package androidx.lifecycle;

import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class CompositeGeneratedAdaptersObserver implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final InterfaceC0007g[] f714a;

    public CompositeGeneratedAdaptersObserver(InterfaceC0007g[] interfaceC0007gArr) {
        this.f714a = interfaceC0007gArr;
    }

    @Override // androidx.lifecycle.o
    public final void b(q qVar, k kVar) {
        new HashMap();
        InterfaceC0007g[] interfaceC0007gArr = this.f714a;
        if (interfaceC0007gArr.length > 0) {
            InterfaceC0007g interfaceC0007g = interfaceC0007gArr[0];
            throw null;
        }
        if (interfaceC0007gArr.length <= 0) {
            return;
        }
        InterfaceC0007g interfaceC0007g2 = interfaceC0007gArr[0];
        throw null;
    }
}
