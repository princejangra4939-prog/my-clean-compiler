package androidx.lifecycle;

import android.app.Activity;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public final class m extends AbstractC0006f {
    @Override // androidx.lifecycle.AbstractC0006f, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        e0.c.e(activity, "activity");
        int i2 = A.b;
        y.b(activity);
    }
}
