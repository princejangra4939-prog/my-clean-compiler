package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class A extends Fragment {
    public static final /* synthetic */ int b = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public C.j f708a;

    public static final class a implements Application.ActivityLifecycleCallbacks {
        public static final z Companion = new z();

        public static final void registerIn(Activity activity) {
            Companion.getClass();
            e0.c.e(activity, "activity");
            activity.registerActivityLifecycleCallbacks(new a());
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            e0.c.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            e0.c.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            e0.c.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            e0.c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_CREATE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            e0.c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_RESUME);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            e0.c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_START);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreDestroyed(Activity activity) {
            e0.c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_DESTROY);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPrePaused(Activity activity) {
            e0.c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_PAUSE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreStopped(Activity activity) {
            e0.c.e(activity, "activity");
            int i2 = A.b;
            y.a(activity, k.ON_STOP);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
            e0.c.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            e0.c.e(activity, "activity");
            e0.c.e(bundle, "bundle");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
            e0.c.e(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
            e0.c.e(activity, "activity");
        }
    }

    public final void a(k kVar) {
        if (Build.VERSION.SDK_INT < 29) {
            Activity activity = getActivity();
            e0.c.d(activity, "activity");
            y.a(activity, kVar);
        }
    }

    @Override // android.app.Fragment
    public final void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(k.ON_CREATE);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        a(k.ON_DESTROY);
        this.f708a = null;
    }

    @Override // android.app.Fragment
    public final void onPause() {
        super.onPause();
        a(k.ON_PAUSE);
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        C.j jVar = this.f708a;
        if (jVar != null) {
            ((x) jVar.b).b();
        }
        a(k.ON_RESUME);
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        C.j jVar = this.f708a;
        if (jVar != null) {
            x xVar = (x) jVar.b;
            int i2 = xVar.f743a + 1;
            xVar.f743a = i2;
            if (i2 == 1 && xVar.f745d) {
                xVar.f.d(k.ON_START);
                xVar.f745d = false;
            }
        }
        a(k.ON_START);
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        a(k.ON_STOP);
    }
}
