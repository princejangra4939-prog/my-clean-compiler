package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class LegacySavedStateHandleController$tryToAddRecreator$1 implements o {
    @Override // androidx.lifecycle.o
    public final void b(q qVar, k kVar) {
        if (kVar == k.ON_START) {
            throw null;
        }
    }
}
