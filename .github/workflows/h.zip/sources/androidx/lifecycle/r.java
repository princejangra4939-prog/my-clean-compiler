package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public l f734a;
    public o b;

    public final void a(q qVar, k kVar) {
        l lVarA = kVar.a();
        l lVar = this.f734a;
        e0.c.e(lVar, "state1");
        if (lVarA.compareTo(lVar) < 0) {
            lVar = lVarA;
        }
        this.f734a = lVar;
        this.b.b(qVar, kVar);
        this.f734a = lVarA;
    }
}
