package androidx.lifecycle;

import android.os.Bundle;
import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class C implements M.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final M.e f711a;
    public boolean b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Bundle f712c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final X.b f713d;

    public C(M.e eVar, androidx.activity.l lVar) {
        e0.c.e(eVar, "savedStateRegistry");
        this.f711a = eVar;
        this.f713d = new X.b(new androidx.activity.o(3, lVar));
    }

    @Override // M.d
    public final Bundle a() {
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f712c;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        Iterator it = ((D) this.f713d.a()).f715c.entrySet().iterator();
        if (!it.hasNext()) {
            this.b = false;
            return bundle;
        }
        Map.Entry entry = (Map.Entry) it.next();
        entry.getValue().getClass();
        throw new ClassCastException();
    }
}
