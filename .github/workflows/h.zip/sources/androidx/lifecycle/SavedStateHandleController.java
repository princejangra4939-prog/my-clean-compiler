package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class SavedStateHandleController implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f722a;

    @Override // androidx.lifecycle.o
    public final void b(q qVar, k kVar) {
        if (kVar == k.ON_DESTROY) {
            this.f722a = false;
            qVar.c().f(this);
        }
    }
}
