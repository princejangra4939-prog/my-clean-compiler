package androidx.lifecycle;

import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public final class SavedStateHandleAttacher implements o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C f721a;

    public SavedStateHandleAttacher(C c2) {
        this.f721a = c2;
    }

    @Override // androidx.lifecycle.o
    public final void b(q qVar, k kVar) {
        if (kVar != k.ON_CREATE) {
            throw new IllegalStateException(("Next event must be ON_CREATE, it was " + kVar).toString());
        }
        qVar.c().f(this);
        C c2 = this.f721a;
        if (c2.b) {
            return;
        }
        Bundle bundleC = c2.f711a.c("androidx.lifecycle.internal.SavedStateHandlesProvider");
        Bundle bundle = new Bundle();
        Bundle bundle2 = c2.f712c;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        if (bundleC != null) {
            bundle.putAll(bundleC);
        }
        c2.f712c = bundle;
        c2.b = true;
    }
}
