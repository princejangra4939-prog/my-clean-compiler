package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
class LiveData$LifecycleBoundObserver extends B implements o {
    @Override // androidx.lifecycle.o
    public final void b(q qVar, k kVar) {
        throw null;
    }
}
