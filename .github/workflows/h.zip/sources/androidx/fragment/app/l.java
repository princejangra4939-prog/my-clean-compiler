package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ p f646a;

    public l(p pVar) {
        this.f646a = pVar;
    }
}
