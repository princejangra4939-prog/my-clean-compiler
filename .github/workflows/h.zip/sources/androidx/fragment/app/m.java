package androidx.fragment.app;

import java.lang.reflect.InvocationTargetException;
import l.C0111k;

/* JADX INFO: loaded from: classes.dex */
public final class m {
    public static final C0111k b = new C0111k();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ p f647a;

    public m(p pVar) {
        this.f647a = pVar;
    }

    public static Class b(ClassLoader classLoader, String str) throws ClassNotFoundException {
        C0111k c0111k = b;
        C0111k c0111k2 = (C0111k) c0111k.getOrDefault(classLoader, null);
        if (c0111k2 == null) {
            c0111k2 = new C0111k();
            c0111k.put(classLoader, c0111k2);
        }
        Class cls = (Class) c0111k2.getOrDefault(str, null);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        c0111k2.put(str, cls2);
        return cls2;
    }

    public static Class c(ClassLoader classLoader, String str) {
        try {
            return b(classLoader, str);
        } catch (ClassCastException e2) {
            throw new N.c("Unable to instantiate fragment " + str + ": make sure class is a valid subclass of Fragment", e2);
        } catch (ClassNotFoundException e3) {
            throw new N.c("Unable to instantiate fragment " + str + ": make sure class name exists", e3);
        }
    }

    public final void a(String str) {
        try {
            if (c(this.f647a.f671r.f634a.getClassLoader(), str).getConstructor(null).newInstance(null) == null) {
            } else {
                throw new ClassCastException();
            }
        } catch (IllegalAccessException e2) {
            throw new N.c("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e2);
        } catch (InstantiationException e3) {
            throw new N.c("Unable to instantiate fragment " + str + ": make sure class name exists, is public, and has an empty constructor that is public", e3);
        } catch (NoSuchMethodException e4) {
            throw new N.c("Unable to instantiate fragment " + str + ": could not find Fragment constructor", e4);
        } catch (InvocationTargetException e5) {
            throw new N.c("Unable to instantiate fragment " + str + ": calling Fragment constructor caused an exception", e5);
        }
    }
}
