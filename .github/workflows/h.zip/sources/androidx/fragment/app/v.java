package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
public abstract class v {
    public abstract void a();
}
