package androidx.fragment.app;

import android.util.Log;
import java.io.PrintWriter;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f605a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f606c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f607d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f608e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f609g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public String f610h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f611i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f612j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f613k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public CharSequence f614l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public ArrayList f615m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public ArrayList f616n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f617o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final p f618p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f619q;

    public a(p pVar) {
        m mVar = pVar.f673t;
        f fVar = pVar.f671r;
        if (fVar != null) {
            fVar.f634a.getClassLoader();
        }
        this.f605a = new ArrayList();
        this.f617o = false;
        this.f619q = -1;
        this.f618p = pVar;
    }

    public final void a(int i2) {
        if (this.f609g) {
            if (p.h(2)) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i2);
            }
            ArrayList arrayList = this.f605a;
            int size = arrayList.size();
            for (int i3 = 0; i3 < size; i3++) {
                ((t) arrayList.get(i3)).getClass();
            }
        }
    }

    public final void b(String str, PrintWriter printWriter, boolean z2) {
        String str2;
        if (z2) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f610h);
            printWriter.print(" mIndex=");
            printWriter.print(this.f619q);
            printWriter.print(" mCommitted=");
            printWriter.println(false);
            if (this.f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f));
            }
            if (this.b != 0 || this.f606c != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f606c));
            }
            if (this.f607d != 0 || this.f608e != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f607d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f608e));
            }
            if (this.f611i != 0 || this.f612j != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f611i));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f612j);
            }
            if (this.f613k != 0 || this.f614l != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f613k));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f614l);
            }
        }
        ArrayList arrayList = this.f605a;
        if (arrayList.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            t tVar = (t) arrayList.get(i2);
            switch (tVar.f701a) {
                case 0:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case 3:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case 6:
                    str2 = "DETACH";
                    break;
                case 7:
                    str2 = "ATTACH";
                    break;
                case 8:
                    str2 = "SET_PRIMARY_NAV";
                    break;
                case 9:
                    str2 = "UNSET_PRIMARY_NAV";
                    break;
                case 10:
                    str2 = "OP_SET_MAX_LIFECYCLE";
                    break;
                default:
                    str2 = "cmd=" + tVar.f701a;
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i2);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println((Object) null);
            if (z2) {
                if (tVar.f702c != 0 || tVar.f703d != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(tVar.f702c));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(tVar.f703d));
                }
                if (tVar.f704e != 0 || tVar.f != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(tVar.f704e));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(tVar.f));
                }
            }
        }
    }

    public final void c(ArrayList arrayList, ArrayList arrayList2) {
        if (p.h(2)) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (this.f609g) {
            p pVar = this.f618p;
            if (pVar.f658d == null) {
                pVar.f658d = new ArrayList();
            }
            pVar.f658d.add(this);
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f619q >= 0) {
            sb.append(" #");
            sb.append(this.f619q);
        }
        if (this.f610h != null) {
            sb.append(" ");
            sb.append(this.f610h);
        }
        sb.append("}");
        return sb.toString();
    }
}
