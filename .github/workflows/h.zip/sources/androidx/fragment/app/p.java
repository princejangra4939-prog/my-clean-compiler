package androidx.fragment.app;

import android.os.Looper;
import android.util.Log;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import x.InterfaceC0149a;

/* JADX INFO: loaded from: classes.dex */
public final class p {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f650A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public ArrayList f651B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public ArrayList f652C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public ArrayList f653D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public r f654E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final D.b f655F;
    public boolean b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList f658d;
    public androidx.activity.v f;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final CopyOnWriteArrayList f664k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final i f665l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final i f666m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final i f667n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final i f668o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final l f669p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f670q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public f f671r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public f f672s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final m f673t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public G.a f674u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public G.a f675v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public G.a f676w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public ArrayDeque f677x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f678y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f679z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f656a = new ArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final T.t f657c = new T.t();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final h f659e = new h(this);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final k f660g = new k(this);

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final AtomicInteger f661h = new AtomicInteger();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final Map f662i = Collections.synchronizedMap(new HashMap());

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Map f663j = Collections.synchronizedMap(new HashMap());

    /* JADX WARN: Type inference failed for: r0v12, types: [androidx.fragment.app.i] */
    /* JADX WARN: Type inference failed for: r0v13, types: [androidx.fragment.app.i] */
    /* JADX WARN: Type inference failed for: r0v14, types: [androidx.fragment.app.i] */
    /* JADX WARN: Type inference failed for: r0v15, types: [androidx.fragment.app.i] */
    public p() {
        Collections.synchronizedMap(new HashMap());
        new CopyOnWriteArrayList();
        this.f664k = new CopyOnWriteArrayList();
        final int i2 = 0;
        this.f665l = new InterfaceC0149a(this) { // from class: androidx.fragment.app.i
            public final /* synthetic */ p b;

            {
                this.b = this;
            }

            @Override // x.InterfaceC0149a
            public final void a(Object obj) {
                switch (i2) {
                    case 0:
                        Iterator it = this.b.f657c.d().iterator();
                        while (it.hasNext()) {
                            if (it.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                    case 1:
                        p pVar = this.b;
                        pVar.getClass();
                        if (((Integer) obj).intValue() == 80) {
                            Iterator it2 = pVar.f657c.d().iterator();
                            while (it2.hasNext()) {
                                if (it2.next() != null) {
                                    throw new ClassCastException();
                                }
                            }
                            return;
                        }
                        return;
                    case 2:
                        p pVar2 = this.b;
                        pVar2.getClass();
                        boolean z2 = ((o.i) obj).f1562a;
                        Iterator it3 = pVar2.f657c.d().iterator();
                        while (it3.hasNext()) {
                            if (it3.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                    default:
                        p pVar3 = this.b;
                        pVar3.getClass();
                        boolean z3 = ((o.r) obj).f1564a;
                        Iterator it4 = pVar3.f657c.d().iterator();
                        while (it4.hasNext()) {
                            if (it4.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                }
            }
        };
        final int i3 = 1;
        this.f666m = new InterfaceC0149a(this) { // from class: androidx.fragment.app.i
            public final /* synthetic */ p b;

            {
                this.b = this;
            }

            @Override // x.InterfaceC0149a
            public final void a(Object obj) {
                switch (i3) {
                    case 0:
                        Iterator it = this.b.f657c.d().iterator();
                        while (it.hasNext()) {
                            if (it.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                    case 1:
                        p pVar = this.b;
                        pVar.getClass();
                        if (((Integer) obj).intValue() == 80) {
                            Iterator it2 = pVar.f657c.d().iterator();
                            while (it2.hasNext()) {
                                if (it2.next() != null) {
                                    throw new ClassCastException();
                                }
                            }
                            return;
                        }
                        return;
                    case 2:
                        p pVar2 = this.b;
                        pVar2.getClass();
                        boolean z2 = ((o.i) obj).f1562a;
                        Iterator it3 = pVar2.f657c.d().iterator();
                        while (it3.hasNext()) {
                            if (it3.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                    default:
                        p pVar3 = this.b;
                        pVar3.getClass();
                        boolean z3 = ((o.r) obj).f1564a;
                        Iterator it4 = pVar3.f657c.d().iterator();
                        while (it4.hasNext()) {
                            if (it4.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                }
            }
        };
        final int i4 = 2;
        this.f667n = new InterfaceC0149a(this) { // from class: androidx.fragment.app.i
            public final /* synthetic */ p b;

            {
                this.b = this;
            }

            @Override // x.InterfaceC0149a
            public final void a(Object obj) {
                switch (i4) {
                    case 0:
                        Iterator it = this.b.f657c.d().iterator();
                        while (it.hasNext()) {
                            if (it.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                    case 1:
                        p pVar = this.b;
                        pVar.getClass();
                        if (((Integer) obj).intValue() == 80) {
                            Iterator it2 = pVar.f657c.d().iterator();
                            while (it2.hasNext()) {
                                if (it2.next() != null) {
                                    throw new ClassCastException();
                                }
                            }
                            return;
                        }
                        return;
                    case 2:
                        p pVar2 = this.b;
                        pVar2.getClass();
                        boolean z2 = ((o.i) obj).f1562a;
                        Iterator it3 = pVar2.f657c.d().iterator();
                        while (it3.hasNext()) {
                            if (it3.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                    default:
                        p pVar3 = this.b;
                        pVar3.getClass();
                        boolean z3 = ((o.r) obj).f1564a;
                        Iterator it4 = pVar3.f657c.d().iterator();
                        while (it4.hasNext()) {
                            if (it4.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                }
            }
        };
        final int i5 = 3;
        this.f668o = new InterfaceC0149a(this) { // from class: androidx.fragment.app.i
            public final /* synthetic */ p b;

            {
                this.b = this;
            }

            @Override // x.InterfaceC0149a
            public final void a(Object obj) {
                switch (i5) {
                    case 0:
                        Iterator it = this.b.f657c.d().iterator();
                        while (it.hasNext()) {
                            if (it.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                    case 1:
                        p pVar = this.b;
                        pVar.getClass();
                        if (((Integer) obj).intValue() == 80) {
                            Iterator it2 = pVar.f657c.d().iterator();
                            while (it2.hasNext()) {
                                if (it2.next() != null) {
                                    throw new ClassCastException();
                                }
                            }
                            return;
                        }
                        return;
                    case 2:
                        p pVar2 = this.b;
                        pVar2.getClass();
                        boolean z2 = ((o.i) obj).f1562a;
                        Iterator it3 = pVar2.f657c.d().iterator();
                        while (it3.hasNext()) {
                            if (it3.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                    default:
                        p pVar3 = this.b;
                        pVar3.getClass();
                        boolean z3 = ((o.r) obj).f1564a;
                        Iterator it4 = pVar3.f657c.d().iterator();
                        while (it4.hasNext()) {
                            if (it4.next() != null) {
                                throw new ClassCastException();
                            }
                        }
                        return;
                }
            }
        };
        this.f669p = new l(this);
        this.f670q = -1;
        this.f673t = new m(this);
        this.f677x = new ArrayDeque();
        this.f655F = new D.b(4, this);
    }

    public static boolean h(int i2) {
        return Log.isLoggable("FragmentManager", i2);
    }

    public final void a() {
        this.b = false;
        this.f652C.clear();
        this.f651B.clear();
    }

    public final HashSet b() {
        HashSet hashSet = new HashSet();
        Iterator it = this.f657c.c().iterator();
        if (!it.hasNext()) {
            return hashSet;
        }
        L.d.a(it.next());
        throw null;
    }

    public final void c(int i2) {
        try {
            this.b = true;
            Iterator it = ((HashMap) this.f657c.f211a).values().iterator();
            while (it.hasNext()) {
                if (it.next() != null) {
                    throw new ClassCastException();
                }
            }
            i(i2, false);
            Iterator it2 = b().iterator();
            if (it2.hasNext()) {
                ((v) it2.next()).a();
                throw null;
            }
            this.b = false;
            e(true);
        } catch (Throwable th) {
            this.b = false;
            throw th;
        }
    }

    public final void d(boolean z2) {
        if (this.b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        }
        if (this.f671r == null) {
            if (!this.f650A) {
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            }
            throw new IllegalStateException("FragmentManager has been destroyed");
        }
        if (Looper.myLooper() != this.f671r.b.getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
        if (!z2 && (this.f678y || this.f679z)) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
        if (this.f651B == null) {
            this.f651B = new ArrayList();
            this.f652C = new ArrayList();
        }
    }

    public final boolean e(boolean z2) {
        boolean z3;
        d(z2);
        boolean z4 = false;
        while (true) {
            ArrayList arrayList = this.f651B;
            ArrayList arrayList2 = this.f652C;
            synchronized (this.f656a) {
                if (this.f656a.isEmpty()) {
                    z3 = false;
                } else {
                    try {
                        int size = this.f656a.size();
                        int i2 = 0;
                        z3 = false;
                        while (i2 < size) {
                            ((a) this.f656a.get(i2)).c(arrayList, arrayList2);
                            i2++;
                            z3 = true;
                        }
                    } finally {
                    }
                }
            }
            if (!z3) {
                k();
                ((HashMap) this.f657c.f211a).values().removeAll(Collections.singleton(null));
                return z4;
            }
            this.b = true;
            try {
                j(this.f651B, this.f652C);
                a();
                z4 = true;
            } catch (Throwable th) {
                a();
                throw th;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x0085  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00d1  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void f(java.util.ArrayList r19, java.util.ArrayList r20, int r21, int r22) {
        /*
            Method dump skipped, instruction units count: 722
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.p.f(java.util.ArrayList, java.util.ArrayList, int, int):void");
    }

    public final void g() {
        T.t tVar = this.f657c;
        ArrayList arrayList = (ArrayList) tVar.b;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (arrayList.get(size) != null) {
                throw new ClassCastException();
            }
        }
        Iterator it = ((HashMap) tVar.f211a).values().iterator();
        while (it.hasNext()) {
            L.d.a(it.next());
        }
    }

    public final void i(int i2, boolean z2) {
        if (this.f671r == null && i2 != -1) {
            throw new IllegalStateException("No activity");
        }
        if (z2 || i2 != this.f670q) {
            this.f670q = i2;
            T.t tVar = this.f657c;
            Iterator it = ((ArrayList) tVar.b).iterator();
            if (it.hasNext()) {
                it.next().getClass();
                throw new ClassCastException();
            }
            Iterator it2 = ((HashMap) tVar.f211a).values().iterator();
            while (it2.hasNext()) {
                if (it2.next() != null) {
                    throw new ClassCastException();
                }
            }
            Iterator it3 = tVar.c().iterator();
            if (it3.hasNext()) {
                it3.next().getClass();
                throw new ClassCastException();
            }
        }
    }

    public final void j(ArrayList arrayList, ArrayList arrayList2) {
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("Internal error with the back stack records");
        }
        int size = arrayList.size();
        int i2 = 0;
        int i3 = 0;
        while (i2 < size) {
            if (!((a) arrayList.get(i2)).f617o) {
                if (i3 != i2) {
                    f(arrayList, arrayList2, i3, i2);
                }
                i3 = i2 + 1;
                if (((Boolean) arrayList2.get(i2)).booleanValue()) {
                    while (i3 < size && ((Boolean) arrayList2.get(i3)).booleanValue() && !((a) arrayList.get(i3)).f617o) {
                        i3++;
                    }
                }
                f(arrayList, arrayList2, i2, i3);
                i2 = i3 - 1;
            }
            i2++;
        }
        if (i3 != size) {
            f(arrayList, arrayList2, i3, size);
        }
    }

    public final void k() {
        synchronized (this.f656a) {
            try {
                if (!this.f656a.isEmpty()) {
                    k kVar = this.f660g;
                    kVar.f643a = true;
                    androidx.activity.u uVar = kVar.f644c;
                    if (uVar != null) {
                        uVar.a();
                    }
                    return;
                }
                k kVar2 = this.f660g;
                ArrayList arrayList = this.f658d;
                kVar2.f643a = (arrayList != null ? arrayList.size() : 0) > 0;
                androidx.activity.u uVar2 = kVar2.f644c;
                if (uVar2 != null) {
                    uVar2.a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        f fVar = this.f671r;
        if (fVar != null) {
            sb.append(fVar.getClass().getSimpleName());
            sb.append("{");
            sb.append(Integer.toHexString(System.identityHashCode(this.f671r)));
            sb.append("}");
        } else {
            sb.append("null");
        }
        sb.append("}}");
        return sb.toString();
    }
}
