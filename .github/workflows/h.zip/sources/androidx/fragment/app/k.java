package androidx.fragment.app;

import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f643a = false;
    public final CopyOnWriteArrayList b = new CopyOnWriteArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public androidx.activity.u f644c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ p f645d;

    public k(p pVar) {
        this.f645d = pVar;
    }
}
