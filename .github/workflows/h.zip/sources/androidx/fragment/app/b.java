package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new D.m(4);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int[] f620a;
    public final ArrayList b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int[] f621c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int[] f622d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f623e;
    public final String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f624g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f625h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final CharSequence f626i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f627j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final CharSequence f628k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final ArrayList f629l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ArrayList f630m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final boolean f631n;

    public b(a aVar) {
        int size = aVar.f605a.size();
        this.f620a = new int[size * 6];
        if (!aVar.f609g) {
            throw new IllegalStateException("Not on back stack");
        }
        this.b = new ArrayList(size);
        this.f621c = new int[size];
        this.f622d = new int[size];
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            t tVar = (t) aVar.f605a.get(i3);
            this.f620a[i2] = tVar.f701a;
            this.b.add(null);
            int[] iArr = this.f620a;
            iArr[i2 + 1] = tVar.b ? 1 : 0;
            iArr[i2 + 2] = tVar.f702c;
            iArr[i2 + 3] = tVar.f703d;
            int i4 = i2 + 5;
            iArr[i2 + 4] = tVar.f704e;
            i2 += 6;
            iArr[i4] = tVar.f;
            this.f621c[i3] = tVar.f705g.ordinal();
            this.f622d[i3] = tVar.f706h.ordinal();
        }
        this.f623e = aVar.f;
        this.f = aVar.f610h;
        this.f624g = aVar.f619q;
        this.f625h = aVar.f611i;
        this.f626i = aVar.f612j;
        this.f627j = aVar.f613k;
        this.f628k = aVar.f614l;
        this.f629l = aVar.f615m;
        this.f630m = aVar.f616n;
        this.f631n = aVar.f617o;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeIntArray(this.f620a);
        parcel.writeStringList(this.b);
        parcel.writeIntArray(this.f621c);
        parcel.writeIntArray(this.f622d);
        parcel.writeInt(this.f623e);
        parcel.writeString(this.f);
        parcel.writeInt(this.f624g);
        parcel.writeInt(this.f625h);
        TextUtils.writeToParcel(this.f626i, parcel, 0);
        parcel.writeInt(this.f627j);
        TextUtils.writeToParcel(this.f628k, parcel, 0);
        parcel.writeStringList(this.f629l);
        parcel.writeStringList(this.f630m);
        parcel.writeInt(this.f631n ? 1 : 0);
    }

    public b(Parcel parcel) {
        this.f620a = parcel.createIntArray();
        this.b = parcel.createStringArrayList();
        this.f621c = parcel.createIntArray();
        this.f622d = parcel.createIntArray();
        this.f623e = parcel.readInt();
        this.f = parcel.readString();
        this.f624g = parcel.readInt();
        this.f625h = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.f626i = (CharSequence) creator.createFromParcel(parcel);
        this.f627j = parcel.readInt();
        this.f628k = (CharSequence) creator.createFromParcel(parcel);
        this.f629l = parcel.createStringArrayList();
        this.f630m = parcel.createStringArrayList();
        this.f631n = parcel.readInt() != 0;
    }
}
