package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class q implements Parcelable {
    public static final Parcelable.Creator<q> CREATOR = new D.m(7);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ArrayList f680a;
    public ArrayList b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public b[] f681c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f682d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public String f683e;
    public ArrayList f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ArrayList f684g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public ArrayList f685h;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeStringList(this.f680a);
        parcel.writeStringList(this.b);
        parcel.writeTypedArray(this.f681c, i2);
        parcel.writeInt(this.f682d);
        parcel.writeString(this.f683e);
        parcel.writeStringList(this.f);
        parcel.writeTypedList(this.f684g);
        parcel.writeTypedList(this.f685h);
    }
}
