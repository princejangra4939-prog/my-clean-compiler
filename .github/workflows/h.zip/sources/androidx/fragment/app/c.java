package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class c implements Parcelable {
    public static final Parcelable.Creator<c> CREATOR = new D.m(5);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f632a;
    public final ArrayList b;

    public c(Parcel parcel) {
        this.f632a = parcel.createStringArrayList();
        this.b = parcel.createTypedArrayList(b.CREATOR);
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeStringList(this.f632a);
        parcel.writeTypedList(this.b);
    }
}
