package androidx.fragment.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class s implements Parcelable {
    public static final Parcelable.Creator<s> CREATOR = new D.m(8);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f690a;
    public final String b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f691c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f692d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f693e;
    public final String f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f694g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f695h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f696i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Bundle f697j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final boolean f698k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final int f699l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final Bundle f700m;

    public s(Parcel parcel) {
        this.f690a = parcel.readString();
        this.b = parcel.readString();
        this.f691c = parcel.readInt() != 0;
        this.f692d = parcel.readInt();
        this.f693e = parcel.readInt();
        this.f = parcel.readString();
        this.f694g = parcel.readInt() != 0;
        this.f695h = parcel.readInt() != 0;
        this.f696i = parcel.readInt() != 0;
        this.f697j = parcel.readBundle();
        this.f698k = parcel.readInt() != 0;
        this.f700m = parcel.readBundle();
        this.f699l = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.f690a);
        sb.append(" (");
        sb.append(this.b);
        sb.append(")}:");
        if (this.f691c) {
            sb.append(" fromLayout");
        }
        int i2 = this.f693e;
        if (i2 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(i2));
        }
        String str = this.f;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(str);
        }
        if (this.f694g) {
            sb.append(" retainInstance");
        }
        if (this.f695h) {
            sb.append(" removing");
        }
        if (this.f696i) {
            sb.append(" detached");
        }
        if (this.f698k) {
            sb.append(" hidden");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeString(this.f690a);
        parcel.writeString(this.b);
        parcel.writeInt(this.f691c ? 1 : 0);
        parcel.writeInt(this.f692d);
        parcel.writeInt(this.f693e);
        parcel.writeString(this.f);
        parcel.writeInt(this.f694g ? 1 : 0);
        parcel.writeInt(this.f695h ? 1 : 0);
        parcel.writeInt(this.f696i ? 1 : 0);
        parcel.writeBundle(this.f697j);
        parcel.writeInt(this.f698k ? 1 : 0);
        parcel.writeBundle(this.f700m);
        parcel.writeInt(this.f699l);
    }
}
