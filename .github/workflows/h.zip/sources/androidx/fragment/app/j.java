package androidx.fragment.app;

import android.util.Log;
import java.util.ArrayList;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f642a;
    public final /* synthetic */ p b;

    public /* synthetic */ j(p pVar, int i2) {
        this.f642a = i2;
        this.b = pVar;
    }

    public final void a(Object obj) {
        switch (this.f642a) {
            case 0:
                Map map = (Map) obj;
                ArrayList arrayList = new ArrayList(map.values());
                int[] iArr = new int[arrayList.size()];
                for (int i2 = 0; i2 < arrayList.size(); i2++) {
                    iArr[i2] = ((Boolean) arrayList.get(i2)).booleanValue() ? 0 : -1;
                }
                p pVar = this.b;
                o oVar = (o) pVar.f677x.pollFirst();
                if (oVar == null) {
                    Log.w("FragmentManager", "No permissions were requested for " + this);
                } else {
                    String str = oVar.f649a;
                    pVar.f657c.a();
                    Log.w("FragmentManager", "Permission request result delivered for unknown Fragment " + str);
                }
                break;
            case 1:
                p pVar2 = this.b;
                o oVar2 = (o) pVar2.f677x.pollFirst();
                if (oVar2 == null) {
                    Log.w("FragmentManager", "No Activities were started for result for " + this);
                } else {
                    String str2 = oVar2.f649a;
                    pVar2.f657c.a();
                    Log.w("FragmentManager", "Activity result delivered for unknown Fragment " + str2);
                }
                break;
            default:
                p pVar3 = this.b;
                o oVar3 = (o) pVar3.f677x.pollFirst();
                if (oVar3 == null) {
                    Log.w("FragmentManager", "No IntentSenders were started for " + this);
                } else {
                    String str3 = oVar3.f649a;
                    pVar3.f657c.a();
                    Log.w("FragmentManager", "Intent Sender result delivered for unknown Fragment " + str3);
                }
                break;
        }
    }
}
