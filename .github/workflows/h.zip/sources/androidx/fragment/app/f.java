package androidx.fragment.app;

import android.os.Handler;
import androidx.lifecycle.G;
import androidx.lifecycle.H;
import e.AbstractActivityC0022i;

/* JADX INFO: loaded from: classes.dex */
public final class f implements H, androidx.lifecycle.q, M.g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final AbstractActivityC0022i f634a;
    public final Handler b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p f635c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ AbstractActivityC0022i f636d;

    public f(AbstractActivityC0022i abstractActivityC0022i) {
        this.f636d = abstractActivityC0022i;
        Handler handler = new Handler();
        this.f635c = new p();
        this.f634a = abstractActivityC0022i;
        this.b = handler;
    }

    @Override // M.g
    public final M.e a() {
        return (M.e) this.f636d.f331e.f120c;
    }

    @Override // androidx.lifecycle.H
    public final G b() {
        return this.f636d.b();
    }

    @Override // androidx.lifecycle.q
    public final androidx.lifecycle.s c() {
        return this.f636d.f980s;
    }
}
