package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import com.warppaiwarden.tictactoe.R;
import e.AbstractActivityC0022i;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import y.AbstractC0180y;
import y.K;
import y.f0;

/* JADX INFO: loaded from: classes.dex */
public final class g extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f637a;
    public final ArrayList b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View.OnApplyWindowInsetsListener f638c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f639d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g(Context context, AttributeSet attributeSet, p pVar) {
        super(context, attributeSet);
        e0.c.e(context, "context");
        e0.c.e(attributeSet, "attrs");
        e0.c.e(pVar, "fm");
        this.f637a = new ArrayList();
        this.b = new ArrayList();
        this.f639d = true;
        String classAttribute = attributeSet.getClassAttribute();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, H.a.b, 0, 0);
        classAttribute = classAttribute == null ? typedArrayObtainStyledAttributes.getString(0) : classAttribute;
        String string = typedArrayObtainStyledAttributes.getString(1);
        typedArrayObtainStyledAttributes.recycle();
        int id = getId();
        pVar.g();
        if (classAttribute == null) {
            Iterator it = pVar.f657c.c().iterator();
            if (it.hasNext()) {
                it.next().getClass();
                throw new ClassCastException();
            }
            return;
        }
        if (id != -1) {
            context.getClassLoader();
            pVar.f673t.a(classAttribute);
            e0.c.d(null, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            throw null;
        }
        throw new IllegalStateException("FragmentContainerView must have an android:id to add Fragment " + classAttribute + (string != null ? " with tag ".concat(string) : ""));
    }

    public final void a(View view) {
        if (this.b.contains(view)) {
            this.f637a.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i2, ViewGroup.LayoutParams layoutParams) {
        e0.c.e(view, "child");
        view.getTag(R.id.fragment_container_view_tag);
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.").toString());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        f0 f0VarC;
        e0.c.e(windowInsets, "insets");
        f0 f0VarC2 = f0.c(windowInsets, null);
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.f638c;
        if (onApplyWindowInsetsListener != null) {
            WindowInsets windowInsetsOnApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, windowInsets);
            e0.c.d(windowInsetsOnApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            f0VarC = f0.c(windowInsetsOnApplyWindowInsets, null);
        } else {
            WeakHashMap weakHashMap = K.f1647a;
            WindowInsets windowInsetsB = f0VarC2.b();
            if (windowInsetsB != null) {
                WindowInsets windowInsetsB2 = AbstractC0180y.b(this, windowInsetsB);
                if (!windowInsetsB2.equals(windowInsetsB)) {
                    f0VarC2 = f0.c(windowInsetsB2, this);
                }
            }
            f0VarC = f0VarC2;
        }
        if (!f0VarC.f1684a.m()) {
            int childCount = getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                WeakHashMap weakHashMap2 = K.f1647a;
                WindowInsets windowInsetsB3 = f0VarC.b();
                if (windowInsetsB3 != null) {
                    WindowInsets windowInsetsA = AbstractC0180y.a(childAt, windowInsetsB3);
                    if (!windowInsetsA.equals(windowInsetsB3)) {
                        f0.c(windowInsetsA, childAt);
                    }
                }
            }
        }
        return windowInsets;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        e0.c.e(canvas, "canvas");
        if (this.f639d) {
            ArrayList arrayList = this.f637a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                super.drawChild(canvas, (View) obj, getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j2) {
        e0.c.e(canvas, "canvas");
        e0.c.e(view, "child");
        if (this.f639d) {
            ArrayList arrayList = this.f637a;
            if (!arrayList.isEmpty() && arrayList.contains(view)) {
                return false;
            }
        }
        return super.drawChild(canvas, view, j2);
    }

    @Override // android.view.ViewGroup
    public final void endViewTransition(View view) {
        e0.c.e(view, "view");
        this.b.remove(view);
        if (this.f637a.remove(view)) {
            this.f639d = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends d> F getFragment() {
        AbstractActivityC0022i abstractActivityC0022i;
        View view = this;
        while (view != null) {
            view.getTag(R.id.fragment_container_view_tag);
            Object parent = view.getParent();
            view = parent instanceof View ? (View) parent : null;
        }
        Context context = getContext();
        while (true) {
            if (!(context instanceof ContextWrapper)) {
                abstractActivityC0022i = null;
                break;
            }
            if (context instanceof AbstractActivityC0022i) {
                abstractActivityC0022i = (AbstractActivityC0022i) context;
                break;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        if (abstractActivityC0022i != null) {
            f fVar = (f) abstractActivityC0022i.f979r.b;
            getId();
            fVar.f635c.g();
            return null;
        }
        throw new IllegalStateException("View " + this + " is not within a subclass of FragmentActivity.");
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        e0.c.e(windowInsets, "insets");
        return windowInsets;
    }

    @Override // android.view.ViewGroup
    public final void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 >= childCount) {
                super.removeAllViewsInLayout();
                return;
            } else {
                View childAt = getChildAt(childCount);
                e0.c.d(childAt, "view");
                a(childAt);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void removeView(View view) {
        e0.c.e(view, "view");
        a(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViewAt(int i2) {
        View childAt = getChildAt(i2);
        e0.c.d(childAt, "view");
        a(childAt);
        super.removeViewAt(i2);
    }

    @Override // android.view.ViewGroup
    public final void removeViewInLayout(View view) {
        e0.c.e(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViews(int i2, int i3) {
        int i4 = i2 + i3;
        for (int i5 = i2; i5 < i4; i5++) {
            View childAt = getChildAt(i5);
            e0.c.d(childAt, "view");
            a(childAt);
        }
        super.removeViews(i2, i3);
    }

    @Override // android.view.ViewGroup
    public final void removeViewsInLayout(int i2, int i3) {
        int i4 = i2 + i3;
        for (int i5 = i2; i5 < i4; i5++) {
            View childAt = getChildAt(i5);
            e0.c.d(childAt, "view");
            a(childAt);
        }
        super.removeViewsInLayout(i2, i3);
    }

    public final void setDrawDisappearingViewsLast(boolean z2) {
        this.f639d = z2;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.View
    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        e0.c.e(onApplyWindowInsetsListener, "listener");
        this.f638c = onApplyWindowInsetsListener;
    }

    @Override // android.view.ViewGroup
    public final void startViewTransition(View view) {
        e0.c.e(view, "view");
        if (view.getParent() == this) {
            this.b.add(view);
        }
        super.startViewTransition(view);
    }
}
