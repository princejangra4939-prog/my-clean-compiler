package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.E;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class r extends E {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final F.d f686g = new F.d(18);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashMap f687c = new HashMap();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final HashMap f688d = new HashMap();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final HashMap f689e = new HashMap();
    public boolean f = false;

    public r(boolean z2) {
    }

    @Override // androidx.lifecycle.E
    public final void a() {
        if (p.h(3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.f = true;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && r.class == obj.getClass()) {
            r rVar = (r) obj;
            if (this.f687c.equals(rVar.f687c) && this.f688d.equals(rVar.f688d) && this.f689e.equals(rVar.f689e)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f689e.hashCode() + ((this.f688d.hashCode() + (this.f687c.hashCode() * 31)) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator it = this.f687c.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator it2 = this.f688d.keySet().iterator();
        while (it2.hasNext()) {
            sb.append((String) it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator it3 = this.f689e.keySet().iterator();
        while (it3.hasNext()) {
            sb.append((String) it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
