package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f701a;
    public boolean b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f702c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f703d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f704e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public androidx.lifecycle.l f705g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public androidx.lifecycle.l f706h;
}
