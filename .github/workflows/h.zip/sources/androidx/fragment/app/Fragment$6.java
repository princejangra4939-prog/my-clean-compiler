package androidx.fragment.app;

/* JADX INFO: loaded from: classes.dex */
class Fragment$6 implements androidx.lifecycle.o {
    @Override // androidx.lifecycle.o
    public final void b(androidx.lifecycle.q qVar, androidx.lifecycle.k kVar) {
        if (kVar == androidx.lifecycle.k.ON_STOP) {
            throw null;
        }
    }
}
