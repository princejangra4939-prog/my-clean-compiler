package androidx.versionedparcelable;

import D.m;
import S.b;
import S.c;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new m(2);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f785a;

    public ParcelImpl(Parcel parcel) {
        this.f785a = new b(parcel).g();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        new b(parcel).i(this.f785a);
    }
}
