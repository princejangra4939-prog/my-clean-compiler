package androidx.versionedparcelable;

import S.c;

/* JADX INFO: loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements c {
}
