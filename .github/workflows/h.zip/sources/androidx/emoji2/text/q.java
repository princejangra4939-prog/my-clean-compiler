package androidx.emoji2.text;

import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f581a = 1;
    public final t b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public t f582c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public t f583d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f584e;
    public int f;

    public q(t tVar) {
        this.b = tVar;
        this.f582c = tVar;
    }

    public final void a() {
        this.f581a = 1;
        this.f582c = this.b;
        this.f = 0;
    }

    public final boolean b() {
        F.a aVarB = this.f582c.b.b();
        int iA = aVarB.a(6);
        return !(iA == 0 || ((ByteBuffer) aVarB.f55d).get(iA + aVarB.f53a) == 0) || this.f584e == 65039;
    }
}
