package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public interface j {
    void p(D.g gVar);
}
