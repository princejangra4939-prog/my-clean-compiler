package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import e.C0019f;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import v.AbstractC0138b;
import v.C0143g;

/* JADX INFO: loaded from: classes.dex */
public final class r implements j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f585a;
    public final W.d b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final F.d f586c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f587d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Handler f588e;
    public ThreadPoolExecutor f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ThreadPoolExecutor f589g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public D.g f590h;

    public r(Context context, W.d dVar) {
        F.d dVar2 = s.f591d;
        this.f587d = new Object();
        D.g.d(context, "Context cannot be null");
        this.f585a = context.getApplicationContext();
        this.b = dVar;
        this.f586c = dVar2;
    }

    public final void a() {
        synchronized (this.f587d) {
            try {
                this.f590h = null;
                Handler handler = this.f588e;
                if (handler != null) {
                    handler.removeCallbacks(null);
                }
                this.f588e = null;
                ThreadPoolExecutor threadPoolExecutor = this.f589g;
                if (threadPoolExecutor != null) {
                    threadPoolExecutor.shutdown();
                }
                this.f = null;
                this.f589g = null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final C0143g b() {
        try {
            F.d dVar = this.f586c;
            Context context = this.f585a;
            W.d dVar2 = this.b;
            dVar.getClass();
            C0019f c0019fA = AbstractC0138b.a(context, dVar2);
            int i2 = c0019fA.f973a;
            if (i2 != 0) {
                throw new RuntimeException("fetchFonts failed (" + i2 + ")");
            }
            C0143g[] c0143gArr = (C0143g[]) c0019fA.b;
            if (c0143gArr == null || c0143gArr.length == 0) {
                throw new RuntimeException("fetchFonts failed (empty result)");
            }
            return c0143gArr[0];
        } catch (PackageManager.NameNotFoundException e2) {
            throw new RuntimeException("provider not found", e2);
        }
    }

    @Override // androidx.emoji2.text.j
    public final void p(D.g gVar) {
        synchronized (this.f587d) {
            this.f590h = gVar;
        }
        synchronized (this.f587d) {
            try {
                if (this.f590h == null) {
                    return;
                }
                if (this.f == null) {
                    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new a("emojiCompat"));
                    threadPoolExecutor.allowCoreThreadTimeOut(true);
                    this.f589g = threadPoolExecutor;
                    this.f = threadPoolExecutor;
                }
                this.f.execute(new androidx.activity.d(3, this));
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
