package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public final class s {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final F.d f591d = new F.d(16);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f592a;
    public int b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final e f593c = new e();

    public s(j jVar) {
        this.f592a = jVar;
    }
}
