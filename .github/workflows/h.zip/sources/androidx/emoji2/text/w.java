package androidx.emoji2.text;

import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public final class w {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final ThreadLocal f597d = new ThreadLocal();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f598a;
    public final T.t b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile int f599c = 0;

    public w(T.t tVar, int i2) {
        this.b = tVar;
        this.f598a = i2;
    }

    public final int a(int i2) {
        F.a aVarB = b();
        int iA = aVarB.a(16);
        if (iA == 0) {
            return 0;
        }
        ByteBuffer byteBuffer = (ByteBuffer) aVarB.f55d;
        int i3 = iA + aVarB.f53a;
        return byteBuffer.getInt((i2 * 4) + byteBuffer.getInt(i3) + i3 + 4);
    }

    public final F.a b() {
        ThreadLocal threadLocal = f597d;
        F.a aVar = (F.a) threadLocal.get();
        if (aVar == null) {
            aVar = new F.a();
            threadLocal.set(aVar);
        }
        F.b bVar = (F.b) this.b.f211a;
        int iA = bVar.a(6);
        if (iA != 0) {
            int i2 = iA + bVar.f53a;
            int i3 = (this.f598a * 4) + ((ByteBuffer) bVar.f55d).getInt(i2) + i2 + 4;
            int i4 = ((ByteBuffer) bVar.f55d).getInt(i3) + i3;
            ByteBuffer byteBuffer = (ByteBuffer) bVar.f55d;
            aVar.f55d = byteBuffer;
            if (byteBuffer != null) {
                aVar.f53a = i4;
                int i5 = i4 - byteBuffer.getInt(i4);
                aVar.b = i5;
                aVar.f54c = ((ByteBuffer) aVar.f55d).getShort(i5);
                return aVar;
            }
            aVar.f53a = 0;
            aVar.b = 0;
            aVar.f54c = 0;
        }
        return aVar;
    }

    public final String toString() {
        int i2;
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(", id:");
        F.a aVarB = b();
        int iA = aVarB.a(4);
        sb.append(Integer.toHexString(iA != 0 ? ((ByteBuffer) aVarB.f55d).getInt(iA + aVarB.f53a) : 0));
        sb.append(", codepoints:");
        F.a aVarB2 = b();
        int iA2 = aVarB2.a(16);
        if (iA2 != 0) {
            int i3 = iA2 + aVarB2.f53a;
            i2 = ((ByteBuffer) aVarB2.f55d).getInt(((ByteBuffer) aVarB2.f55d).getInt(i3) + i3);
        } else {
            i2 = 0;
        }
        for (int i4 = 0; i4 < i2; i4++) {
            sb.append(Integer.toHexString(a(i4)));
            sb.append(" ");
        }
        return sb.toString();
    }
}
