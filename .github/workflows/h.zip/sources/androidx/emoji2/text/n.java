package androidx.emoji2.text;

import android.os.Trace;
import u.AbstractC0136e;

/* JADX INFO: loaded from: classes.dex */
public final class n implements Runnable {
    @Override // java.lang.Runnable
    public final void run() {
        try {
            int i2 = AbstractC0136e.f1624a;
            Trace.beginSection("EmojiCompat.EmojiCompatInitializer.run");
            if (k.f569k != null) {
                k.a().c();
            }
            Trace.endSection();
        } catch (Throwable th) {
            int i3 = AbstractC0136e.f1624a;
            Trace.endSection();
            throw th;
        }
    }
}
