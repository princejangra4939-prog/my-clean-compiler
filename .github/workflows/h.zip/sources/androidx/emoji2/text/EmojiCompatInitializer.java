package androidx.emoji2.text;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.InterfaceC0004d;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class EmojiCompatInitializer implements N.b {
    @Override // N.b
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // N.b
    public final Object b(Context context) {
        Object objB;
        s sVar = new s(new C.j(context));
        sVar.b = 1;
        if (k.f569k == null) {
            synchronized (k.f568j) {
                try {
                    if (k.f569k == null) {
                        k.f569k = new k(sVar);
                    }
                } finally {
                }
            }
        }
        N.a aVarC = N.a.c(context);
        aVarC.getClass();
        synchronized (N.a.f122e) {
            try {
                objB = aVarC.f123a.get(ProcessLifecycleInitializer.class);
                if (objB == null) {
                    objB = aVarC.b(ProcessLifecycleInitializer.class, new HashSet());
                }
            } finally {
            }
        }
        final androidx.lifecycle.s sVarC = ((androidx.lifecycle.q) objB).c();
        sVarC.a(new InterfaceC0004d(this) { // from class: androidx.emoji2.text.EmojiCompatInitializer.1
            @Override // androidx.lifecycle.InterfaceC0004d
            public final void a() {
                (Build.VERSION.SDK_INT >= 28 ? c.a(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new n(), 500L);
                sVarC.f(this);
            }
        });
        return Boolean.TRUE;
    }
}
