package androidx.emoji2.text;

import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public abstract class o {
    public static Set<int[]> a() {
        return D.g.x();
    }
}
