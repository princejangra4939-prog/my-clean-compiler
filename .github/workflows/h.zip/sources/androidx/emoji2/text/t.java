package androidx.emoji2.text;

import android.util.SparseArray;

/* JADX INFO: loaded from: classes.dex */
public final class t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SparseArray f594a;
    public w b;

    public t(int i2) {
        this.f594a = new SparseArray(i2);
    }

    public final void a(w wVar, int i2, int i3) {
        int iA = wVar.a(i2);
        SparseArray sparseArray = this.f594a;
        t tVar = sparseArray == null ? null : (t) sparseArray.get(iA);
        if (tVar == null) {
            tVar = new t(1);
            sparseArray.put(wVar.a(i2), tVar);
        }
        if (i3 > i2) {
            tVar.a(wVar, i2 + 1, i3);
        } else {
            tVar.b = wVar;
        }
    }
}
