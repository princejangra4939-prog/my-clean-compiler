package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public interface p {
    boolean c(CharSequence charSequence, int i2, int i3, w wVar);

    Object i();
}
