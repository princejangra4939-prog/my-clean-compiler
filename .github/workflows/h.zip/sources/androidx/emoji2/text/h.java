package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public abstract class h {
    public abstract void a();
}
