package androidx.emoji2.text;

import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class i implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f567a;
    public final int b;

    public i(List list, int i2, Throwable th) {
        D.g.d(list, "initCallbacks cannot be null");
        this.f567a = new ArrayList(list);
        this.b = i2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ArrayList arrayList = this.f567a;
        int size = arrayList.size();
        int i2 = 0;
        if (this.b != 1) {
            while (i2 < size) {
                ((h) arrayList.get(i2)).getClass();
                i2++;
            }
        } else {
            while (i2 < size) {
                ((h) arrayList.get(i2)).a();
                i2++;
            }
        }
    }
}
