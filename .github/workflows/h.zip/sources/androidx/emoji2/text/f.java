package androidx.emoji2.text;

import android.os.Build;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class f extends D.g {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ g f564o;

    public f(g gVar) {
        this.f564o = gVar;
    }

    @Override // D.g
    public final void M(Throwable th) {
        this.f564o.f565a.d(th);
    }

    @Override // D.g
    public final void O(T.t tVar) {
        g gVar = this.f564o;
        gVar.f566c = tVar;
        T.t tVar2 = gVar.f566c;
        k kVar = gVar.f565a;
        gVar.b = new C.h(tVar2, kVar.f574g, kVar.f576i, Build.VERSION.SDK_INT >= 34 ? o.a() : D.g.x());
        k kVar2 = gVar.f565a;
        kVar2.getClass();
        ArrayList arrayList = new ArrayList();
        kVar2.f570a.writeLock().lock();
        try {
            kVar2.f571c = 1;
            arrayList.addAll(kVar2.b);
            kVar2.b.clear();
            kVar2.f570a.writeLock().unlock();
            kVar2.f572d.post(new i(arrayList, kVar2.f571c, null));
        } catch (Throwable th) {
            kVar2.f570a.writeLock().unlock();
            throw th;
        }
    }
}
