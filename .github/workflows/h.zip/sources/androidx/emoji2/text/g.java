package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final k f565a;
    public volatile C.h b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile T.t f566c;

    public g(k kVar) {
        this.f565a = kVar;
    }
}
