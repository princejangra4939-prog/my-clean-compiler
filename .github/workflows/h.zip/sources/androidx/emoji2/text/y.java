package androidx.emoji2.text;

/* JADX INFO: loaded from: classes.dex */
public final class y extends F.d {
    @Override // F.d
    public final boolean g(CharSequence charSequence) {
        return b.p(charSequence);
    }
}
