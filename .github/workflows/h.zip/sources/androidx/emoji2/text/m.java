package androidx.emoji2.text;

import java.util.concurrent.ThreadPoolExecutor;

/* JADX INFO: loaded from: classes.dex */
public final class m extends D.g {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ D.g f579o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ ThreadPoolExecutor f580p;

    public m(D.g gVar, ThreadPoolExecutor threadPoolExecutor) {
        this.f579o = gVar;
        this.f580p = threadPoolExecutor;
    }

    @Override // D.g
    public final void M(Throwable th) {
        ThreadPoolExecutor threadPoolExecutor = this.f580p;
        try {
            this.f579o.M(th);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }

    @Override // D.g
    public final void O(T.t tVar) {
        ThreadPoolExecutor threadPoolExecutor = this.f580p;
        try {
            this.f579o.O(tVar);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }
}
