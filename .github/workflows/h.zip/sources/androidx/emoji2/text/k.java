package androidx.emoji2.text;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import l.C0103c;

/* JADX INFO: loaded from: classes.dex */
public final class k {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final Object f568j = new Object();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static volatile k f569k;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ReentrantReadWriteLock f570a;
    public final C0103c b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public volatile int f571c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Handler f572d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final g f573e;
    public final j f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final F.d f574g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f575h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final e f576i;

    public k(s sVar) {
        ReentrantReadWriteLock reentrantReadWriteLock = new ReentrantReadWriteLock();
        this.f570a = reentrantReadWriteLock;
        this.f571c = 3;
        j jVar = sVar.f592a;
        this.f = jVar;
        int i2 = sVar.b;
        this.f575h = i2;
        this.f576i = sVar.f593c;
        this.f572d = new Handler(Looper.getMainLooper());
        this.b = new C0103c(0);
        this.f574g = new F.d(15);
        g gVar = new g(this);
        this.f573e = gVar;
        reentrantReadWriteLock.writeLock().lock();
        if (i2 == 0) {
            try {
                this.f571c = 0;
            } catch (Throwable th) {
                this.f570a.writeLock().unlock();
                throw th;
            }
        }
        reentrantReadWriteLock.writeLock().unlock();
        if (b() == 0) {
            try {
                jVar.p(new f(gVar));
            } catch (Throwable th2) {
                d(th2);
            }
        }
    }

    public static k a() {
        k kVar;
        synchronized (f568j) {
            try {
                kVar = f569k;
                if (!(kVar != null)) {
                    throw new IllegalStateException("EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
                }
            } finally {
            }
        }
        return kVar;
    }

    public final int b() {
        this.f570a.readLock().lock();
        try {
            return this.f571c;
        } finally {
            this.f570a.readLock().unlock();
        }
    }

    public final void c() {
        if (!(this.f575h == 1)) {
            throw new IllegalStateException("Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        }
        if (b() == 1) {
            return;
        }
        this.f570a.writeLock().lock();
        try {
            if (this.f571c == 0) {
                return;
            }
            this.f571c = 0;
            this.f570a.writeLock().unlock();
            g gVar = this.f573e;
            k kVar = gVar.f565a;
            try {
                kVar.f.p(new f(gVar));
            } catch (Throwable th) {
                kVar.d(th);
            }
        } finally {
            this.f570a.writeLock().unlock();
        }
    }

    public final void d(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f570a.writeLock().lock();
        try {
            this.f571c = 2;
            arrayList.addAll(this.b);
            this.b.clear();
            this.f570a.writeLock().unlock();
            this.f572d.post(new i(arrayList, this.f571c, th));
        } catch (Throwable th2) {
            this.f570a.writeLock().unlock();
            throw th2;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:111:? A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:113:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0086 A[Catch: all -> 0x0079, TRY_ENTER, TryCatch #1 {all -> 0x0079, blocks: (B:35:0x0051, B:38:0x0056, B:40:0x005a, B:42:0x0067, B:49:0x0086, B:51:0x0090, B:53:0x0093, B:55:0x0096, B:57:0x00a6, B:58:0x00a9), top: B:104:0x0051 }] */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0096 A[Catch: all -> 0x0079, TryCatch #1 {all -> 0x0079, blocks: (B:35:0x0051, B:38:0x0056, B:40:0x005a, B:42:0x0067, B:49:0x0086, B:51:0x0090, B:53:0x0093, B:55:0x0096, B:57:0x00a6, B:58:0x00a9), top: B:104:0x0051 }] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x00b8 A[Catch: all -> 0x00ed, TRY_ENTER, TryCatch #3 {all -> 0x00ed, blocks: (B:62:0x00b8, B:65:0x00c0, B:67:0x00c6, B:47:0x007c), top: B:108:0x007c }] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:87:0x00fa  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.CharSequence e(java.lang.CharSequence r11, int r12, int r13) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 306
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.emoji2.text.k.e(java.lang.CharSequence, int, int):java.lang.CharSequence");
    }

    public final void f(h hVar) {
        D.g.d(hVar, "initCallback cannot be null");
        this.f570a.writeLock().lock();
        try {
            if (this.f571c == 1 || this.f571c == 2) {
                this.f572d.post(new i(Arrays.asList(hVar), this.f571c, null));
            } else {
                this.b.add(hVar);
            }
            this.f570a.writeLock().unlock();
        } catch (Throwable th) {
            this.f570a.writeLock().unlock();
            throw th;
        }
    }
}
