package androidx.core.app;

import S.c;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: classes.dex */
public final class RemoteActionCompat implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IconCompat f516a;
    public CharSequence b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f517c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public PendingIntent f518d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f519e;
    public boolean f;
}
