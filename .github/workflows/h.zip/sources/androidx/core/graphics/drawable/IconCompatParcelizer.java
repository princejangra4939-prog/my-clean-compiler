package androidx.core.graphics.drawable;

import S.a;
import S.b;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;

/* JADX INFO: loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        int i2 = iconCompat.f525a;
        if (aVar.e(1)) {
            i2 = ((b) aVar).f163e.readInt();
        }
        iconCompat.f525a = i2;
        byte[] bArr = iconCompat.f526c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f163e;
            int i3 = parcel.readInt();
            if (i3 < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[i3];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f526c = bArr;
        iconCompat.f527d = aVar.f(iconCompat.f527d, 3);
        int i4 = iconCompat.f528e;
        if (aVar.e(4)) {
            i4 = ((b) aVar).f163e.readInt();
        }
        iconCompat.f528e = i4;
        int i5 = iconCompat.f;
        if (aVar.e(5)) {
            i5 = ((b) aVar).f163e.readInt();
        }
        iconCompat.f = i5;
        iconCompat.f529g = (ColorStateList) aVar.f(iconCompat.f529g, 6);
        String string = iconCompat.f531i;
        if (aVar.e(7)) {
            string = ((b) aVar).f163e.readString();
        }
        iconCompat.f531i = string;
        String string2 = iconCompat.f532j;
        if (aVar.e(8)) {
            string2 = ((b) aVar).f163e.readString();
        }
        iconCompat.f532j = string2;
        iconCompat.f530h = PorterDuff.Mode.valueOf(iconCompat.f531i);
        switch (iconCompat.f525a) {
            case -1:
                Parcelable parcelable = iconCompat.f527d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f527d;
                if (parcelable2 != null) {
                    iconCompat.b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f526c;
                iconCompat.b = bArr3;
                iconCompat.f525a = 3;
                iconCompat.f528e = 0;
                iconCompat.f = bArr3.length;
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str = new String(iconCompat.f526c, Charset.forName("UTF-16"));
                iconCompat.b = str;
                if (iconCompat.f525a == 2 && iconCompat.f532j == null) {
                    iconCompat.f532j = str.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.b = iconCompat.f526c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f531i = iconCompat.f530h.name();
        switch (iconCompat.f525a) {
            case -1:
                iconCompat.f527d = (Parcelable) iconCompat.b;
                break;
            case 1:
            case 5:
                iconCompat.f527d = (Parcelable) iconCompat.b;
                break;
            case 2:
                iconCompat.f526c = ((String) iconCompat.b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f526c = (byte[]) iconCompat.b;
                break;
            case 4:
            case 6:
                iconCompat.f526c = iconCompat.b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i2 = iconCompat.f525a;
        if (-1 != i2) {
            aVar.h(1);
            ((b) aVar).f163e.writeInt(i2);
        }
        byte[] bArr = iconCompat.f526c;
        if (bArr != null) {
            aVar.h(2);
            int length = bArr.length;
            Parcel parcel = ((b) aVar).f163e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f527d;
        if (parcelable != null) {
            aVar.h(3);
            ((b) aVar).f163e.writeParcelable(parcelable, 0);
        }
        int i3 = iconCompat.f528e;
        if (i3 != 0) {
            aVar.h(4);
            ((b) aVar).f163e.writeInt(i3);
        }
        int i4 = iconCompat.f;
        if (i4 != 0) {
            aVar.h(5);
            ((b) aVar).f163e.writeInt(i4);
        }
        ColorStateList colorStateList = iconCompat.f529g;
        if (colorStateList != null) {
            aVar.h(6);
            ((b) aVar).f163e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f531i;
        if (str != null) {
            aVar.h(7);
            ((b) aVar).f163e.writeString(str);
        }
        String str2 = iconCompat.f532j;
        if (str2 != null) {
            aVar.h(8);
            ((b) aVar).f163e.writeString(str2);
        }
    }
}
