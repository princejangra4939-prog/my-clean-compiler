package androidx.activity;

import androidx.lifecycle.B;
import androidx.lifecycle.D;
import androidx.lifecycle.E;
import androidx.lifecycle.F;
import androidx.lifecycle.G;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.ListIterator;

/* JADX INFO: loaded from: classes.dex */
public final class o extends e0.d implements d0.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f344a;
    public final /* synthetic */ Object b;

    public /* synthetic */ o(int i2, Object obj) {
        this.f344a = i2;
        this.b = obj;
    }

    @Override // d0.a
    public final Object a() {
        Object objPrevious;
        switch (this.f344a) {
            case 0:
                ((v) this.b).a();
                return X.c.f293c;
            case 1:
                v vVar = (v) this.b;
                Y.a aVar = vVar.b;
                ListIterator listIterator = aVar.listIterator(aVar.size());
                while (true) {
                    if (listIterator.hasPrevious()) {
                        objPrevious = listIterator.previous();
                        if (((androidx.fragment.app.k) objPrevious).f643a) {
                        }
                    } else {
                        objPrevious = null;
                    }
                }
                vVar.f359c = null;
                return X.c.f293c;
            case 2:
                ((v) this.b).a();
                return X.c.f293c;
            default:
                l lVar = (l) this.b;
                ArrayList arrayList = new ArrayList();
                e0.f.f1010a.getClass();
                Class clsA = new e0.b(D.class).a();
                e0.c.c(clsA, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-java>>");
                arrayList.add(new J.d(clsA));
                J.d[] dVarArr = (J.d[]) arrayList.toArray(new J.d[0]);
                J.d[] dVarArr2 = (J.d[]) Arrays.copyOf(dVarArr, dVarArr.length);
                e0.c.e(dVarArr2, "initializers");
                G gB = lVar.b();
                J.a aVar2 = J.a.b;
                e0.c.e(aVar2, "initialExtras");
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                linkedHashMap.putAll(aVar2.f75a);
                if (lVar.getApplication() != null) {
                    linkedHashMap.put(F.f718a, lVar.getApplication());
                }
                linkedHashMap.put(B.f709a, lVar);
                linkedHashMap.put(B.b, lVar);
                if (lVar.getIntent() != null && lVar.getIntent().getExtras() != null) {
                    linkedHashMap.put(B.f710c, lVar.getIntent().getExtras());
                }
                e0.c.e(gB, "store");
                LinkedHashMap linkedHashMap2 = gB.f719a;
                E e2 = (E) linkedHashMap2.get("androidx.lifecycle.internal.SavedStateHandlesVM");
                if (D.class.isInstance(e2)) {
                    e0.c.c(e2, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
                } else {
                    LinkedHashMap linkedHashMap3 = new LinkedHashMap();
                    linkedHashMap3.putAll(linkedHashMap);
                    linkedHashMap3.put(F.b, "androidx.lifecycle.internal.SavedStateHandlesVM");
                    try {
                        D d2 = null;
                        for (J.d dVar : dVarArr2) {
                            if (dVar.f76a.equals(D.class)) {
                                d2 = new D();
                            }
                        }
                        if (d2 == null) {
                            throw new IllegalArgumentException("No initializer set for given class ".concat(D.class.getName()));
                        }
                        E e3 = (E) linkedHashMap2.put("androidx.lifecycle.internal.SavedStateHandlesVM", d2);
                        if (e3 != null) {
                            e3.a();
                        }
                        e2 = d2;
                    } catch (AbstractMethodError unused) {
                        throw new UnsupportedOperationException("Factory.create(String) is unsupported.  This Factory requires `CreationExtras` to be passed into `create` method.");
                    }
                }
                return (D) e2;
        }
    }
}
