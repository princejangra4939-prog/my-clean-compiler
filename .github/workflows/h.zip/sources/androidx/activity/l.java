package androidx.activity;

import a.C0000a;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.A;
import androidx.lifecycle.C;
import androidx.lifecycle.G;
import androidx.lifecycle.H;
import androidx.lifecycle.SavedStateHandleAttacher;
import androidx.lifecycle.y;
import com.warppaiwarden.tictactoe.R;
import e.AbstractActivityC0022i;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import x.InterfaceC0149a;

/* JADX INFO: loaded from: classes.dex */
public abstract class l extends o.h implements H, M.g {
    public final C0000a b = new C0000a();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C.h f329c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final androidx.lifecycle.s f330d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final M.f f331e;
    public G f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public v f332g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final k f333h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final M.f f334i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final h f335j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final CopyOnWriteArrayList f336k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final CopyOnWriteArrayList f337l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final CopyOnWriteArrayList f338m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final CopyOnWriteArrayList f339n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final CopyOnWriteArrayList f340o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f341p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f342q;

    /* JADX WARN: Type inference failed for: r6v0, types: [androidx.activity.e] */
    public l() {
        final AbstractActivityC0022i abstractActivityC0022i = (AbstractActivityC0022i) this;
        this.f329c = new C.h(new d(0, abstractActivityC0022i));
        androidx.lifecycle.s sVar = new androidx.lifecycle.s(this);
        this.f330d = sVar;
        M.f fVar = new M.f(this);
        this.f331e = fVar;
        M.d dVar = null;
        this.f332g = null;
        k kVar = new k(abstractActivityC0022i);
        this.f333h = kVar;
        this.f334i = new M.f(kVar, new d0.a() { // from class: androidx.activity.e
            @Override // d0.a
            public final Object a() {
                abstractActivityC0022i.reportFullyDrawn();
                return null;
            }
        });
        new AtomicInteger();
        this.f335j = new h();
        this.f336k = new CopyOnWriteArrayList();
        this.f337l = new CopyOnWriteArrayList();
        this.f338m = new CopyOnWriteArrayList();
        this.f339n = new CopyOnWriteArrayList();
        this.f340o = new CopyOnWriteArrayList();
        this.f341p = false;
        this.f342q = false;
        sVar.a(new androidx.lifecycle.o() { // from class: androidx.activity.ComponentActivity$2
            @Override // androidx.lifecycle.o
            public final void b(androidx.lifecycle.q qVar, androidx.lifecycle.k kVar2) {
                if (kVar2 == androidx.lifecycle.k.ON_STOP) {
                    Window window = abstractActivityC0022i.getWindow();
                    View viewPeekDecorView = window != null ? window.peekDecorView() : null;
                    if (viewPeekDecorView != null) {
                        viewPeekDecorView.cancelPendingInputEvents();
                    }
                }
            }
        });
        sVar.a(new androidx.lifecycle.o() { // from class: androidx.activity.ComponentActivity$3
            @Override // androidx.lifecycle.o
            public final void b(androidx.lifecycle.q qVar, androidx.lifecycle.k kVar2) {
                if (kVar2 == androidx.lifecycle.k.ON_DESTROY) {
                    abstractActivityC0022i.b.b = null;
                    if (!abstractActivityC0022i.isChangingConfigurations()) {
                        abstractActivityC0022i.b().a();
                    }
                    k kVar3 = abstractActivityC0022i.f333h;
                    AbstractActivityC0022i abstractActivityC0022i2 = kVar3.f328d;
                    abstractActivityC0022i2.getWindow().getDecorView().removeCallbacks(kVar3);
                    abstractActivityC0022i2.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(kVar3);
                }
            }
        });
        sVar.a(new androidx.lifecycle.o() { // from class: androidx.activity.ComponentActivity$4
            @Override // androidx.lifecycle.o
            public final void b(androidx.lifecycle.q qVar, androidx.lifecycle.k kVar2) {
                AbstractActivityC0022i abstractActivityC0022i2 = abstractActivityC0022i;
                if (abstractActivityC0022i2.f == null) {
                    j jVar = (j) abstractActivityC0022i2.getLastNonConfigurationInstance();
                    if (jVar != null) {
                        abstractActivityC0022i2.f = jVar.f325a;
                    }
                    if (abstractActivityC0022i2.f == null) {
                        abstractActivityC0022i2.f = new G();
                    }
                }
                abstractActivityC0022i2.f330d.f(this);
            }
        });
        fVar.a();
        androidx.lifecycle.l lVar = sVar.f736c;
        if (lVar != androidx.lifecycle.l.b && lVar != androidx.lifecycle.l.f730c) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        M.e eVar = (M.e) fVar.f120c;
        eVar.getClass();
        Iterator it = ((k.f) eVar.f117d).iterator();
        while (true) {
            k.b bVar = (k.b) it;
            if (!bVar.hasNext()) {
                break;
            }
            Map.Entry entry = (Map.Entry) bVar.next();
            e0.c.d(entry, "components");
            String str = (String) entry.getKey();
            M.d dVar2 = (M.d) entry.getValue();
            if (e0.c.a(str, "androidx.lifecycle.internal.SavedStateHandlesProvider")) {
                dVar = dVar2;
                break;
            }
        }
        if (dVar == null) {
            C c2 = new C((M.e) this.f331e.f120c, this);
            ((M.e) this.f331e.f120c).e("androidx.lifecycle.internal.SavedStateHandlesProvider", c2);
            this.f330d.a(new SavedStateHandleAttacher(c2));
        }
        ((M.e) this.f331e.f120c).e("android:support:activity-result", new f(0, abstractActivityC0022i));
        f(new g(abstractActivityC0022i, 0));
    }

    @Override // M.g
    public final M.e a() {
        return (M.e) this.f331e.f120c;
    }

    @Override // androidx.lifecycle.H
    public final G b() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        if (this.f == null) {
            j jVar = (j) getLastNonConfigurationInstance();
            if (jVar != null) {
                this.f = jVar.f325a;
            }
            if (this.f == null) {
                this.f = new G();
            }
        }
        return this.f;
    }

    @Override // androidx.lifecycle.q
    public final androidx.lifecycle.s c() {
        return this.f330d;
    }

    public final void f(a.b bVar) {
        C0000a c0000a = this.b;
        c0000a.getClass();
        if (c0000a.b != null) {
            bVar.a();
        }
        c0000a.f303a.add(bVar);
    }

    public final v g() {
        if (this.f332g == null) {
            this.f332g = new v(new D.b(3, this));
            this.f330d.a(new androidx.lifecycle.o() { // from class: androidx.activity.ComponentActivity$6
                @Override // androidx.lifecycle.o
                public final void b(androidx.lifecycle.q qVar, androidx.lifecycle.k kVar) {
                    if (kVar != androidx.lifecycle.k.ON_CREATE || Build.VERSION.SDK_INT < 33) {
                        return;
                    }
                    v vVar = this.f307a.f332g;
                    OnBackInvokedDispatcher onBackInvokedDispatcherA = i.a((l) qVar);
                    vVar.getClass();
                    e0.c.e(onBackInvokedDispatcherA, "invoker");
                    vVar.f361e = onBackInvokedDispatcherA;
                    vVar.b(vVar.f362g);
                }
            });
        }
        return this.f332g;
    }

    public final void h() {
        View decorView = getWindow().getDecorView();
        e0.c.e(decorView, "<this>");
        decorView.setTag(R.id.view_tree_lifecycle_owner, this);
        View decorView2 = getWindow().getDecorView();
        e0.c.e(decorView2, "<this>");
        decorView2.setTag(R.id.view_tree_view_model_store_owner, this);
        View decorView3 = getWindow().getDecorView();
        e0.c.e(decorView3, "<this>");
        decorView3.setTag(R.id.view_tree_saved_state_registry_owner, this);
        View decorView4 = getWindow().getDecorView();
        e0.c.e(decorView4, "<this>");
        decorView4.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        View decorView5 = getWindow().getDecorView();
        e0.c.e(decorView5, "<this>");
        decorView5.setTag(R.id.report_drawn, this);
    }

    @Override // android.app.Activity
    public void onActivityResult(int i2, int i3, Intent intent) {
        if (this.f335j.a(i2, i3, intent)) {
            return;
        }
        super.onActivityResult(i2, i3, intent);
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        g().a();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Iterator it = this.f336k.iterator();
        while (it.hasNext()) {
            ((InterfaceC0149a) it.next()).a(configuration);
        }
    }

    @Override // o.h, android.app.Activity
    public void onCreate(Bundle bundle) {
        this.f331e.b(bundle);
        C0000a c0000a = this.b;
        c0000a.getClass();
        c0000a.b = this;
        Iterator it = c0000a.f303a.iterator();
        while (it.hasNext()) {
            ((a.b) it.next()).a();
        }
        super.onCreate(bundle);
        int i2 = A.b;
        y.b(this);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onCreatePanelMenu(int i2, Menu menu) {
        if (i2 != 0) {
            return true;
        }
        super.onCreatePanelMenu(i2, menu);
        getMenuInflater();
        this.f329c.n();
        return true;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i2, MenuItem menuItem) {
        if (super.onMenuItemSelected(i2, menuItem)) {
            return true;
        }
        if (i2 == 0) {
            this.f329c.o();
        }
        return false;
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z2) {
        if (this.f341p) {
            return;
        }
        Iterator it = this.f339n.iterator();
        while (it.hasNext()) {
            ((InterfaceC0149a) it.next()).a(new o.i(z2));
        }
    }

    @Override // android.app.Activity
    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Iterator it = this.f338m.iterator();
        while (it.hasNext()) {
            ((InterfaceC0149a) it.next()).a(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i2, Menu menu) {
        Iterator it = ((CopyOnWriteArrayList) this.f329c.b).iterator();
        while (it.hasNext()) {
            androidx.fragment.app.p pVar = ((androidx.fragment.app.l) it.next()).f646a;
            if (pVar.f670q >= 1) {
                Iterator it2 = pVar.f657c.d().iterator();
                while (it2.hasNext()) {
                    if (it2.next() != null) {
                        throw new ClassCastException();
                    }
                }
            }
        }
        super.onPanelClosed(i2, menu);
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z2) {
        if (this.f342q) {
            return;
        }
        Iterator it = this.f340o.iterator();
        while (it.hasNext()) {
            ((InterfaceC0149a) it.next()).a(new o.r(z2));
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onPreparePanel(int i2, View view, Menu menu) {
        if (i2 != 0) {
            return true;
        }
        super.onPreparePanel(i2, view, menu);
        this.f329c.p();
        return true;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (this.f335j.a(i2, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            return;
        }
        super.onRequestPermissionsResult(i2, strArr, iArr);
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        j jVar;
        G g2 = this.f;
        if (g2 == null && (jVar = (j) getLastNonConfigurationInstance()) != null) {
            g2 = jVar.f325a;
        }
        if (g2 == null) {
            return null;
        }
        j jVar2 = new j();
        jVar2.f325a = g2;
        return jVar2;
    }

    @Override // o.h, android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        androidx.lifecycle.s sVar = this.f330d;
        if (sVar != null) {
            androidx.lifecycle.l lVar = androidx.lifecycle.l.f730c;
            sVar.c("setCurrentState");
            sVar.e(lVar);
        }
        super.onSaveInstanceState(bundle);
        this.f331e.c(bundle);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i2) {
        super.onTrimMemory(i2);
        Iterator it = this.f337l.iterator();
        while (it.hasNext()) {
            ((InterfaceC0149a) it.next()).a(Integer.valueOf(i2));
        }
    }

    @Override // android.app.Activity
    public final void reportFullyDrawn() {
        try {
            if (D.g.G()) {
                Trace.beginSection("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            M.f fVar = this.f334i;
            synchronized (fVar.f119a) {
                try {
                    fVar.b = true;
                    ArrayList arrayList = (ArrayList) fVar.f120c;
                    int size = arrayList.size();
                    int i2 = 0;
                    while (i2 < size) {
                        Object obj = arrayList.get(i2);
                        i2++;
                        ((d0.a) obj).a();
                    }
                    ((ArrayList) fVar.f120c).clear();
                } finally {
                }
            }
            Trace.endSection();
        } catch (Throwable th) {
            Trace.endSection();
            throw th;
        }
    }

    @Override // android.app.Activity
    public void setContentView(View view) {
        h();
        View decorView = getWindow().getDecorView();
        k kVar = this.f333h;
        if (!kVar.f327c) {
            kVar.f327c = true;
            decorView.getViewTreeObserver().addOnDrawListener(kVar);
        }
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z2, Configuration configuration) {
        this.f341p = true;
        try {
            super.onMultiWindowModeChanged(z2, configuration);
            this.f341p = false;
            for (InterfaceC0149a interfaceC0149a : this.f339n) {
                e0.c.e(configuration, "newConfig");
                interfaceC0149a.a(new o.i(z2));
            }
        } catch (Throwable th) {
            this.f341p = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z2, Configuration configuration) {
        this.f342q = true;
        try {
            super.onPictureInPictureModeChanged(z2, configuration);
            this.f342q = false;
            for (InterfaceC0149a interfaceC0149a : this.f340o) {
                e0.c.e(configuration, "newConfig");
                interfaceC0149a.a(new o.r(z2));
            }
        } catch (Throwable th) {
            this.f342q = false;
            throw th;
        }
    }
}
