package androidx.activity;

import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

/* JADX INFO: loaded from: classes.dex */
public final class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final q f346a = new q();

    public final OnBackInvokedCallback a(d0.a aVar) {
        e0.c.e(aVar, "onBackInvoked");
        return new p(0, aVar);
    }

    public final void b(Object obj, int i2, Object obj2) {
        e0.c.e(obj, "dispatcher");
        e0.c.e(obj2, "callback");
        ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(i2, (OnBackInvokedCallback) obj2);
    }

    public final void c(Object obj, Object obj2) {
        e0.c.e(obj, "dispatcher");
        e0.c.e(obj2, "callback");
        ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
    }
}
