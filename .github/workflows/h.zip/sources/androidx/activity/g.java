package androidx.activity;

import android.os.Bundle;
import android.util.Log;
import e.AbstractActivityC0022i;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class g implements a.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f319a;
    public final /* synthetic */ AbstractActivityC0022i b;

    public /* synthetic */ g(AbstractActivityC0022i abstractActivityC0022i, int i2) {
        this.f319a = i2;
        this.b = abstractActivityC0022i;
    }

    @Override // a.b
    public final void a() {
        int i2;
        Bundle bundle;
        Bundle bundle2;
        switch (this.f319a) {
            case 0:
                AbstractActivityC0022i abstractActivityC0022i = this.b;
                Bundle bundleC = ((M.e) abstractActivityC0022i.f331e.f120c).c("android:support:activity-result");
                if (bundleC != null) {
                    h hVar = abstractActivityC0022i.f335j;
                    hVar.getClass();
                    ArrayList<Integer> integerArrayList = bundleC.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
                    ArrayList<String> stringArrayList = bundleC.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
                    if (stringArrayList == null || integerArrayList == null) {
                        return;
                    }
                    hVar.f322d = bundleC.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                    Bundle bundle3 = bundleC.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
                    Bundle bundle4 = hVar.f324g;
                    bundle4.putAll(bundle3);
                    for (int i3 = 0; i3 < stringArrayList.size(); i3++) {
                        String str = stringArrayList.get(i3);
                        HashMap map = hVar.b;
                        boolean zContainsKey = map.containsKey(str);
                        HashMap map2 = hVar.f320a;
                        if (zContainsKey) {
                            Integer num = (Integer) map.remove(str);
                            if (!bundle4.containsKey(str)) {
                                map2.remove(num);
                            }
                        }
                        Integer num2 = integerArrayList.get(i3);
                        num2.intValue();
                        String str2 = stringArrayList.get(i3);
                        map2.put(num2, str2);
                        map.put(str2, num2);
                    }
                    return;
                }
                return;
            default:
                androidx.fragment.app.f fVar = (androidx.fragment.app.f) this.b.f979r.b;
                androidx.fragment.app.p pVar = fVar.f635c;
                if (pVar.f671r != null) {
                    throw new IllegalStateException("Already attached");
                }
                pVar.f671r = fVar;
                pVar.f672s = fVar;
                pVar.f664k.add(fVar);
                AbstractActivityC0022i abstractActivityC0022i2 = fVar.f636d;
                v vVarG = abstractActivityC0022i2.g();
                pVar.f = vVarG;
                androidx.fragment.app.k kVar = pVar.f660g;
                vVarG.getClass();
                e0.c.e(kVar, "onBackPressedCallback");
                androidx.lifecycle.s sVarC = fVar.c();
                if (sVarC.f736c != androidx.lifecycle.l.f729a) {
                    kVar.b.add(new OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(vVarG, sVarC, kVar));
                    vVarG.c();
                    kVar.f644c = new u(0, vVarG);
                }
                androidx.fragment.app.r rVar = (androidx.fragment.app.r) new C.h(abstractActivityC0022i2.b(), androidx.fragment.app.r.f686g).g(androidx.fragment.app.r.class);
                pVar.f654E = rVar;
                T.t tVar = pVar.f657c;
                tVar.f213d = rVar;
                androidx.fragment.app.f fVar2 = pVar.f671r;
                if (fVar2 != null) {
                    M.e eVarA = fVar2.a();
                    eVarA.e("android:support:fragments", new f(2, pVar));
                    Bundle bundleC2 = eVarA.c("android:support:fragments");
                    if (bundleC2 != null) {
                        for (String str3 : bundleC2.keySet()) {
                            if (str3.startsWith("result_") && (bundle2 = bundleC2.getBundle(str3)) != null) {
                                bundle2.setClassLoader(pVar.f671r.f634a.getClassLoader());
                                pVar.f663j.put(str3.substring(7), bundle2);
                            }
                        }
                        ArrayList arrayList = new ArrayList();
                        for (String str4 : bundleC2.keySet()) {
                            if (str4.startsWith("fragment_") && (bundle = bundleC2.getBundle(str4)) != null) {
                                bundle.setClassLoader(pVar.f671r.f634a.getClassLoader());
                                arrayList.add((androidx.fragment.app.s) bundle.getParcelable("state"));
                            }
                        }
                        HashMap map3 = (HashMap) tVar.f212c;
                        map3.clear();
                        int size = arrayList.size();
                        int i4 = 0;
                        while (i4 < size) {
                            Object obj = arrayList.get(i4);
                            i4++;
                            androidx.fragment.app.s sVar = (androidx.fragment.app.s) obj;
                            map3.put(sVar.b, sVar);
                        }
                        androidx.fragment.app.q qVar = (androidx.fragment.app.q) bundleC2.getParcelable("state");
                        if (qVar != null) {
                            HashMap map4 = (HashMap) tVar.f211a;
                            map4.clear();
                            ArrayList arrayList2 = qVar.f680a;
                            int size2 = arrayList2.size();
                            int i5 = 0;
                            while (i5 < size2) {
                                Object obj2 = arrayList2.get(i5);
                                i5++;
                                androidx.fragment.app.s sVar2 = (androidx.fragment.app.s) map3.remove((String) obj2);
                                if (sVar2 != null) {
                                    if (pVar.f654E.f687c.get(sVar2.b) != null) {
                                        throw new ClassCastException();
                                    }
                                    ClassLoader classLoader = pVar.f671r.f634a.getClassLoader();
                                    pVar.f673t.a(sVar2.f690a);
                                    Bundle bundle5 = sVar2.f697j;
                                    if (bundle5 == null) {
                                        throw null;
                                    }
                                    bundle5.setClassLoader(classLoader);
                                    throw null;
                                }
                            }
                            androidx.fragment.app.r rVar2 = pVar.f654E;
                            rVar2.getClass();
                            Iterator it = new ArrayList(rVar2.f687c.values()).iterator();
                            if (it.hasNext()) {
                                it.next().getClass();
                                throw new ClassCastException();
                            }
                            ArrayList arrayList3 = qVar.b;
                            ((ArrayList) tVar.b).clear();
                            if (arrayList3 != null) {
                                Iterator it2 = arrayList3.iterator();
                                if (it2.hasNext()) {
                                    String str5 = (String) it2.next();
                                    L.d.a(map4.get(str5));
                                    throw new IllegalStateException("No instantiated fragment for (" + str5 + ")");
                                }
                            }
                            if (qVar.f681c != null) {
                                pVar.f658d = new ArrayList(qVar.f681c.length);
                                int i6 = 0;
                                while (true) {
                                    androidx.fragment.app.b[] bVarArr = qVar.f681c;
                                    if (i6 < bVarArr.length) {
                                        androidx.fragment.app.b bVar = bVarArr[i6];
                                        bVar.getClass();
                                        androidx.fragment.app.a aVar = new androidx.fragment.app.a(pVar);
                                        int i7 = 0;
                                        int i8 = 0;
                                        while (true) {
                                            int[] iArr = bVar.f620a;
                                            boolean z2 = true;
                                            if (i7 < iArr.length) {
                                                androidx.fragment.app.t tVar2 = new androidx.fragment.app.t();
                                                int i9 = i7 + 1;
                                                tVar2.f701a = iArr[i7];
                                                if (androidx.fragment.app.p.h(2)) {
                                                    Log.v("FragmentManager", "Instantiate " + aVar + " op #" + i8 + " base fragment #" + iArr[i9]);
                                                }
                                                tVar2.f705g = androidx.lifecycle.l.values()[bVar.f621c[i8]];
                                                tVar2.f706h = androidx.lifecycle.l.values()[bVar.f622d[i8]];
                                                int i10 = i7 + 2;
                                                if (iArr[i9] == 0) {
                                                    z2 = false;
                                                }
                                                tVar2.b = z2;
                                                int i11 = iArr[i10];
                                                tVar2.f702c = i11;
                                                int i12 = iArr[i7 + 3];
                                                tVar2.f703d = i12;
                                                int i13 = i7 + 5;
                                                int i14 = iArr[i7 + 4];
                                                tVar2.f704e = i14;
                                                i7 += 6;
                                                int i15 = iArr[i13];
                                                tVar2.f = i15;
                                                aVar.b = i11;
                                                aVar.f606c = i12;
                                                aVar.f607d = i14;
                                                aVar.f608e = i15;
                                                aVar.f605a.add(tVar2);
                                                tVar2.f702c = aVar.b;
                                                tVar2.f703d = aVar.f606c;
                                                tVar2.f704e = aVar.f607d;
                                                tVar2.f = aVar.f608e;
                                                i8++;
                                            } else {
                                                aVar.f = bVar.f623e;
                                                aVar.f610h = bVar.f;
                                                aVar.f609g = true;
                                                aVar.f611i = bVar.f625h;
                                                aVar.f612j = bVar.f626i;
                                                aVar.f613k = bVar.f627j;
                                                aVar.f614l = bVar.f628k;
                                                aVar.f615m = bVar.f629l;
                                                aVar.f616n = bVar.f630m;
                                                aVar.f617o = bVar.f631n;
                                                aVar.f619q = bVar.f624g;
                                                int i16 = 0;
                                                while (true) {
                                                    ArrayList arrayList4 = bVar.b;
                                                    if (i16 < arrayList4.size()) {
                                                        String str6 = (String) arrayList4.get(i16);
                                                        if (str6 != null) {
                                                            androidx.fragment.app.t tVar3 = (androidx.fragment.app.t) aVar.f605a.get(i16);
                                                            L.d.a(((HashMap) tVar.f211a).get(str6));
                                                            tVar3.getClass();
                                                        }
                                                        i16++;
                                                    } else {
                                                        aVar.a(1);
                                                        if (androidx.fragment.app.p.h(2)) {
                                                            Log.v("FragmentManager", "restoreAllState: back stack #" + i6 + " (index " + aVar.f619q + "): " + aVar);
                                                            PrintWriter printWriter = new PrintWriter(new androidx.fragment.app.u());
                                                            aVar.b("  ", printWriter, false);
                                                            printWriter.close();
                                                        }
                                                        pVar.f658d.add(aVar);
                                                        i6++;
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        i2 = 0;
                                    }
                                }
                            } else {
                                i2 = 0;
                                pVar.f658d = null;
                            }
                            pVar.f661h.set(qVar.f682d);
                            String str7 = qVar.f683e;
                            if (str7 != null) {
                                L.d.a(((HashMap) tVar.f211a).get(str7));
                            }
                            ArrayList arrayList5 = qVar.f;
                            if (arrayList5 != null) {
                                while (i2 < arrayList5.size()) {
                                    pVar.f662i.put((String) arrayList5.get(i2), (androidx.fragment.app.c) qVar.f684g.get(i2));
                                    i2++;
                                }
                            }
                            pVar.f677x = new ArrayDeque(qVar.f685h);
                        }
                    }
                }
                androidx.fragment.app.f fVar3 = pVar.f671r;
                if (fVar3 != null) {
                    AbstractActivityC0022i abstractActivityC0022i3 = fVar3.f636d;
                    androidx.fragment.app.n nVar = new androidx.fragment.app.n(2);
                    androidx.fragment.app.j jVar = new androidx.fragment.app.j(pVar, 1);
                    h hVar2 = abstractActivityC0022i3.f335j;
                    pVar.f674u = hVar2.b("FragmentManager:StartActivityForResult", nVar, jVar);
                    pVar.f675v = hVar2.b("FragmentManager:StartIntentSenderForResult", new androidx.fragment.app.n(0), new androidx.fragment.app.j(pVar, 2));
                    pVar.f676w = hVar2.b("FragmentManager:RequestPermissions", new androidx.fragment.app.n(1), new androidx.fragment.app.j(pVar, 0));
                }
                androidx.fragment.app.f fVar4 = pVar.f671r;
                if (fVar4 != null) {
                    fVar4.f636d.f336k.add(pVar.f665l);
                }
                androidx.fragment.app.f fVar5 = pVar.f671r;
                if (fVar5 != null) {
                    fVar5.f636d.f337l.add(pVar.f666m);
                }
                androidx.fragment.app.f fVar6 = pVar.f671r;
                if (fVar6 != null) {
                    fVar6.f636d.f339n.add(pVar.f667n);
                }
                androidx.fragment.app.f fVar7 = pVar.f671r;
                if (fVar7 != null) {
                    fVar7.f636d.f340o.add(pVar.f668o);
                }
                androidx.fragment.app.f fVar8 = pVar.f671r;
                if (fVar8 != null) {
                    C.h hVar3 = fVar8.f636d.f329c;
                    ((CopyOnWriteArrayList) hVar3.b).add(pVar.f669p);
                    ((Runnable) hVar3.f6a).run();
                    return;
                }
                return;
        }
    }
}
