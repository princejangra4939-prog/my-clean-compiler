package androidx.activity;

/* JADX INFO: loaded from: classes.dex */
final class OnBackPressedDispatcher$LifecycleOnBackPressedCancellable implements androidx.lifecycle.o, c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final androidx.lifecycle.s f309a;
    public final androidx.fragment.app.k b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public t f310c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ v f311d;

    public OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(v vVar, androidx.lifecycle.s sVar, androidx.fragment.app.k kVar) {
        e0.c.e(kVar, "onBackPressedCallback");
        this.f311d = vVar;
        this.f309a = sVar;
        this.b = kVar;
        sVar.a(this);
    }

    @Override // androidx.lifecycle.o
    public final void b(androidx.lifecycle.q qVar, androidx.lifecycle.k kVar) {
        if (kVar != androidx.lifecycle.k.ON_START) {
            if (kVar != androidx.lifecycle.k.ON_STOP) {
                if (kVar == androidx.lifecycle.k.ON_DESTROY) {
                    cancel();
                    return;
                }
                return;
            } else {
                t tVar = this.f310c;
                if (tVar != null) {
                    tVar.cancel();
                    return;
                }
                return;
            }
        }
        v vVar = this.f311d;
        vVar.getClass();
        androidx.fragment.app.k kVar2 = this.b;
        e0.c.e(kVar2, "onBackPressedCallback");
        vVar.b.addLast(kVar2);
        t tVar2 = new t(vVar, kVar2);
        kVar2.b.add(tVar2);
        vVar.c();
        kVar2.f644c = new u(1, vVar);
        this.f310c = tVar2;
    }

    @Override // androidx.activity.c
    public final void cancel() {
        this.f309a.f(this);
        this.b.b.remove(this);
        t tVar = this.f310c;
        if (tVar != null) {
            tVar.cancel();
        }
        this.f310c = null;
    }
}
