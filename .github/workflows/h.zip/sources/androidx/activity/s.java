package androidx.activity;

import android.window.OnBackInvokedCallback;

/* JADX INFO: loaded from: classes.dex */
public final class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final s f352a = new s();

    public final OnBackInvokedCallback a(d0.l lVar, d0.l lVar2, d0.a aVar, d0.a aVar2) {
        e0.c.e(lVar, "onBackStarted");
        e0.c.e(lVar2, "onBackProgressed");
        e0.c.e(aVar, "onBackInvoked");
        e0.c.e(aVar2, "onBackCancelled");
        return new r(lVar, lVar2, aVar, aVar2);
    }
}
