package androidx.activity;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;

/* JADX INFO: loaded from: classes.dex */
public final class r implements OnBackAnimationCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ d0.l f347a;
    public final /* synthetic */ d0.l b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ d0.a f348c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ d0.a f349d;

    public r(d0.l lVar, d0.l lVar2, d0.a aVar, d0.a aVar2) {
        this.f347a = lVar;
        this.b = lVar2;
        this.f348c = aVar;
        this.f349d = aVar2;
    }

    public final void onBackCancelled() {
        this.f349d.a();
    }

    public final void onBackInvoked() {
        this.f348c.a();
    }

    public final void onBackProgressed(BackEvent backEvent) {
        e0.c.e(backEvent, "backEvent");
        this.b.b(new b(backEvent));
    }

    public final void onBackStarted(BackEvent backEvent) {
        e0.c.e(backEvent, "backEvent");
        this.f347a.b(new b(backEvent));
    }
}
