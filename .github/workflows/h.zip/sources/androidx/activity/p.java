package androidx.activity;

import android.window.OnBackInvokedCallback;
import e.LayoutInflaterFactory2C0012B;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class p implements OnBackInvokedCallback {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f345a;
    public final /* synthetic */ Object b;

    public /* synthetic */ p(int i2, Object obj) {
        this.f345a = i2;
        this.b = obj;
    }

    public final void onBackInvoked() {
        switch (this.f345a) {
            case 0:
                d0.a aVar = (d0.a) this.b;
                e0.c.e(aVar, "$onBackInvoked");
                aVar.a();
                break;
            case 1:
                ((LayoutInflaterFactory2C0012B) this.b).D();
                break;
            default:
                ((Runnable) this.b).run();
                break;
        }
    }
}
