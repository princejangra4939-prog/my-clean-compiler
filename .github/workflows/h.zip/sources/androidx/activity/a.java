package androidx.activity;

import android.window.BackEvent;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f312a = new a();

    public final BackEvent a(float f, float f2, float f3, int i2) {
        return new BackEvent(f, f2, f3, i2);
    }

    public final float b(BackEvent backEvent) {
        e0.c.e(backEvent, "backEvent");
        return backEvent.getProgress();
    }

    public final int c(BackEvent backEvent) {
        e0.c.e(backEvent, "backEvent");
        return backEvent.getSwipeEdge();
    }

    public final float d(BackEvent backEvent) {
        e0.c.e(backEvent, "backEvent");
        return backEvent.getTouchX();
    }

    public final float e(BackEvent backEvent) {
        e0.c.e(backEvent, "backEvent");
        return backEvent.getTouchY();
    }
}
