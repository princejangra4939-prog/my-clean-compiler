package androidx.activity;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class u implements d0.a, Serializable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public transient u f354a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f355c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f356d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ int f357e;

    public u(int i2, Object obj) {
        this.f357e = i2;
        this.b = obj;
    }

    @Override // d0.a
    public final Object a() {
        switch (this.f357e) {
            case 0:
                ((v) this.b).c();
                break;
            default:
                ((v) this.b).c();
                break;
        }
        return X.c.f293c;
    }

    public final e0.a b() {
        if (this.f355c) {
            e0.f.f1010a.getClass();
            return new e0.e();
        }
        e0.f.f1010a.getClass();
        return new e0.b(v.class);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof u) {
            u uVar = (u) obj;
            uVar.getClass();
            return this.f356d == uVar.f356d && e0.c.a(this.b, uVar.b) && b().equals(uVar.b());
        }
        if (!(obj instanceof u)) {
            return false;
        }
        u uVar2 = this.f354a;
        if (uVar2 == null) {
            e0.f.f1010a.getClass();
            this.f354a = this;
            uVar2 = this;
        }
        return obj.equals(uVar2);
    }

    public final int hashCode() {
        b();
        return (((b().hashCode() * 31) + 986734966) * 31) + 1065238079;
    }

    public final String toString() {
        u uVar = this.f354a;
        if (uVar == null) {
            e0.f.f1010a.getClass();
            this.f354a = this;
            uVar = this;
        }
        return uVar != this ? uVar.toString() : "function updateEnabledCallbacks (Kotlin reflection is not available)";
    }
}
