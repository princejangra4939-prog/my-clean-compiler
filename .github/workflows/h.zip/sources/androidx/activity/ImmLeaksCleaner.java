package androidx.activity;

import android.view.inputmethod.InputMethodManager;

/* JADX INFO: loaded from: classes.dex */
final class ImmLeaksCleaner implements androidx.lifecycle.o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static int f308a;

    @Override // androidx.lifecycle.o
    public final void b(androidx.lifecycle.q qVar, androidx.lifecycle.k kVar) {
        if (kVar != androidx.lifecycle.k.ON_DESTROY) {
            return;
        }
        if (f308a == 0) {
            try {
                f308a = 2;
                InputMethodManager.class.getDeclaredField("mServedView").setAccessible(true);
                InputMethodManager.class.getDeclaredField("mNextServedView").setAccessible(true);
                InputMethodManager.class.getDeclaredField("mH").setAccessible(true);
                f308a = 1;
            } catch (NoSuchFieldException unused) {
            }
        }
        if (f308a == 1) {
            throw null;
        }
    }
}
