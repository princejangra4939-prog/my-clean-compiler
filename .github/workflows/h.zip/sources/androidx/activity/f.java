package androidx.activity;

import android.os.Bundle;
import android.util.Log;
import e.AbstractActivityC0022i;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class f implements M.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f318a;
    public final /* synthetic */ Object b;

    public /* synthetic */ f(int i2, Object obj) {
        this.f318a = i2;
        this.b = obj;
    }

    @Override // M.d
    public final Bundle a() {
        ArrayList arrayList;
        androidx.fragment.app.b[] bVarArr;
        int size;
        switch (this.f318a) {
            case 0:
                AbstractActivityC0022i abstractActivityC0022i = (AbstractActivityC0022i) this.b;
                Bundle bundle = new Bundle();
                h hVar = abstractActivityC0022i.f335j;
                hVar.getClass();
                HashMap map = hVar.b;
                bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(map.values()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(map.keySet()));
                bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(hVar.f322d));
                bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) hVar.f324g.clone());
                return bundle;
            case 1:
                AbstractActivityC0022i abstractActivityC0022i2 = (AbstractActivityC0022i) this.b;
                Iterator it = ((androidx.fragment.app.f) abstractActivityC0022i2.f979r.b).f635c.f657c.d().iterator();
                while (it.hasNext()) {
                    if (it.next() != null) {
                        throw new ClassCastException();
                    }
                }
                abstractActivityC0022i2.f980s.d(androidx.lifecycle.k.ON_STOP);
                return new Bundle();
            default:
                androidx.fragment.app.p pVar = (androidx.fragment.app.p) this.b;
                pVar.getClass();
                Bundle bundle2 = new Bundle();
                Iterator it2 = pVar.b().iterator();
                while (it2.hasNext()) {
                    ((androidx.fragment.app.v) it2.next()).getClass();
                }
                Iterator it3 = pVar.b().iterator();
                if (it3.hasNext()) {
                    ((androidx.fragment.app.v) it3.next()).a();
                    throw null;
                }
                pVar.e(true);
                pVar.f678y = true;
                pVar.f654E.getClass();
                T.t tVar = pVar.f657c;
                tVar.getClass();
                HashMap map2 = (HashMap) tVar.f211a;
                ArrayList arrayList2 = new ArrayList(map2.size());
                Iterator it4 = map2.values().iterator();
                while (it4.hasNext()) {
                    if (it4.next() != null) {
                        throw new ClassCastException();
                    }
                }
                T.t tVar2 = pVar.f657c;
                tVar2.getClass();
                ArrayList arrayList3 = new ArrayList(((HashMap) tVar2.f212c).values());
                if (!arrayList3.isEmpty()) {
                    T.t tVar3 = pVar.f657c;
                    synchronized (((ArrayList) tVar3.b)) {
                        try {
                            if (((ArrayList) tVar3.b).isEmpty()) {
                                arrayList = null;
                            } else {
                                arrayList = new ArrayList(((ArrayList) tVar3.b).size());
                                Iterator it5 = ((ArrayList) tVar3.b).iterator();
                                if (it5.hasNext()) {
                                    if (it5.next() == null) {
                                        throw null;
                                    }
                                    throw new ClassCastException();
                                }
                            }
                        } finally {
                        }
                    }
                    ArrayList arrayList4 = pVar.f658d;
                    int i2 = 0;
                    if (arrayList4 == null || (size = arrayList4.size()) <= 0) {
                        bVarArr = null;
                    } else {
                        bVarArr = new androidx.fragment.app.b[size];
                        for (int i3 = 0; i3 < size; i3++) {
                            bVarArr[i3] = new androidx.fragment.app.b((androidx.fragment.app.a) pVar.f658d.get(i3));
                            if (androidx.fragment.app.p.h(2)) {
                                Log.v("FragmentManager", "saveAllState: adding back stack #" + i3 + ": " + pVar.f658d.get(i3));
                            }
                        }
                    }
                    androidx.fragment.app.q qVar = new androidx.fragment.app.q();
                    qVar.f683e = null;
                    ArrayList arrayList5 = new ArrayList();
                    qVar.f = arrayList5;
                    ArrayList arrayList6 = new ArrayList();
                    qVar.f684g = arrayList6;
                    qVar.f680a = arrayList2;
                    qVar.b = arrayList;
                    qVar.f681c = bVarArr;
                    qVar.f682d = pVar.f661h.get();
                    arrayList5.addAll(pVar.f662i.keySet());
                    arrayList6.addAll(pVar.f662i.values());
                    qVar.f685h = new ArrayList(pVar.f677x);
                    bundle2.putParcelable("state", qVar);
                    for (String str : pVar.f663j.keySet()) {
                        bundle2.putBundle("result_" + str, (Bundle) pVar.f663j.get(str));
                    }
                    int size2 = arrayList3.size();
                    while (i2 < size2) {
                        Object obj = arrayList3.get(i2);
                        i2++;
                        androidx.fragment.app.s sVar = (androidx.fragment.app.s) obj;
                        Bundle bundle3 = new Bundle();
                        bundle3.putParcelable("state", sVar);
                        bundle2.putBundle("fragment_" + sVar.b, bundle3);
                    }
                } else if (androidx.fragment.app.p.h(2)) {
                    Log.v("FragmentManager", "saveAllState: no fragments!");
                }
                return bundle2;
        }
    }
}
