package androidx.activity;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Trace;
import androidx.lifecycle.x;
import e.AbstractActivityC0022i;
import e.DialogC0020g;
import i.U;
import java.lang.reflect.Method;
import java.nio.MappedByteBuffer;
import u.AbstractC0136e;
import v.C0143g;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f316a;
    public final /* synthetic */ Object b;

    public /* synthetic */ d(int i2, Object obj) {
        this.f316a = i2;
        this.b = obj;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v10 */
    /* JADX WARN: Type inference failed for: r3v11 */
    /* JADX WARN: Type inference failed for: r3v12 */
    /* JADX WARN: Type inference failed for: r3v13 */
    /* JADX WARN: Type inference failed for: r3v3 */
    /* JADX WARN: Type inference failed for: r3v4 */
    /* JADX WARN: Type inference failed for: r3v5, types: [android.os.Handler] */
    /* JADX WARN: Type inference failed for: r3v6 */
    /* JADX WARN: Type inference failed for: r3v7, types: [android.os.Handler] */
    /* JADX WARN: Type inference failed for: r3v9 */
    /* JADX WARN: Type inference failed for: r5v10 */
    /* JADX WARN: Type inference failed for: r5v3, types: [int] */
    /* JADX WARN: Type inference failed for: r5v4 */
    /* JADX WARN: Type inference failed for: r5v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v6 */
    /* JADX WARN: Type inference failed for: r5v7, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r5v8 */
    /* JADX WARN: Type inference failed for: r5v9 */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v12 */
    /* JADX WARN: Type inference failed for: r6v5 */
    /* JADX WARN: Type inference failed for: r6v6 */
    /* JADX WARN: Type inference failed for: r6v7, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v8 */
    /* JADX WARN: Type inference failed for: r6v9, types: [java.lang.Object] */
    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        ?? r3 = 1;
        r3 = 1;
        switch (this.f316a) {
            case 0:
                ((AbstractActivityC0022i) this.b).invalidateOptionsMenu();
                return;
            case 1:
                k kVar = (k) this.b;
                Runnable runnable = kVar.b;
                if (runnable != null) {
                    runnable.run();
                    kVar.b = null;
                    return;
                }
                return;
            case 2:
                DialogC0020g.b((DialogC0020g) this.b);
                return;
            case 3:
                androidx.emoji2.text.r rVar = (androidx.emoji2.text.r) this.b;
                synchronized (rVar.f587d) {
                    try {
                        if (rVar.f590h == null) {
                            return;
                        }
                        try {
                            C0143g c0143gB = rVar.b();
                            int i2 = c0143gB.f1638e;
                            if (i2 == 2) {
                                synchronized (rVar.f587d) {
                                }
                            }
                            if (i2 != 0) {
                                throw new RuntimeException("fetchFonts result is not OK. (" + i2 + ")");
                            }
                            try {
                                int i3 = AbstractC0136e.f1624a;
                                Trace.beginSection("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                                F.d dVar = rVar.f586c;
                                Context context = rVar.f585a;
                                dVar.getClass();
                                Typeface typefaceM = r.f.f1604a.m(context, new C0143g[]{c0143gB}, 0);
                                MappedByteBuffer mappedByteBufferH = D.g.H(rVar.f585a, c0143gB.f1635a);
                                if (mappedByteBufferH == null || typefaceM == null) {
                                    throw new RuntimeException("Unable to open file.");
                                }
                                try {
                                    Trace.beginSection("EmojiCompat.MetadataRepo.create");
                                    T.t tVar = new T.t(typefaceM, D.g.X(mappedByteBufferH));
                                    Trace.endSection();
                                    Trace.endSection();
                                    synchronized (rVar.f587d) {
                                        try {
                                            D.g gVar = rVar.f590h;
                                            if (gVar != null) {
                                                gVar.O(tVar);
                                            }
                                        } finally {
                                        }
                                        break;
                                    }
                                    rVar.a();
                                    return;
                                } finally {
                                    int i4 = AbstractC0136e.f1624a;
                                    Trace.endSection();
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                            break;
                        } catch (Throwable th2) {
                            synchronized (rVar.f587d) {
                                try {
                                    D.g gVar2 = rVar.f590h;
                                    if (gVar2 != null) {
                                        gVar2.M(th2);
                                    }
                                    rVar.a();
                                    return;
                                } finally {
                                }
                            }
                        }
                    } finally {
                    }
                }
            case 4:
                x xVar = (x) this.b;
                e0.c.e(xVar, "this$0");
                int i5 = xVar.b;
                androidx.lifecycle.s sVar = xVar.f;
                if (i5 == 0) {
                    xVar.f744c = true;
                    sVar.d(androidx.lifecycle.k.ON_PAUSE);
                }
                if (xVar.f743a == 0 && xVar.f744c) {
                    sVar.d(androidx.lifecycle.k.ON_STOP);
                    xVar.f745d = true;
                    return;
                }
                return;
            case 5:
                Activity activity = (Activity) this.b;
                if (activity.isFinishing()) {
                    return;
                }
                ?? r5 = Build.VERSION.SDK_INT;
                if (r5 >= 28) {
                    Class cls = o.d.f1555a;
                    activity.recreate();
                    return;
                }
                Class cls2 = o.d.f1555a;
                ?? r6 = 27;
                boolean z2 = r5 == 26 || r5 == 27;
                Method method = o.d.f;
                if ((!z2 || method != null) && (o.d.f1558e != null || o.d.f1557d != null)) {
                    try {
                        Object obj2 = o.d.f1556c.get(activity);
                        if (obj2 != null && (obj = o.d.b.get(activity)) != null) {
                            Application application = activity.getApplication();
                            o.c cVar = new o.c(activity);
                            application.registerActivityLifecycleCallbacks(cVar);
                            Handler handler = o.d.f1559g;
                            handler.post(new T.c(cVar, 1, obj2));
                            if (r5 != 26 && r5 != 27) {
                                r3 = 0;
                            }
                            try {
                                if (r3 != 0) {
                                    Handler handler2 = handler;
                                    try {
                                        Boolean bool = Boolean.FALSE;
                                        r5 = application;
                                        r6 = cVar;
                                        method.invoke(obj, obj2, null, null, 0, bool, null, null, bool, bool);
                                        r3 = handler2;
                                    } catch (Throwable th3) {
                                        th = th3;
                                        ?? r52 = application;
                                        ?? r62 = cVar;
                                        ?? r32 = handler2;
                                        r32.post(new T.c(r52, 2, r62));
                                        throw th;
                                    }
                                } else {
                                    r5 = application;
                                    r6 = cVar;
                                    r3 = handler;
                                    activity.recreate();
                                }
                                r3.post(new T.c(r5, 2, r6));
                                return;
                            } catch (Throwable th4) {
                                th = th4;
                            }
                        }
                    } catch (Throwable unused) {
                    }
                }
                activity.recreate();
                return;
            default:
                ((U) this.b).getClass();
                return;
        }
    }
}
