package androidx.activity;

import android.window.BackEvent;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f313a;
    public final float b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f314c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f315d;

    public b(BackEvent backEvent) {
        a aVar = a.f312a;
        float fD = aVar.d(backEvent);
        float fE = aVar.e(backEvent);
        float fB = aVar.b(backEvent);
        int iC = aVar.c(backEvent);
        this.f313a = fD;
        this.b = fE;
        this.f314c = fB;
        this.f315d = iC;
    }

    public final String toString() {
        return "BackEventCompat{touchX=" + this.f313a + ", touchY=" + this.b + ", progress=" + this.f314c + ", swipeEdge=" + this.f315d + '}';
    }
}
