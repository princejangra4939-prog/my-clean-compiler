package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;

/* JADX INFO: loaded from: classes.dex */
public final class v {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Runnable f358a;
    public final Y.a b = new Y.a();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public androidx.fragment.app.k f359c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final OnBackInvokedCallback f360d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public OnBackInvokedDispatcher f361e;
    public boolean f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f362g;

    public v(Runnable runnable) {
        this.f358a = runnable;
        int i2 = Build.VERSION.SDK_INT;
        if (i2 >= 33) {
            this.f360d = i2 >= 34 ? s.f352a.a(new n(this, 0), new n(this, 1), new o(0, this), new o(1, this)) : q.f346a.a(new o(2, this));
        }
    }

    public final void a() {
        Object objPrevious;
        Y.a aVar = this.b;
        aVar.getClass();
        ListIterator listIterator = aVar.listIterator(aVar.f297c);
        while (true) {
            if (listIterator.hasPrevious()) {
                objPrevious = listIterator.previous();
                if (((androidx.fragment.app.k) objPrevious).f643a) {
                    break;
                }
            } else {
                objPrevious = null;
                break;
            }
        }
        androidx.fragment.app.k kVar = (androidx.fragment.app.k) objPrevious;
        this.f359c = null;
        if (kVar == null) {
            this.f358a.run();
            return;
        }
        androidx.fragment.app.p pVar = kVar.f645d;
        pVar.e(true);
        if (!pVar.f660g.f643a) {
            pVar.f.a();
            return;
        }
        pVar.e(false);
        pVar.d(true);
        ArrayList arrayList = pVar.f651B;
        ArrayList arrayList2 = pVar.f652C;
        ArrayList arrayList3 = pVar.f658d;
        int size = (arrayList3 == null || arrayList3.isEmpty()) ? -1 : pVar.f658d.size() - 1;
        if (size >= 0) {
            for (int size2 = pVar.f658d.size() - 1; size2 >= size; size2--) {
                arrayList.add((androidx.fragment.app.a) pVar.f658d.remove(size2));
                arrayList2.add(Boolean.TRUE);
            }
            pVar.b = true;
            try {
                pVar.j(pVar.f651B, pVar.f652C);
            } finally {
                pVar.a();
            }
        }
        pVar.k();
        ((HashMap) pVar.f657c.f211a).values().removeAll(Collections.singleton(null));
    }

    public final void b(boolean z2) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f361e;
        OnBackInvokedCallback onBackInvokedCallback = this.f360d;
        if (onBackInvokedDispatcher == null || onBackInvokedCallback == null) {
            return;
        }
        q qVar = q.f346a;
        if (z2 && !this.f) {
            qVar.b(onBackInvokedDispatcher, 0, onBackInvokedCallback);
            this.f = true;
        } else {
            if (z2 || !this.f) {
                return;
            }
            qVar.c(onBackInvokedDispatcher, onBackInvokedCallback);
            this.f = false;
        }
    }

    public final void c() {
        boolean z2 = this.f362g;
        boolean z3 = false;
        Y.a aVar = this.b;
        if (aVar == null || !aVar.isEmpty()) {
            Iterator it = aVar.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                } else if (((androidx.fragment.app.k) it.next()).f643a) {
                    z3 = true;
                    break;
                }
            }
        }
        this.f362g = z3;
        if (z3 == z2 || Build.VERSION.SDK_INT < 33) {
            return;
        }
        b(z3);
    }
}
