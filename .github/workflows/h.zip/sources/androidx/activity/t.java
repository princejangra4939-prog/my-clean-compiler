package androidx.activity;

/* JADX INFO: loaded from: classes.dex */
public final class t implements c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final androidx.fragment.app.k f353a;
    public final /* synthetic */ v b;

    public t(v vVar, androidx.fragment.app.k kVar) {
        e0.c.e(kVar, "onBackPressedCallback");
        this.b = vVar;
        this.f353a = kVar;
    }

    @Override // androidx.activity.c
    public final void cancel() {
        v vVar = this.b;
        Y.a aVar = vVar.b;
        androidx.fragment.app.k kVar = this.f353a;
        aVar.remove(kVar);
        if (e0.c.a(vVar.f359c, kVar)) {
            kVar.getClass();
            vVar.f359c = null;
        }
        kVar.b.remove(this);
        u uVar = kVar.f644c;
        if (uVar != null) {
            uVar.a();
        }
        kVar.f644c = null;
    }
}
