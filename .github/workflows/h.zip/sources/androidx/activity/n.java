package androidx.activity;

import java.util.ListIterator;

/* JADX INFO: loaded from: classes.dex */
public final class n extends e0.d implements d0.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f343a;
    public final /* synthetic */ v b;

    public /* synthetic */ n(v vVar, int i2) {
        this.f343a = i2;
        this.b = vVar;
    }

    @Override // d0.l
    public final Object b(Object obj) {
        Object objPrevious;
        Object objPrevious2;
        switch (this.f343a) {
            case 0:
                v vVar = this.b;
                Y.a aVar = vVar.b;
                aVar.getClass();
                ListIterator listIterator = aVar.listIterator(aVar.f297c);
                while (true) {
                    if (listIterator.hasPrevious()) {
                        objPrevious = listIterator.previous();
                        if (((androidx.fragment.app.k) objPrevious).f643a) {
                        }
                    } else {
                        objPrevious = null;
                    }
                }
                vVar.f359c = (androidx.fragment.app.k) objPrevious;
                break;
            default:
                Y.a aVar2 = this.b.b;
                aVar2.getClass();
                ListIterator listIterator2 = aVar2.listIterator(aVar2.f297c);
                while (true) {
                    if (listIterator2.hasPrevious()) {
                        objPrevious2 = listIterator2.previous();
                        if (((androidx.fragment.app.k) objPrevious2).f643a) {
                        }
                    } else {
                        objPrevious2 = null;
                    }
                }
                break;
        }
        return X.c.f293c;
    }
}
