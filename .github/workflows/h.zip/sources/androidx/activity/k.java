package androidx.activity;

import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewTreeObserver;
import e.AbstractActivityC0022i;
import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class k implements Executor, ViewTreeObserver.OnDrawListener, Runnable {
    public Runnable b;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ AbstractActivityC0022i f328d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final long f326a = SystemClock.uptimeMillis() + 10000;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f327c = false;

    public k(AbstractActivityC0022i abstractActivityC0022i) {
        this.f328d = abstractActivityC0022i;
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.b = runnable;
        View decorView = this.f328d.getWindow().getDecorView();
        if (!this.f327c) {
            decorView.postOnAnimation(new d(1, this));
        } else if (Looper.myLooper() == Looper.getMainLooper()) {
            decorView.invalidate();
        } else {
            decorView.postInvalidate();
        }
    }

    @Override // android.view.ViewTreeObserver.OnDrawListener
    public final void onDraw() {
        boolean z2;
        Runnable runnable = this.b;
        if (runnable == null) {
            if (SystemClock.uptimeMillis() > this.f326a) {
                this.f327c = false;
                this.f328d.getWindow().getDecorView().post(this);
                return;
            }
            return;
        }
        runnable.run();
        this.b = null;
        M.f fVar = this.f328d.f334i;
        synchronized (fVar.f119a) {
            z2 = fVar.b;
        }
        if (z2) {
            this.f327c = false;
            this.f328d.getWindow().getDecorView().post(this);
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f328d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
}
