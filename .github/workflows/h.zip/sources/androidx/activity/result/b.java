package androidx.activity.result;

import D.g;
import androidx.fragment.app.j;

/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final j f351a;
    public final g b;

    public b(j jVar, g gVar) {
        this.f351a = jVar;
        this.b = gVar;
    }
}
