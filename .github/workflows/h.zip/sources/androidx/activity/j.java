package androidx.activity;

import androidx.lifecycle.G;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public G f325a;
}
