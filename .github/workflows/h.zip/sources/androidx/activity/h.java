package androidx.activity;

import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f320a = new HashMap();
    public final HashMap b = new HashMap();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final HashMap f321c = new HashMap();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList f322d = new ArrayList();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final transient HashMap f323e = new HashMap();
    public final HashMap f = new HashMap();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Bundle f324g = new Bundle();

    public final boolean a(int i2, int i3, Intent intent) {
        String str = (String) this.f320a.get(Integer.valueOf(i2));
        if (str == null) {
            return false;
        }
        androidx.activity.result.b bVar = (androidx.activity.result.b) this.f323e.get(str);
        if (bVar != null) {
            androidx.fragment.app.j jVar = bVar.f351a;
            if (this.f322d.contains(str)) {
                jVar.a(bVar.b.U(i3, intent));
                this.f322d.remove(str);
                return true;
            }
        }
        this.f.remove(str);
        this.f324g.putParcelable(str, new androidx.activity.result.a(i3, intent));
        return true;
    }

    public final G.a b(String str, D.g gVar, androidx.fragment.app.j jVar) {
        int i2;
        HashMap map;
        HashMap map2 = this.b;
        if (((Integer) map2.get(str)) == null) {
            int iB = f0.a.f1011a.b();
            while (true) {
                i2 = iB + 65536;
                map = this.f320a;
                if (!map.containsKey(Integer.valueOf(i2))) {
                    break;
                }
                iB = f0.a.f1011a.b();
            }
            map.put(Integer.valueOf(i2), str);
            map2.put(str, Integer.valueOf(i2));
        }
        this.f323e.put(str, new androidx.activity.result.b(jVar, gVar));
        HashMap map3 = this.f;
        if (map3.containsKey(str)) {
            Object obj = map3.get(str);
            map3.remove(str);
            jVar.a(obj);
        }
        Bundle bundle = this.f324g;
        androidx.activity.result.a aVar = (androidx.activity.result.a) bundle.getParcelable(str);
        if (aVar != null) {
            bundle.remove(str);
            jVar.a(gVar.U(aVar.f350a, aVar.b));
        }
        return new G.a(this, str, false);
    }
}
