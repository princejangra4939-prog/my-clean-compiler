package androidx.profileinstaller;

import F.d;
import L.h;
import L.k;
import N.b;
import android.content.Context;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class ProfileInstallerInitializer implements b {
    @Override // N.b
    public final List a() {
        return Collections.EMPTY_LIST;
    }

    @Override // N.b
    public final Object b(Context context) {
        k.a(new h(this, 0, context.getApplicationContext()));
        return new d(6);
    }
}
