package i;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.warppaiwarden.tictactoe.R;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: renamed from: i.t0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0085t0 extends ListView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Rect f1435a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1436c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1437d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1438e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public C0081r0 f1439g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1440h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f1441i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1442j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public D.i f1443k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public D.b f1444l;

    public C0085t0(Context context, boolean z2) {
        super(context, null, R.attr.dropDownListViewStyle);
        this.f1435a = new Rect();
        this.b = 0;
        this.f1436c = 0;
        this.f1437d = 0;
        this.f1438e = 0;
        this.f1441i = z2;
        setCacheColorHint(0);
    }

    public final int a(int i2, int i3) {
        int listPaddingTop = getListPaddingTop();
        int listPaddingBottom = getListPaddingBottom();
        int dividerHeight = getDividerHeight();
        Drawable divider = getDivider();
        ListAdapter adapter = getAdapter();
        if (adapter == null) {
            return listPaddingTop + listPaddingBottom;
        }
        int measuredHeight = listPaddingTop + listPaddingBottom;
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        int count = adapter.getCount();
        int i4 = 0;
        View view = null;
        for (int i5 = 0; i5 < count; i5++) {
            int itemViewType = adapter.getItemViewType(i5);
            if (itemViewType != i4) {
                view = null;
                i4 = itemViewType;
            }
            view = adapter.getView(i5, view, this);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams);
            }
            int i6 = layoutParams.height;
            view.measure(i2, i6 > 0 ? View.MeasureSpec.makeMeasureSpec(i6, 1073741824) : View.MeasureSpec.makeMeasureSpec(0, 0));
            view.forceLayout();
            if (i5 > 0) {
                measuredHeight += dividerHeight;
            }
            measuredHeight += view.getMeasuredHeight();
            if (measuredHeight >= i3) {
                return i3;
            }
        }
        return measuredHeight;
    }

    /* JADX WARN: Removed duplicated region for block: B:82:0x014c  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x0162  */
    /* JADX WARN: Removed duplicated region for block: B:86:0x0167  */
    /* JADX WARN: Removed duplicated region for block: B:90:0x017d  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0015  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean b(android.view.MotionEvent r18, int r19) {
        /*
            Method dump skipped, instruction units count: 396
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: i.C0085t0.b(android.view.MotionEvent, int):boolean");
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        Drawable selector;
        Rect rect = this.f1435a;
        if (!rect.isEmpty() && (selector = getSelector()) != null) {
            selector.setBounds(rect);
            selector.draw(canvas);
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.widget.AbsListView, android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        if (this.f1444l != null) {
            return;
        }
        super.drawableStateChanged();
        C0081r0 c0081r0 = this.f1439g;
        if (c0081r0 != null) {
            c0081r0.b = true;
        }
        Drawable selector = getSelector();
        if (selector != null && this.f1442j && isPressed()) {
            selector.setState(getDrawableState());
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean hasFocus() {
        return this.f1441i || super.hasFocus();
    }

    @Override // android.view.View
    public final boolean hasWindowFocus() {
        return this.f1441i || super.hasWindowFocus();
    }

    @Override // android.view.View
    public final boolean isFocused() {
        return this.f1441i || super.isFocused();
    }

    @Override // android.view.View
    public final boolean isInTouchMode() {
        return (this.f1441i && this.f1440h) || super.isInTouchMode();
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        this.f1444l = null;
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int i2 = Build.VERSION.SDK_INT;
        if (i2 < 26) {
            return super.onHoverEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10 && this.f1444l == null) {
            D.b bVar = new D.b(6, this);
            this.f1444l = bVar;
            post(bVar);
        }
        boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked != 9 && actionMasked != 7) {
            setSelection(-1);
            return zOnHoverEvent;
        }
        int iPointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        if (iPointToPosition != -1 && iPointToPosition != getSelectedItemPosition()) {
            View childAt = getChildAt(iPointToPosition - getFirstVisiblePosition());
            if (childAt.isEnabled()) {
                requestFocus();
                if (i2 < 30 || !AbstractC0078p0.f1420d) {
                    setSelectionFromTop(iPointToPosition, childAt.getTop() - getTop());
                } else {
                    try {
                        AbstractC0078p0.f1418a.invoke(this, Integer.valueOf(iPointToPosition), childAt, Boolean.FALSE, -1, -1);
                        AbstractC0078p0.b.invoke(this, Integer.valueOf(iPointToPosition));
                        AbstractC0078p0.f1419c.invoke(this, Integer.valueOf(iPointToPosition));
                    } catch (IllegalAccessException e2) {
                        e2.printStackTrace();
                    } catch (InvocationTargetException e3) {
                        e3.printStackTrace();
                    }
                }
            }
            Drawable selector = getSelector();
            if (selector != null && this.f1442j && isPressed()) {
                selector.setState(getDrawableState());
            }
        }
        return zOnHoverEvent;
    }

    @Override // android.widget.AbsListView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        D.b bVar = this.f1444l;
        if (bVar != null) {
            C0085t0 c0085t0 = (C0085t0) bVar.b;
            c0085t0.f1444l = null;
            c0085t0.removeCallbacks(bVar);
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setListSelectionHidden(boolean z2) {
        this.f1440h = z2;
    }

    @Override // android.widget.AbsListView
    public void setSelector(Drawable drawable) {
        C0081r0 c0081r0 = null;
        if (drawable != null) {
            C0081r0 c0081r02 = new C0081r0();
            Drawable drawable2 = c0081r02.f1427a;
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            c0081r02.f1427a = drawable;
            drawable.setCallback(c0081r02);
            c0081r02.b = true;
            c0081r0 = c0081r02;
        }
        this.f1439g = c0081r0;
        super.setSelector(c0081r0);
        Rect rect = new Rect();
        if (drawable != null) {
            drawable.getPadding(rect);
        }
        this.b = rect.left;
        this.f1436c = rect.top;
        this.f1437d = rect.right;
        this.f1438e = rect.bottom;
    }
}
