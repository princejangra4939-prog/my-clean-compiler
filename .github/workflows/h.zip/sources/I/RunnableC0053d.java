package i;

import androidx.appcompat.widget.ActionBarOverlayLayout;

/* JADX INFO: renamed from: i.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class RunnableC0053d implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1332a;
    public final /* synthetic */ ActionBarOverlayLayout b;

    public /* synthetic */ RunnableC0053d(ActionBarOverlayLayout actionBarOverlayLayout, int i2) {
        this.f1332a = i2;
        this.b = actionBarOverlayLayout;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f1332a) {
            case 0:
                ActionBarOverlayLayout actionBarOverlayLayout = this.b;
                actionBarOverlayLayout.h();
                actionBarOverlayLayout.f441w = actionBarOverlayLayout.f423d.animate().translationY(0.0f).setListener(actionBarOverlayLayout.f442x);
                break;
            default:
                ActionBarOverlayLayout actionBarOverlayLayout2 = this.b;
                actionBarOverlayLayout2.h();
                actionBarOverlayLayout2.f441w = actionBarOverlayLayout2.f423d.animate().translationY(-actionBarOverlayLayout2.f423d.getHeight()).setListener(actionBarOverlayLayout2.f442x);
                break;
        }
    }
}
