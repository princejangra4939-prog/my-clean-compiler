package i;

import l.C0106f;

/* JADX INFO: loaded from: classes.dex */
public final class M0 extends C0106f {
}
