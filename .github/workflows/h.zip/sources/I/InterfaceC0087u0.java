package i;

/* JADX INFO: renamed from: i.u0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0087u0 {
}
