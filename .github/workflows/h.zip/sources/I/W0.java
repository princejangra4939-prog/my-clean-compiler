package i;

import androidx.appcompat.widget.Toolbar;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class W0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1308a;
    public final /* synthetic */ Toolbar b;

    public /* synthetic */ W0(Toolbar toolbar, int i2) {
        this.f1308a = i2;
        this.b = toolbar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f1308a) {
            case 0:
                Z0 z0 = this.b.f481M;
                h.p pVar = z0 == null ? null : z0.b;
                if (pVar != null) {
                    pVar.collapseActionView();
                }
                break;
            default:
                this.b.m();
                break;
        }
    }
}
