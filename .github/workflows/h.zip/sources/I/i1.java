package i;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;
import com.warppaiwarden.tictactoe.R;

/* JADX INFO: loaded from: classes.dex */
public final class i1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f1377a;
    public final View b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final TextView f1378c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final WindowManager.LayoutParams f1379d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Rect f1380e;
    public final int[] f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int[] f1381g;

    public i1(Context context) {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        this.f1379d = layoutParams;
        this.f1380e = new Rect();
        this.f = new int[2];
        this.f1381g = new int[2];
        this.f1377a = context;
        View viewInflate = LayoutInflater.from(context).inflate(R.layout.abc_tooltip, (ViewGroup) null);
        this.b = viewInflate;
        this.f1378c = (TextView) viewInflate.findViewById(R.id.message);
        layoutParams.setTitle(i1.class.getSimpleName());
        layoutParams.packageName = context.getPackageName();
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = R.style.Animation_AppCompat_Tooltip;
        layoutParams.flags = 24;
    }
}
