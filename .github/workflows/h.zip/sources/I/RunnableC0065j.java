package i;

import android.view.View;

/* JADX INFO: renamed from: i.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class RunnableC0065j implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0061h f1382a;
    public final /* synthetic */ C0069l b;

    public RunnableC0065j(C0069l c0069l, C0061h c0061h) {
        this.b = c0069l;
        this.f1382a = c0061h;
    }

    @Override // java.lang.Runnable
    public final void run() {
        h.l lVar;
        C0069l c0069l = this.b;
        h.n nVar = c0069l.f1388c;
        if (nVar != null && (lVar = nVar.f1144e) != null) {
            lVar.g(nVar);
        }
        View view = (View) c0069l.f1392h;
        if (view != null && view.getWindowToken() != null) {
            C0061h c0061h = this.f1382a;
            if (c0061h.b()) {
                c0069l.f1403s = c0061h;
            } else if (c0061h.f1204e != null) {
                c0061h.d(0, 0, false, false);
                c0069l.f1403s = c0061h;
            }
        }
        c0069l.f1405u = null;
    }
}
