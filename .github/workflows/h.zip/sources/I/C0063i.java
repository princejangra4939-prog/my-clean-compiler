package i;

import h.AbstractC0042c;

/* JADX INFO: renamed from: i.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0063i extends AbstractC0042c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0069l f1365a;

    public C0063i(C0069l c0069l) {
        this.f1365a = c0069l;
    }
}
