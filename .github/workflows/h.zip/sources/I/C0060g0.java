package i;

import android.text.StaticLayout;
import android.widget.TextView;

/* JADX INFO: renamed from: i.g0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0060g0 extends C0058f0 {
    @Override // i.C0058f0, i.AbstractC0062h0
    public void a(StaticLayout.Builder builder, TextView textView) {
        builder.setTextDirection(textView.getTextDirectionHeuristic());
    }

    @Override // i.AbstractC0062h0
    public boolean b(TextView textView) {
        return textView.isHorizontallyScrollable();
    }
}
