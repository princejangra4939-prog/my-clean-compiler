package i;

import android.view.View;

/* JADX INFO: renamed from: i.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0059g extends View {
    @Override // android.view.View
    public final int getWindowSystemUiVisibility() {
        return 0;
    }
}
