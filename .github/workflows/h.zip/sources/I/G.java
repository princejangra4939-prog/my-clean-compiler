package i;

import android.app.Activity;
import android.content.ClipData;
import android.os.Build;
import android.text.Selection;
import android.text.Spannable;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;
import y.C0161e;
import y.InterfaceC0160d;

/* JADX INFO: loaded from: classes.dex */
public abstract class G {
    public static boolean a(DragEvent dragEvent, TextView textView, Activity activity) {
        InterfaceC0160d jVar;
        activity.requestDragAndDropPermissions(dragEvent);
        int offsetForPosition = textView.getOffsetForPosition(dragEvent.getX(), dragEvent.getY());
        textView.beginBatchEdit();
        try {
            Selection.setSelection((Spannable) textView.getText(), offsetForPosition);
            ClipData clipData = dragEvent.getClipData();
            if (Build.VERSION.SDK_INT >= 31) {
                jVar = new C.j(clipData, 3);
            } else {
                C0161e c0161e = new C0161e();
                c0161e.b = clipData;
                c0161e.f1681c = 3;
                jVar = c0161e;
            }
            y.K.f(textView, jVar.k());
            textView.endBatchEdit();
            return true;
        } catch (Throwable th) {
            textView.endBatchEdit();
            throw th;
        }
    }

    public static boolean b(DragEvent dragEvent, View view, Activity activity) {
        InterfaceC0160d jVar;
        activity.requestDragAndDropPermissions(dragEvent);
        ClipData clipData = dragEvent.getClipData();
        if (Build.VERSION.SDK_INT >= 31) {
            jVar = new C.j(clipData, 3);
        } else {
            C0161e c0161e = new C0161e();
            c0161e.b = clipData;
            c0161e.f1681c = 3;
            jVar = c0161e;
        }
        y.K.f(view, jVar.k());
        return true;
    }
}
