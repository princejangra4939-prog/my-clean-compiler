package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import d.AbstractC0010a;
import java.util.WeakHashMap;
import y.AbstractC0150A;

/* JADX INFO: renamed from: i.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0079q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final View f1421a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public U0 f1423d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public U0 f1424e;
    public U0 f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1422c = -1;
    public final C0088v b = C0088v.a();

    public C0079q(View view) {
        this.f1421a = view;
    }

    public final void a() {
        View view = this.f1421a;
        Drawable background = view.getBackground();
        if (background != null) {
            if (this.f1423d != null) {
                if (this.f == null) {
                    this.f = new U0();
                }
                U0 u0 = this.f;
                u0.f1303a = null;
                u0.f1305d = false;
                u0.b = null;
                u0.f1304c = false;
                WeakHashMap weakHashMap = y.K.f1647a;
                ColorStateList colorStateListG = AbstractC0150A.g(view);
                if (colorStateListG != null) {
                    u0.f1305d = true;
                    u0.f1303a = colorStateListG;
                }
                PorterDuff.Mode modeH = AbstractC0150A.h(view);
                if (modeH != null) {
                    u0.f1304c = true;
                    u0.b = modeH;
                }
                if (u0.f1305d || u0.f1304c) {
                    C0088v.d(background, u0, view.getDrawableState());
                    return;
                }
            }
            U0 u02 = this.f1424e;
            if (u02 != null) {
                C0088v.d(background, u02, view.getDrawableState());
                return;
            }
            U0 u03 = this.f1423d;
            if (u03 != null) {
                C0088v.d(background, u03, view.getDrawableState());
            }
        }
    }

    public final ColorStateList b() {
        U0 u0 = this.f1424e;
        if (u0 != null) {
            return u0.f1303a;
        }
        return null;
    }

    public final PorterDuff.Mode c() {
        U0 u0 = this.f1424e;
        if (u0 != null) {
            return u0.b;
        }
        return null;
    }

    public final void d(AttributeSet attributeSet, int i2) {
        ColorStateList colorStateListF;
        View view = this.f1421a;
        Context context = view.getContext();
        int[] iArr = AbstractC0010a.f822y;
        C.h hVarM = C.h.m(context, attributeSet, iArr, i2);
        TypedArray typedArray = (TypedArray) hVarM.b;
        View view2 = this.f1421a;
        y.K.g(view2, view2.getContext(), iArr, attributeSet, (TypedArray) hVarM.b, i2);
        try {
            if (typedArray.hasValue(0)) {
                this.f1422c = typedArray.getResourceId(0, -1);
                C0088v c0088v = this.b;
                Context context2 = view.getContext();
                int i3 = this.f1422c;
                synchronized (c0088v) {
                    colorStateListF = c0088v.f1450a.f(context2, i3);
                }
                if (colorStateListF != null) {
                    g(colorStateListF);
                }
            }
            if (typedArray.hasValue(1)) {
                AbstractC0150A.q(view, hVarM.h(1));
            }
            if (typedArray.hasValue(2)) {
                AbstractC0150A.r(view, AbstractC0074n0.b(typedArray.getInt(2, -1), null));
            }
            hVarM.r();
        } catch (Throwable th) {
            hVarM.r();
            throw th;
        }
    }

    public final void e() {
        this.f1422c = -1;
        g(null);
        a();
    }

    public final void f(int i2) {
        ColorStateList colorStateListF;
        this.f1422c = i2;
        C0088v c0088v = this.b;
        if (c0088v != null) {
            Context context = this.f1421a.getContext();
            synchronized (c0088v) {
                colorStateListF = c0088v.f1450a.f(context, i2);
            }
        } else {
            colorStateListF = null;
        }
        g(colorStateListF);
        a();
    }

    public final void g(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f1423d == null) {
                this.f1423d = new U0();
            }
            U0 u0 = this.f1423d;
            u0.f1303a = colorStateList;
            u0.f1305d = true;
        } else {
            this.f1423d = null;
        }
        a();
    }

    public final void h(ColorStateList colorStateList) {
        if (this.f1424e == null) {
            this.f1424e = new U0();
        }
        U0 u0 = this.f1424e;
        u0.f1303a = colorStateList;
        u0.f1305d = true;
        a();
    }

    public final void i(PorterDuff.Mode mode) {
        if (this.f1424e == null) {
            this.f1424e = new U0();
        }
        U0 u0 = this.f1424e;
        u0.b = mode;
        u0.f1304c = true;
        a();
    }
}
