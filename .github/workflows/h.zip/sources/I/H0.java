package i;

/* JADX INFO: loaded from: classes.dex */
public interface H0 {
    void r(h.n nVar, h.p pVar);

    void t(h.n nVar, h.p pVar);
}
