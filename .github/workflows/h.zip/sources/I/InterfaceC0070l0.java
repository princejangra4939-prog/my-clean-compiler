package i;

import android.view.Window;

/* JADX INFO: renamed from: i.l0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0070l0 {
    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
