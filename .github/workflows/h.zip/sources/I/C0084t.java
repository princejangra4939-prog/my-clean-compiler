package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import com.warppaiwarden.tictactoe.R;
import d.AbstractC0010a;

/* JADX INFO: renamed from: i.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0084t extends CheckedTextView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final M.e f1432a;
    public final C0079q b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Z f1433c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C0094y f1434d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0084t(Context context, AttributeSet attributeSet) {
        int resourceId;
        int resourceId2;
        super(context, attributeSet, R.attr.checkedTextViewStyle);
        T0.a(context);
        S0.a(this, getContext());
        Z z2 = new Z(this);
        this.f1433c = z2;
        z2.f(attributeSet, R.attr.checkedTextViewStyle);
        z2.b();
        C0079q c0079q = new C0079q(this);
        this.b = c0079q;
        c0079q.d(attributeSet, R.attr.checkedTextViewStyle);
        this.f1432a = new M.e(this);
        Context context2 = getContext();
        int[] iArr = AbstractC0010a.f809l;
        C.h hVarM = C.h.m(context2, attributeSet, iArr, R.attr.checkedTextViewStyle);
        TypedArray typedArray = (TypedArray) hVarM.b;
        y.K.g(this, getContext(), iArr, attributeSet, (TypedArray) hVarM.b, R.attr.checkedTextViewStyle);
        try {
            if (typedArray.hasValue(1) && (resourceId2 = typedArray.getResourceId(1, 0)) != 0) {
                try {
                    setCheckMarkDrawable(D.g.w(getContext(), resourceId2));
                } catch (Resources.NotFoundException unused) {
                    if (typedArray.hasValue(0)) {
                        setCheckMarkDrawable(D.g.w(getContext(), resourceId));
                    }
                }
            } else if (typedArray.hasValue(0) && (resourceId = typedArray.getResourceId(0, 0)) != 0) {
                setCheckMarkDrawable(D.g.w(getContext(), resourceId));
            }
            if (typedArray.hasValue(2)) {
                setCheckMarkTintList(hVarM.h(2));
            }
            if (typedArray.hasValue(3)) {
                setCheckMarkTintMode(AbstractC0074n0.b(typedArray.getInt(3, -1), null));
            }
            hVarM.r();
            getEmojiTextViewHelper().a(attributeSet, R.attr.checkedTextViewStyle);
        } catch (Throwable th) {
            hVarM.r();
            throw th;
        }
    }

    private C0094y getEmojiTextViewHelper() {
        if (this.f1434d == null) {
            this.f1434d = new C0094y(this);
        }
        return this.f1434d;
    }

    @Override // android.widget.CheckedTextView, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Z z2 = this.f1433c;
        if (z2 != null) {
            z2.b();
        }
        C0079q c0079q = this.b;
        if (c0079q != null) {
            c0079q.a();
        }
        M.e eVar = this.f1432a;
        if (eVar != null) {
            eVar.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return D.g.i0(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0079q c0079q = this.b;
        if (c0079q != null) {
            return c0079q.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0079q c0079q = this.b;
        if (c0079q != null) {
            return c0079q.c();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        M.e eVar = this.f1432a;
        if (eVar != null) {
            return (ColorStateList) eVar.f118e;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        M.e eVar = this.f1432a;
        if (eVar != null) {
            return (PorterDuff.Mode) eVar.f;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f1433c.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f1433c.e();
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        D.g.K(editorInfo, inputConnectionOnCreateInputConnection, this);
        return inputConnectionOnCreateInputConnection;
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0079q c0079q = this.b;
        if (c0079q != null) {
            c0079q.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0079q c0079q = this.b;
        if (c0079q != null) {
            c0079q.f(i2);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        M.e eVar = this.f1432a;
        if (eVar != null) {
            if (eVar.f116c) {
                eVar.f116c = false;
            } else {
                eVar.f116c = true;
                eVar.b();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.f1433c;
        if (z2 != null) {
            z2.b();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        Z z2 = this.f1433c;
        if (z2 != null) {
            z2.b();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(D.g.j0(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0079q c0079q = this.b;
        if (c0079q != null) {
            c0079q.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0079q c0079q = this.b;
        if (c0079q != null) {
            c0079q.i(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        M.e eVar = this.f1432a;
        if (eVar != null) {
            eVar.f118e = colorStateList;
            eVar.f115a = true;
            eVar.b();
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        M.e eVar = this.f1432a;
        if (eVar != null) {
            eVar.f = mode;
            eVar.b = true;
            eVar.b();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Z z2 = this.f1433c;
        z2.l(colorStateList);
        z2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Z z2 = this.f1433c;
        z2.m(mode);
        z2.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        Z z2 = this.f1433c;
        if (z2 != null) {
            z2.g(context, i2);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(int i2) {
        setCheckMarkDrawable(D.g.w(getContext(), i2));
    }
}
