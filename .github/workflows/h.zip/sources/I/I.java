package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import com.warppaiwarden.tictactoe.R;
import d.AbstractC0010a;
import s.AbstractC0128a;
import s.AbstractC0129b;

/* JADX INFO: loaded from: classes.dex */
public final class I extends E {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final H f1253e;
    public Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f1254g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f1255h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f1256i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1257j;

    public I(H h2) {
        super(h2);
        this.f1254g = null;
        this.f1255h = null;
        this.f1256i = false;
        this.f1257j = false;
        this.f1253e = h2;
    }

    @Override // i.E
    public final void b(AttributeSet attributeSet, int i2) {
        super.b(attributeSet, R.attr.seekBarStyle);
        H h2 = this.f1253e;
        Context context = h2.getContext();
        int[] iArr = AbstractC0010a.f804g;
        C.h hVarM = C.h.m(context, attributeSet, iArr, R.attr.seekBarStyle);
        y.K.g(h2, h2.getContext(), iArr, attributeSet, (TypedArray) hVarM.b, R.attr.seekBarStyle);
        Drawable drawableJ = hVarM.j(0);
        if (drawableJ != null) {
            h2.setThumb(drawableJ);
        }
        Drawable drawableI = hVarM.i(1);
        Drawable drawable = this.f;
        if (drawable != null) {
            drawable.setCallback(null);
        }
        this.f = drawableI;
        if (drawableI != null) {
            drawableI.setCallback(h2);
            AbstractC0129b.b(drawableI, h2.getLayoutDirection());
            if (drawableI.isStateful()) {
                drawableI.setState(h2.getDrawableState());
            }
            f();
        }
        h2.invalidate();
        TypedArray typedArray = (TypedArray) hVarM.b;
        if (typedArray.hasValue(3)) {
            this.f1255h = AbstractC0074n0.b(typedArray.getInt(3, -1), this.f1255h);
            this.f1257j = true;
        }
        if (typedArray.hasValue(2)) {
            this.f1254g = hVarM.h(2);
            this.f1256i = true;
        }
        hVarM.r();
        f();
    }

    public final void f() {
        Drawable drawable = this.f;
        if (drawable != null) {
            if (this.f1256i || this.f1257j) {
                Drawable drawableMutate = drawable.mutate();
                this.f = drawableMutate;
                if (this.f1256i) {
                    AbstractC0128a.h(drawableMutate, this.f1254g);
                }
                if (this.f1257j) {
                    AbstractC0128a.i(this.f, this.f1255h);
                }
                if (this.f.isStateful()) {
                    this.f.setState(this.f1253e.getDrawableState());
                }
            }
        }
    }

    public final void g(Canvas canvas) {
        if (this.f != null) {
            int max = this.f1253e.getMax();
            if (max > 1) {
                int intrinsicWidth = this.f.getIntrinsicWidth();
                int intrinsicHeight = this.f.getIntrinsicHeight();
                int i2 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                int i3 = intrinsicHeight >= 0 ? intrinsicHeight / 2 : 1;
                this.f.setBounds(-i2, -i3, i2, i3);
                float width = ((r0.getWidth() - r0.getPaddingLeft()) - r0.getPaddingRight()) / max;
                int iSave = canvas.save();
                canvas.translate(r0.getPaddingLeft(), r0.getHeight() / 2);
                for (int i4 = 0; i4 <= max; i4++) {
                    this.f.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(iSave);
            }
        }
    }
}
