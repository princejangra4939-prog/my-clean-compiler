package i;

/* JADX INFO: loaded from: classes.dex */
public final class J extends AbstractViewOnTouchListenerC0091w0 {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ O f1258j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ S f1259k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public J(S s2, S s3, O o2) {
        super(s3);
        this.f1259k = s2;
        this.f1258j = o2;
    }

    @Override // i.AbstractViewOnTouchListenerC0091w0
    public final h.D b() {
        return this.f1258j;
    }

    @Override // i.AbstractViewOnTouchListenerC0091w0
    public final boolean c() {
        S s2 = this.f1259k;
        if (s2.getInternalPopup().a()) {
            return true;
        }
        s2.f.e(s2.getTextDirection(), s2.getTextAlignment());
        return true;
    }
}
