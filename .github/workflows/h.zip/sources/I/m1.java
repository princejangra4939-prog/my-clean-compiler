package i;

import android.os.Build;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes.dex */
public abstract class m1 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static boolean f1408a;
    public static Method b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final boolean f1409c;

    static {
        f1409c = Build.VERSION.SDK_INT >= 27;
    }
}
