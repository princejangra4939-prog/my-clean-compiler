package i;

/* JADX INFO: renamed from: i.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0071m {
    boolean a();

    boolean b();
}
