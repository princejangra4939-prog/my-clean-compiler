package i;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public abstract class f1 {
    public static void a(View view, CharSequence charSequence) {
        view.setTooltipText(charSequence);
    }
}
