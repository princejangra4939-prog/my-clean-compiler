package i;

/* JADX INFO: renamed from: i.m0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0072m0 {
}
