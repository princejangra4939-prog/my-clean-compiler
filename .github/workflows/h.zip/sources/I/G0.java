package i;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import d.AbstractC0010a;
import java.lang.reflect.Method;

/* JADX INFO: loaded from: classes.dex */
public abstract class G0 implements h.D {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public static final Method f1227A;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static final Method f1228z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f1229a;
    public ListAdapter b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C0085t0 f1230c;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1233g;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f1235i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1236j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f1237k;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public D0 f1240n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public View f1241o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public AdapterView.OnItemClickListener f1242p;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Handler f1247u;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public Rect f1249w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f1250x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final D f1251y;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1231d = -2;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1232e = -2;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f1234h = 1002;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f1238l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f1239m = Integer.MAX_VALUE;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final C0 f1243q = new C0(this, 1);

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final F0 f1244r = new F0(this);

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final E0 f1245s = new E0(this);

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final C0 f1246t = new C0(this, 0);

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Rect f1248v = new Rect();

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                f1228z = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                f1227A = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
    }

    public G0(Context context, AttributeSet attributeSet, int i2) {
        int resourceId;
        this.f1229a = context;
        this.f1247u = new Handler(context.getMainLooper());
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0010a.f812o, i2, 0);
        this.f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f1233g = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f1235i = true;
        }
        typedArrayObtainStyledAttributes.recycle();
        D d2 = new D(context, attributeSet, i2, 0);
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, AbstractC0010a.f816s, i2, 0);
        if (typedArrayObtainStyledAttributes2.hasValue(2)) {
            D.o.c(d2, typedArrayObtainStyledAttributes2.getBoolean(2, false));
        }
        d2.setBackgroundDrawable((!typedArrayObtainStyledAttributes2.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes2.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes2.getDrawable(0) : D.g.w(context, resourceId));
        typedArrayObtainStyledAttributes2.recycle();
        this.f1251y = d2;
        d2.setInputMethodMode(1);
    }

    @Override // h.D
    public final boolean a() {
        return this.f1251y.isShowing();
    }

    public final void c(int i2) {
        this.f = i2;
    }

    public final int d() {
        return this.f;
    }

    @Override // h.D
    public final void dismiss() {
        D d2 = this.f1251y;
        d2.dismiss();
        d2.setContentView(null);
        this.f1230c = null;
        this.f1247u.removeCallbacks(this.f1243q);
    }

    @Override // h.D
    public final C0085t0 f() {
        return this.f1230c;
    }

    @Override // h.D
    public final void h() {
        int i2;
        int paddingBottom;
        C0085t0 c0085t0;
        C0085t0 c0085t02 = this.f1230c;
        D d2 = this.f1251y;
        Context context = this.f1229a;
        if (c0085t02 == null) {
            C0085t0 c0085t0O = o(context, !this.f1250x);
            this.f1230c = c0085t0O;
            c0085t0O.setAdapter(this.b);
            this.f1230c.setOnItemClickListener(this.f1242p);
            this.f1230c.setFocusable(true);
            this.f1230c.setFocusableInTouchMode(true);
            this.f1230c.setOnItemSelectedListener(new C0097z0(this));
            this.f1230c.setOnScrollListener(this.f1245s);
            d2.setContentView(this.f1230c);
        }
        Drawable background = d2.getBackground();
        Rect rect = this.f1248v;
        if (background != null) {
            background.getPadding(rect);
            int i3 = rect.top;
            i2 = rect.bottom + i3;
            if (!this.f1235i) {
                this.f1233g = -i3;
            }
        } else {
            rect.setEmpty();
            i2 = 0;
        }
        int iA = A0.a(d2, this.f1241o, this.f1233g, d2.getInputMethodMode() == 2);
        int i4 = this.f1231d;
        if (i4 == -1) {
            paddingBottom = iA + i2;
        } else {
            int i5 = this.f1232e;
            int iA2 = this.f1230c.a(i5 != -2 ? i5 != -1 ? View.MeasureSpec.makeMeasureSpec(i5, 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE), iA);
            paddingBottom = iA2 + (iA2 > 0 ? this.f1230c.getPaddingBottom() + this.f1230c.getPaddingTop() + i2 : 0);
        }
        boolean z2 = this.f1251y.getInputMethodMode() == 2;
        D.o.d(d2, this.f1234h);
        if (d2.isShowing()) {
            if (this.f1241o.isAttachedToWindow()) {
                int width = this.f1232e;
                if (width == -1) {
                    width = -1;
                } else if (width == -2) {
                    width = this.f1241o.getWidth();
                }
                if (i4 == -1) {
                    i4 = z2 ? paddingBottom : -1;
                    if (z2) {
                        d2.setWidth(this.f1232e == -1 ? -1 : 0);
                        d2.setHeight(0);
                    } else {
                        d2.setWidth(this.f1232e == -1 ? -1 : 0);
                        d2.setHeight(-1);
                    }
                } else if (i4 == -2) {
                    i4 = paddingBottom;
                }
                d2.setOutsideTouchable(true);
                View view = this.f1241o;
                int i6 = this.f;
                int i7 = this.f1233g;
                if (width < 0) {
                    width = -1;
                }
                d2.update(view, i6, i7, width, i4 < 0 ? -1 : i4);
                return;
            }
            return;
        }
        int width2 = this.f1232e;
        if (width2 == -1) {
            width2 = -1;
        } else if (width2 == -2) {
            width2 = this.f1241o.getWidth();
        }
        if (i4 == -1) {
            i4 = -1;
        } else if (i4 == -2) {
            i4 = paddingBottom;
        }
        d2.setWidth(width2);
        d2.setHeight(i4);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = f1228z;
            if (method != null) {
                try {
                    method.invoke(d2, Boolean.TRUE);
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            B0.b(d2, true);
        }
        d2.setOutsideTouchable(true);
        d2.setTouchInterceptor(this.f1244r);
        if (this.f1237k) {
            D.o.c(d2, this.f1236j);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = f1227A;
            if (method2 != null) {
                try {
                    method2.invoke(d2, this.f1249w);
                } catch (Exception e2) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                }
            }
        } else {
            B0.a(d2, this.f1249w);
        }
        d2.showAsDropDown(this.f1241o, this.f, this.f1233g, this.f1238l);
        this.f1230c.setSelection(-1);
        if ((!this.f1250x || this.f1230c.isInTouchMode()) && (c0085t0 = this.f1230c) != null) {
            c0085t0.setListSelectionHidden(true);
            c0085t0.requestLayout();
        }
        if (this.f1250x) {
            return;
        }
        this.f1247u.post(this.f1246t);
    }

    public final int i() {
        if (this.f1235i) {
            return this.f1233g;
        }
        return 0;
    }

    public final void j(Drawable drawable) {
        this.f1251y.setBackgroundDrawable(drawable);
    }

    public final void k(int i2) {
        this.f1233g = i2;
        this.f1235i = true;
    }

    public final Drawable l() {
        return this.f1251y.getBackground();
    }

    public void m(ListAdapter listAdapter) {
        D0 d02 = this.f1240n;
        if (d02 == null) {
            this.f1240n = new D0(this);
        } else {
            ListAdapter listAdapter2 = this.b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(d02);
            }
        }
        this.b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f1240n);
        }
        C0085t0 c0085t0 = this.f1230c;
        if (c0085t0 != null) {
            c0085t0.setAdapter(this.b);
        }
    }

    public C0085t0 o(Context context, boolean z2) {
        return new C0085t0(context, z2);
    }

    public final void p(int i2) {
        Drawable background = this.f1251y.getBackground();
        if (background == null) {
            this.f1232e = i2;
            return;
        }
        Rect rect = this.f1248v;
        background.getPadding(rect);
        this.f1232e = rect.left + rect.right + i2;
    }
}
