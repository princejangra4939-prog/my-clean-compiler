package i;

import android.content.Context;
import android.content.ContextWrapper;

/* JADX INFO: loaded from: classes.dex */
public abstract class T0 extends ContextWrapper {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Object f1299a = null;

    public static void a(Context context) {
        if (context.getResources() instanceof V0) {
            return;
        }
        context.getResources();
        int i2 = j1.f1385a;
    }
}
