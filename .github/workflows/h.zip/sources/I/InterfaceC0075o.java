package i;

/* JADX INFO: renamed from: i.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0075o {
}
