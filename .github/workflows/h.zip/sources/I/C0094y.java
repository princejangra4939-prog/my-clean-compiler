package i;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.TextView;
import d.AbstractC0010a;

/* JADX INFO: renamed from: i.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0094y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextView f1464a;
    public final C.j b;

    public C0094y(TextView textView) {
        this.f1464a = textView;
        this.b = new C.j(textView);
    }

    public final void a(AttributeSet attributeSet, int i2) {
        TypedArray typedArrayObtainStyledAttributes = this.f1464a.getContext().obtainStyledAttributes(attributeSet, AbstractC0010a.f806i, i2, 0);
        try {
            boolean z2 = typedArrayObtainStyledAttributes.hasValue(14) ? typedArrayObtainStyledAttributes.getBoolean(14, true) : true;
            typedArrayObtainStyledAttributes.recycle();
            c(z2);
        } catch (Throwable th) {
            typedArrayObtainStyledAttributes.recycle();
            throw th;
        }
    }

    public final void b(boolean z2) {
        ((D.g) this.b.b).Y(z2);
    }

    public final void c(boolean z2) {
        ((D.g) this.b.b).a0(z2);
    }
}
