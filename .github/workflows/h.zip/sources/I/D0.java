package i;

import android.database.DataSetObserver;

/* JADX INFO: loaded from: classes.dex */
public final class D0 extends DataSetObserver {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ G0 f1218a;

    public D0(G0 g02) {
        this.f1218a = g02;
    }

    @Override // android.database.DataSetObserver
    public final void onChanged() {
        G0 g02 = this.f1218a;
        if (g02.f1251y.isShowing()) {
            g02.h();
        }
    }

    @Override // android.database.DataSetObserver
    public final void onInvalidated() {
        this.f1218a.dismiss();
    }
}
