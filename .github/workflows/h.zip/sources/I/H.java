package i;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import com.warppaiwarden.tictactoe.R;

/* JADX INFO: loaded from: classes.dex */
public final class H extends SeekBar {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final I f1252a;

    public H(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.seekBarStyle);
        S0.a(this, getContext());
        I i2 = new I(this);
        this.f1252a = i2;
        i2.b(attributeSet, R.attr.seekBarStyle);
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        I i2 = this.f1252a;
        Drawable drawable = i2.f;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        H h2 = i2.f1253e;
        if (drawable.setState(h2.getDrawableState())) {
            h2.invalidateDrawable(drawable);
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f1252a.f;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    @Override // android.widget.AbsSeekBar, android.widget.ProgressBar, android.view.View
    public final synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f1252a.g(canvas);
    }
}
