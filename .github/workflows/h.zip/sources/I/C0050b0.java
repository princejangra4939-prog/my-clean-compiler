package i;

/* JADX INFO: renamed from: i.b0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0050b0 extends C.j {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0054d0 f1327c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0050b0(C0054d0 c0054d0) {
        super(19, c0054d0);
        this.f1327c = c0054d0;
    }

    @Override // C.j, i.InterfaceC0048a0
    public final void d(int i2) {
        super/*android.widget.TextView*/.setFirstBaselineToTopHeight(i2);
    }

    @Override // C.j, i.InterfaceC0048a0
    public final void v(int i2) {
        super/*android.widget.TextView*/.setLastBaselineToBottomHeight(i2);
    }
}
