package i;

import android.widget.LinearLayout;

/* JADX INFO: renamed from: i.x0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0093x0 extends LinearLayout.LayoutParams {
}
