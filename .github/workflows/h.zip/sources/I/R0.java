package i;

import g.InterfaceC0029b;

/* JADX INFO: loaded from: classes.dex */
public abstract class R0 extends AbstractC0095y0 implements InterfaceC0029b {
}
