package i;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import com.warppaiwarden.tictactoe.R;
import h.InterfaceC0039A;
import java.util.ArrayList;

/* JADX INFO: renamed from: i.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0069l implements h.z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f1387a;
    public Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public h.n f1388c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final LayoutInflater f1389d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public h.y f1390e;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public h.B f1392h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public C0067k f1393i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public Drawable f1394j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public boolean f1395k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f1396l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f1397m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f1398n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f1399o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f1400p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f1401q;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public C0061h f1403s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public C0061h f1404t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public RunnableC0065j f1405u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public C0063i f1406v;
    public final int f = R.layout.abc_action_menu_layout;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f1391g = R.layout.abc_action_menu_item_layout;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final SparseBooleanArray f1402r = new SparseBooleanArray();

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final C.j f1407w = new C.j(17, this);

    public C0069l(Context context) {
        this.f1387a = context;
        this.f1389d = LayoutInflater.from(context);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final View a(h.p pVar, View view, ViewGroup viewGroup) {
        View actionView = pVar.getActionView();
        if (actionView == null || pVar.e()) {
            InterfaceC0039A interfaceC0039A = view instanceof InterfaceC0039A ? (InterfaceC0039A) view : (InterfaceC0039A) this.f1389d.inflate(this.f1391g, viewGroup, false);
            interfaceC0039A.c(pVar);
            ActionMenuItemView actionMenuItemView = (ActionMenuItemView) interfaceC0039A;
            actionMenuItemView.setItemInvoker((ActionMenuView) this.f1392h);
            if (this.f1406v == null) {
                this.f1406v = new C0063i(this);
            }
            actionMenuItemView.setPopupCallback(this.f1406v);
            actionView = (View) interfaceC0039A;
        }
        actionView.setVisibility(pVar.f1167C ? 8 : 0);
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        ((ActionMenuView) viewGroup).getClass();
        if (!(layoutParams instanceof C0073n)) {
            actionView.setLayoutParams(ActionMenuView.j(layoutParams));
        }
        return actionView;
    }

    @Override // h.z
    public final void b(h.n nVar, boolean z2) {
        f();
        C0061h c0061h = this.f1404t;
        if (c0061h != null && c0061h.b()) {
            c0061h.f1207i.dismiss();
        }
        h.y yVar = this.f1390e;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // h.z
    public final void c() {
        int i2;
        ViewGroup viewGroup = (ViewGroup) this.f1392h;
        ArrayList arrayList = null;
        boolean z2 = false;
        if (viewGroup != null) {
            h.n nVar = this.f1388c;
            if (nVar != null) {
                nVar.i();
                ArrayList arrayListL = this.f1388c.l();
                int size = arrayListL.size();
                i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    h.p pVar = (h.p) arrayListL.get(i3);
                    if ((pVar.f1189x & 32) == 32) {
                        View childAt = viewGroup.getChildAt(i2);
                        h.p itemData = childAt instanceof InterfaceC0039A ? ((InterfaceC0039A) childAt).getItemData() : null;
                        View viewA = a(pVar, childAt, viewGroup);
                        if (pVar != itemData) {
                            viewA.setPressed(false);
                            viewA.jumpDrawablesToCurrentState();
                        }
                        if (viewA != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) viewA.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(viewA);
                            }
                            ((ViewGroup) this.f1392h).addView(viewA, i2);
                        }
                        i2++;
                    }
                }
            } else {
                i2 = 0;
            }
            while (i2 < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i2) == this.f1393i) {
                    i2++;
                } else {
                    viewGroup.removeViewAt(i2);
                }
            }
        }
        ((View) this.f1392h).requestLayout();
        h.n nVar2 = this.f1388c;
        if (nVar2 != null) {
            nVar2.i();
            ArrayList arrayList2 = nVar2.f1147i;
            int size2 = arrayList2.size();
            for (int i4 = 0; i4 < size2; i4++) {
                h.q qVar = ((h.p) arrayList2.get(i4)).f1165A;
            }
        }
        h.n nVar3 = this.f1388c;
        if (nVar3 != null) {
            nVar3.i();
            arrayList = nVar3.f1148j;
        }
        if (this.f1396l && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z2 = !((h.p) arrayList.get(0)).f1167C;
            } else if (size3 > 0) {
                z2 = true;
            }
        }
        if (z2) {
            if (this.f1393i == null) {
                this.f1393i = new C0067k(this, this.f1387a);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.f1393i.getParent();
            if (viewGroup3 != this.f1392h) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.f1393i);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f1392h;
                C0067k c0067k = this.f1393i;
                actionMenuView.getClass();
                C0073n c0073nI = ActionMenuView.i();
                c0073nI.f1410a = true;
                actionMenuView.addView(c0067k, c0073nI);
            }
        } else {
            C0067k c0067k2 = this.f1393i;
            if (c0067k2 != null) {
                Object parent = c0067k2.getParent();
                Object obj = this.f1392h;
                if (parent == obj) {
                    ((ViewGroup) obj).removeView(this.f1393i);
                }
            }
        }
        ((ActionMenuView) this.f1392h).setOverflowReserved(this.f1396l);
    }

    @Override // h.z
    public final boolean d(h.p pVar) {
        return false;
    }

    @Override // h.z
    public final void e(h.y yVar) {
        throw null;
    }

    public final boolean f() {
        Object obj;
        RunnableC0065j runnableC0065j = this.f1405u;
        if (runnableC0065j != null && (obj = this.f1392h) != null) {
            ((View) obj).removeCallbacks(runnableC0065j);
            this.f1405u = null;
            return true;
        }
        C0061h c0061h = this.f1403s;
        if (c0061h == null) {
            return false;
        }
        if (c0061h.b()) {
            c0061h.f1207i.dismiss();
        }
        return true;
    }

    @Override // h.z
    public final void g(Context context, h.n nVar) {
        this.b = context;
        LayoutInflater.from(context);
        this.f1388c = nVar;
        Resources resources = context.getResources();
        if (!this.f1397m) {
            this.f1396l = true;
        }
        int i2 = 2;
        this.f1398n = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i3 = configuration.screenWidthDp;
        int i4 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
            i2 = 5;
        } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
            i2 = 4;
        } else if (i3 >= 360) {
            i2 = 3;
        }
        this.f1400p = i2;
        int measuredWidth = this.f1398n;
        if (this.f1396l) {
            if (this.f1393i == null) {
                C0067k c0067k = new C0067k(this, this.f1387a);
                this.f1393i = c0067k;
                if (this.f1395k) {
                    c0067k.setImageDrawable(this.f1394j);
                    this.f1394j = null;
                    this.f1395k = false;
                }
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f1393i.measure(iMakeMeasureSpec, iMakeMeasureSpec);
            }
            measuredWidth -= this.f1393i.getMeasuredWidth();
        } else {
            this.f1393i = null;
        }
        this.f1399o = measuredWidth;
        float f = resources.getDisplayMetrics().density;
    }

    public final boolean h() {
        C0061h c0061h = this.f1403s;
        return c0061h != null && c0061h.b();
    }

    @Override // h.z
    public final boolean i() {
        int size;
        ArrayList arrayListL;
        int i2;
        boolean z2;
        C0069l c0069l = this;
        h.n nVar = c0069l.f1388c;
        if (nVar != null) {
            arrayListL = nVar.l();
            size = arrayListL.size();
        } else {
            size = 0;
            arrayListL = null;
        }
        int i3 = c0069l.f1400p;
        int i4 = c0069l.f1399o;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) c0069l.f1392h;
        int i5 = 0;
        boolean z3 = false;
        int i6 = 0;
        int i7 = 0;
        while (true) {
            i2 = 2;
            z2 = true;
            if (i5 >= size) {
                break;
            }
            h.p pVar = (h.p) arrayListL.get(i5);
            int i8 = pVar.f1190y;
            if ((i8 & 2) == 2) {
                i6++;
            } else if ((i8 & 1) == 1) {
                i7++;
            } else {
                z3 = true;
            }
            if (c0069l.f1401q && pVar.f1167C) {
                i3 = 0;
            }
            i5++;
        }
        if (c0069l.f1396l && (z3 || i7 + i6 > i3)) {
            i3--;
        }
        int i9 = i3 - i6;
        SparseBooleanArray sparseBooleanArray = c0069l.f1402r;
        sparseBooleanArray.clear();
        int i10 = 0;
        int i11 = 0;
        while (i10 < size) {
            h.p pVar2 = (h.p) arrayListL.get(i10);
            int i12 = pVar2.f1190y;
            boolean z4 = (i12 & 2) == i2 ? z2 : false;
            int i13 = pVar2.b;
            if (z4) {
                View viewA = c0069l.a(pVar2, null, viewGroup);
                viewA.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                int measuredWidth = viewA.getMeasuredWidth();
                i4 -= measuredWidth;
                if (i11 == 0) {
                    i11 = measuredWidth;
                }
                if (i13 != 0) {
                    sparseBooleanArray.put(i13, z2);
                }
                pVar2.f(z2);
            } else if ((i12 & 1) == z2) {
                boolean z5 = sparseBooleanArray.get(i13);
                boolean z6 = ((i9 > 0 || z5) && i4 > 0) ? z2 : false;
                if (z6) {
                    View viewA2 = c0069l.a(pVar2, null, viewGroup);
                    viewA2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                    int measuredWidth2 = viewA2.getMeasuredWidth();
                    i4 -= measuredWidth2;
                    if (i11 == 0) {
                        i11 = measuredWidth2;
                    }
                    z6 &= i4 + i11 > 0;
                }
                if (z6 && i13 != 0) {
                    sparseBooleanArray.put(i13, true);
                } else if (z5) {
                    sparseBooleanArray.put(i13, false);
                    for (int i14 = 0; i14 < i10; i14++) {
                        h.p pVar3 = (h.p) arrayListL.get(i14);
                        if (pVar3.b == i13) {
                            if ((pVar3.f1189x & 32) == 32) {
                                i9++;
                            }
                            pVar3.f(false);
                        }
                    }
                }
                if (z6) {
                    i9--;
                }
                pVar2.f(z6);
            } else {
                pVar2.f(false);
                i10++;
                i2 = 2;
                c0069l = this;
                z2 = true;
            }
            i10++;
            i2 = 2;
            c0069l = this;
            z2 = true;
        }
        return z2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // h.z
    public final boolean j(h.F f) {
        boolean z2;
        if (f.hasVisibleItems()) {
            h.F f2 = f;
            while (true) {
                h.n nVar = f2.f1084z;
                if (nVar == this.f1388c) {
                    break;
                }
                f2 = (h.F) nVar;
            }
            ViewGroup viewGroup = (ViewGroup) this.f1392h;
            View view = null;
            view = null;
            if (viewGroup != null) {
                int childCount = viewGroup.getChildCount();
                int i2 = 0;
                while (true) {
                    if (i2 >= childCount) {
                        break;
                    }
                    View childAt = viewGroup.getChildAt(i2);
                    if ((childAt instanceof InterfaceC0039A) && ((InterfaceC0039A) childAt).getItemData() == f2.f1083A) {
                        view = childAt;
                        break;
                    }
                    i2++;
                }
            }
            if (view != null) {
                f.f1083A.getClass();
                int size = f.f.size();
                int i3 = 0;
                while (true) {
                    if (i3 >= size) {
                        z2 = false;
                        break;
                    }
                    MenuItem item = f.getItem(i3);
                    if (item.isVisible() && item.getIcon() != null) {
                        z2 = true;
                        break;
                    }
                    i3++;
                }
                C0061h c0061h = new C0061h(this, this.b, f, view);
                this.f1404t = c0061h;
                c0061h.f1205g = z2;
                h.v vVar = c0061h.f1207i;
                if (vVar != null) {
                    vVar.o(z2);
                }
                C0061h c0061h2 = this.f1404t;
                if (!c0061h2.b()) {
                    if (c0061h2.f1204e == null) {
                        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
                    }
                    c0061h2.d(0, 0, false, false);
                }
                h.y yVar = this.f1390e;
                if (yVar != null) {
                    yVar.m(f);
                }
                return true;
            }
        }
        return false;
    }

    @Override // h.z
    public final boolean k(h.p pVar) {
        return false;
    }

    public final boolean l() {
        h.n nVar;
        if (!this.f1396l || h() || (nVar = this.f1388c) == null || this.f1392h == null || this.f1405u != null) {
            return false;
        }
        nVar.i();
        if (nVar.f1148j.isEmpty()) {
            return false;
        }
        RunnableC0065j runnableC0065j = new RunnableC0065j(this, new C0061h(this, this.b, this.f1388c, this.f1393i));
        this.f1405u = runnableC0065j;
        ((View) this.f1392h).post(runnableC0065j);
        return true;
    }
}
