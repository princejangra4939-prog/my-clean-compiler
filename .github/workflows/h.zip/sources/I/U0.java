package i;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* JADX INFO: loaded from: classes.dex */
public final class U0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ColorStateList f1303a;
    public PorterDuff.Mode b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1304c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1305d;
}
