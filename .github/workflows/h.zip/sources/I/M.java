package i;

import android.view.View;
import android.widget.AdapterView;

/* JADX INFO: loaded from: classes.dex */
public final class M implements AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ O f1267a;

    public M(O o2) {
        this.f1267a = o2;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        O o2 = this.f1267a;
        o2.f1279F.setSelection(i2);
        S s2 = o2.f1279F;
        if (s2.getOnItemClickListener() != null) {
            s2.performItemClick(view, i2, o2.f1276C.getItemId(i2));
        }
        o2.dismiss();
    }
}
