package i;

import android.content.res.Resources;

/* JADX INFO: loaded from: classes.dex */
public abstract class O0 extends Resources {
}
