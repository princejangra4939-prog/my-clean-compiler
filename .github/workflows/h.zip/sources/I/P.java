package i;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class P extends View.BaseSavedState {
    public static final Parcelable.Creator<P> CREATOR = new D.m(9);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1280a;

    @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        super.writeToParcel(parcel, i2);
        parcel.writeByte(this.f1280a ? (byte) 1 : (byte) 0);
    }
}
