package i;

import androidx.appcompat.widget.ActionBarContextView;

/* JADX INFO: renamed from: i.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0047a implements y.S {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1323a = false;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ ActionBarContextView f1324c;

    public C0047a(ActionBarContextView actionBarContextView) {
        this.f1324c = actionBarContextView;
    }

    @Override // y.S
    public final void a() {
        if (this.f1323a) {
            return;
        }
        ActionBarContextView actionBarContextView = this.f1324c;
        actionBarContextView.f = null;
        super/*android.view.View*/.setVisibility(this.b);
    }

    @Override // y.S
    public final void b() {
        this.f1323a = true;
    }

    @Override // y.S
    public final void c() {
        super/*android.view.View*/.setVisibility(0);
        this.f1323a = false;
    }
}
