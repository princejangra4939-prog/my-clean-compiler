package i;

import android.content.Context;
import android.graphics.drawable.Drawable;
import com.warppaiwarden.tictactoe.R;
import h.C0041b;
import s.AbstractC0128a;

/* JADX INFO: renamed from: i.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0067k extends B implements InterfaceC0071m {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C0069l f1386d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0067k(C0069l c0069l, Context context) {
        super(context, null, R.attr.actionOverflowButtonStyle);
        this.f1386d = c0069l;
        setClickable(true);
        setFocusable(true);
        setVisibility(0);
        setEnabled(true);
        D.g.f0(this, getContentDescription());
        setOnTouchListener(new C0041b(this, this));
    }

    @Override // i.InterfaceC0071m
    public final boolean a() {
        return false;
    }

    @Override // i.InterfaceC0071m
    public final boolean b() {
        return false;
    }

    @Override // android.view.View
    public final boolean performClick() {
        if (super.performClick()) {
            return true;
        }
        playSoundEffect(0);
        this.f1386d.l();
        return true;
    }

    @Override // android.widget.ImageView
    public final boolean setFrame(int i2, int i3, int i4, int i5) {
        boolean frame = super.setFrame(i2, i3, i4, i5);
        Drawable drawable = getDrawable();
        Drawable background = getBackground();
        if (drawable != null && background != null) {
            int width = getWidth();
            int height = getHeight();
            int iMax = Math.max(width, height) / 2;
            int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
            int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
            AbstractC0128a.f(background, paddingLeft - iMax, paddingTop - iMax, paddingLeft + iMax, paddingTop + iMax);
        }
        return frame;
    }
}
