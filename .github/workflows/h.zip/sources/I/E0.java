package i;

import android.os.Handler;
import android.widget.AbsListView;

/* JADX INFO: loaded from: classes.dex */
public final class E0 implements AbsListView.OnScrollListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ G0 f1222a;

    public E0(G0 g02) {
        this.f1222a = g02;
    }

    @Override // android.widget.AbsListView.OnScrollListener
    public final void onScrollStateChanged(AbsListView absListView, int i2) {
        if (i2 == 1) {
            G0 g02 = this.f1222a;
            if (g02.f1251y.getInputMethodMode() == 2 || g02.f1251y.getContentView() == null) {
                return;
            }
            Handler handler = g02.f1247u;
            C0 c0 = g02.f1243q;
            handler.removeCallbacks(c0);
            c0.run();
        }
    }

    @Override // android.widget.AbsListView.OnScrollListener
    public final void onScroll(AbsListView absListView, int i2, int i3, int i4) {
    }
}
