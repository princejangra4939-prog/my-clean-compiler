package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.TypedValue;
import com.warppaiwarden.tictactoe.R;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import l.AbstractC0104d;
import l.C0105e;
import l.C0112l;
import p.AbstractC0122a;

/* JADX INFO: loaded from: classes.dex */
public final class N0 {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static N0 f1269g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public WeakHashMap f1271a;
    public final WeakHashMap b = new WeakHashMap(0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TypedValue f1272c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1273d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public C0086u f1274e;
    public static final PorterDuff.Mode f = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final M0 f1270h = new M0(6);

    public static synchronized N0 b() {
        try {
            if (f1269g == null) {
                f1269g = new N0();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f1269g;
    }

    public static synchronized PorterDuffColorFilter e(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter porterDuffColorFilter;
        M0 m0 = f1270h;
        m0.getClass();
        int i3 = (31 + i2) * 31;
        porterDuffColorFilter = (PorterDuffColorFilter) m0.a(Integer.valueOf(mode.hashCode() + i3));
        if (porterDuffColorFilter == null) {
            porterDuffColorFilter = new PorterDuffColorFilter(i2, mode);
        }
        return porterDuffColorFilter;
    }

    public final Drawable a(Context context, int i2) {
        Drawable drawableNewDrawable;
        Object obj;
        int i3;
        if (this.f1272c == null) {
            this.f1272c = new TypedValue();
        }
        TypedValue typedValue = this.f1272c;
        context.getResources().getValue(i2, typedValue, true);
        long j2 = (((long) typedValue.assetCookie) << 32) | ((long) typedValue.data);
        synchronized (this) {
            C0105e c0105e = (C0105e) this.b.get(context);
            drawableNewDrawable = null;
            if (c0105e != null) {
                int iB = AbstractC0104d.b(c0105e.b, c0105e.f1512d, j2);
                if (iB < 0 || (obj = c0105e.f1511c[iB]) == C0105e.f1509e) {
                    obj = null;
                }
                WeakReference weakReference = (WeakReference) obj;
                if (weakReference != null) {
                    Drawable.ConstantState constantState = (Drawable.ConstantState) weakReference.get();
                    if (constantState != null) {
                        drawableNewDrawable = constantState.newDrawable(context.getResources());
                    } else {
                        int iB2 = AbstractC0104d.b(c0105e.b, c0105e.f1512d, j2);
                        if (iB2 >= 0) {
                            Object[] objArr = c0105e.f1511c;
                            Object obj2 = objArr[iB2];
                            Object obj3 = C0105e.f1509e;
                            if (obj2 != obj3) {
                                objArr[iB2] = obj3;
                                c0105e.f1510a = true;
                            }
                        }
                    }
                }
            }
        }
        if (drawableNewDrawable != null) {
            return drawableNewDrawable;
        }
        LayerDrawable layerDrawableC = null;
        if (this.f1274e != null) {
            if (i2 == R.drawable.abc_cab_background_top_material) {
                layerDrawableC = new LayerDrawable(new Drawable[]{c(context, R.drawable.abc_cab_background_internal_bg), c(context, R.drawable.abc_cab_background_top_mtrl_alpha)});
            } else if (i2 == R.drawable.abc_ratingbar_material) {
                layerDrawableC = C0086u.c(this, context, R.dimen.abc_star_big);
            } else if (i2 == R.drawable.abc_ratingbar_indicator_material) {
                layerDrawableC = C0086u.c(this, context, R.dimen.abc_star_medium);
            } else if (i2 == R.drawable.abc_ratingbar_small_material) {
                layerDrawableC = C0086u.c(this, context, R.dimen.abc_star_small);
            }
        }
        if (layerDrawableC == null) {
            return layerDrawableC;
        }
        layerDrawableC.setChangingConfigurations(typedValue.changingConfigurations);
        synchronized (this) {
            try {
                Drawable.ConstantState constantState2 = layerDrawableC.getConstantState();
                if (constantState2 != null) {
                    C0105e c0105e2 = (C0105e) this.b.get(context);
                    if (c0105e2 == null) {
                        c0105e2 = new C0105e();
                        c0105e2.f1510a = false;
                        int i4 = 4;
                        while (true) {
                            i3 = 80;
                            if (i4 >= 32) {
                                break;
                            }
                            int i5 = (1 << i4) - 12;
                            if (80 <= i5) {
                                i3 = i5;
                                break;
                            }
                            i4++;
                        }
                        int i6 = i3 / 8;
                        c0105e2.b = new long[i6];
                        c0105e2.f1511c = new Object[i6];
                        this.b.put(context, c0105e2);
                    }
                    c0105e2.b(j2, new WeakReference(constantState2));
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return layerDrawableC;
    }

    public final synchronized Drawable c(Context context, int i2) {
        return d(context, i2, false);
    }

    public final synchronized Drawable d(Context context, int i2, boolean z2) {
        Drawable drawableA;
        try {
            if (!this.f1273d) {
                this.f1273d = true;
                Drawable drawableC = c(context, R.drawable.abc_vector_test);
                if (drawableC == null || (!(drawableC instanceof R.a) && !"android.graphics.drawable.VectorDrawable".equals(drawableC.getClass().getName()))) {
                    this.f1273d = false;
                    throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
                }
            }
            drawableA = a(context, i2);
            if (drawableA == null) {
                drawableA = AbstractC0122a.b(context, i2);
            }
            if (drawableA != null) {
                drawableA = g(context, i2, z2, drawableA);
            }
            if (drawableA != null) {
                AbstractC0074n0.a(drawableA);
            }
        } catch (Throwable th) {
            throw th;
        }
        return drawableA;
    }

    public final synchronized ColorStateList f(Context context, int i2) {
        ColorStateList colorStateList;
        C0112l c0112l;
        Object obj;
        WeakHashMap weakHashMap = this.f1271a;
        ColorStateList colorStateListD = null;
        if (weakHashMap == null || (c0112l = (C0112l) weakHashMap.get(context)) == null) {
            colorStateList = null;
        } else {
            int iA = AbstractC0104d.a(c0112l.f1533c, i2, c0112l.f1532a);
            if (iA < 0 || (obj = c0112l.b[iA]) == C0112l.f1531d) {
                obj = null;
            }
            colorStateList = (ColorStateList) obj;
        }
        if (colorStateList == null) {
            C0086u c0086u = this.f1274e;
            if (c0086u != null) {
                colorStateListD = c0086u.d(context, i2);
            }
            if (colorStateListD != null) {
                if (this.f1271a == null) {
                    this.f1271a = new WeakHashMap();
                }
                C0112l c0112l2 = (C0112l) this.f1271a.get(context);
                if (c0112l2 == null) {
                    c0112l2 = new C0112l();
                    this.f1271a.put(context, c0112l2);
                }
                c0112l2.a(i2, colorStateListD);
            }
            colorStateList = colorStateListD;
        }
        return colorStateList;
    }

    /* JADX WARN: Removed duplicated region for block: B:49:0x00e5  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.graphics.drawable.Drawable g(android.content.Context r8, int r9, boolean r10, android.graphics.drawable.Drawable r11) {
        /*
            Method dump skipped, instruction units count: 264
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: i.N0.g(android.content.Context, int, boolean, android.graphics.drawable.Drawable):android.graphics.drawable.Drawable");
    }
}
