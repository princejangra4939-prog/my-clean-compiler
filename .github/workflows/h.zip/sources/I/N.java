package i;

import android.view.ViewTreeObserver;
import android.widget.PopupWindow;
import h.ViewTreeObserverOnGlobalLayoutListenerC0043d;

/* JADX INFO: loaded from: classes.dex */
public final class N implements PopupWindow.OnDismissListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ ViewTreeObserverOnGlobalLayoutListenerC0043d f1268a;
    public final /* synthetic */ O b;

    public N(O o2, ViewTreeObserverOnGlobalLayoutListenerC0043d viewTreeObserverOnGlobalLayoutListenerC0043d) {
        this.b = o2;
        this.f1268a = viewTreeObserverOnGlobalLayoutListenerC0043d;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public final void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.b.f1279F.getViewTreeObserver();
        if (viewTreeObserver != null) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f1268a);
        }
    }
}
