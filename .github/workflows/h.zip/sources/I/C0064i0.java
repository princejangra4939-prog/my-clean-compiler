package i;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.RectF;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.method.TransformationMethod;
import android.util.Log;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: renamed from: i.i0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0064i0 {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static final RectF f1366l = new RectF();

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public static final ConcurrentHashMap f1367m = new ConcurrentHashMap();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1368a = 0;
    public boolean b = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public float f1369c = -1.0f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f1370d = -1.0f;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f1371e = -1.0f;
    public int[] f = new int[0];

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1372g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public TextPaint f1373h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final TextView f1374i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final Context f1375j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final C0058f0 f1376k;

    public C0064i0(TextView textView) {
        this.f1374i = textView;
        this.f1375j = textView.getContext();
        if (Build.VERSION.SDK_INT >= 29) {
            this.f1376k = new C0060g0();
        } else {
            this.f1376k = new C0058f0();
        }
    }

    public static int[] b(int[] iArr) {
        int length = iArr.length;
        if (length != 0) {
            Arrays.sort(iArr);
            ArrayList arrayList = new ArrayList();
            for (int i2 : iArr) {
                if (i2 > 0 && Collections.binarySearch(arrayList, Integer.valueOf(i2)) < 0) {
                    arrayList.add(Integer.valueOf(i2));
                }
            }
            if (length != arrayList.size()) {
                int size = arrayList.size();
                int[] iArr2 = new int[size];
                for (int i3 = 0; i3 < size; i3++) {
                    iArr2[i3] = ((Integer) arrayList.get(i3)).intValue();
                }
                return iArr2;
            }
        }
        return iArr;
    }

    public static Method d(String str) {
        try {
            ConcurrentHashMap concurrentHashMap = f1367m;
            Method declaredMethod = (Method) concurrentHashMap.get(str);
            if (declaredMethod != null || (declaredMethod = TextView.class.getDeclaredMethod(str, null)) == null) {
                return declaredMethod;
            }
            declaredMethod.setAccessible(true);
            concurrentHashMap.put(str, declaredMethod);
            return declaredMethod;
        } catch (Exception e2) {
            Log.w("ACTVAutoSizeHelper", "Failed to retrieve TextView#" + str + "() method", e2);
            return null;
        }
    }

    public static Object e(Object obj, String str, Object obj2) {
        try {
            return d(str).invoke(obj, null);
        } catch (Exception e2) {
            Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#" + str + "() method", e2);
            return obj2;
        }
    }

    public final void a() {
        if (f()) {
            if (this.b) {
                if (this.f1374i.getMeasuredHeight() <= 0 || this.f1374i.getMeasuredWidth() <= 0) {
                    return;
                }
                int measuredWidth = this.f1376k.b(this.f1374i) ? 1048576 : (this.f1374i.getMeasuredWidth() - this.f1374i.getTotalPaddingLeft()) - this.f1374i.getTotalPaddingRight();
                int height = (this.f1374i.getHeight() - this.f1374i.getCompoundPaddingBottom()) - this.f1374i.getCompoundPaddingTop();
                if (measuredWidth <= 0 || height <= 0) {
                    return;
                }
                RectF rectF = f1366l;
                synchronized (rectF) {
                    try {
                        rectF.setEmpty();
                        rectF.right = measuredWidth;
                        rectF.bottom = height;
                        float fC = c(rectF);
                        if (fC != this.f1374i.getTextSize()) {
                            g(0, fC);
                        }
                    } finally {
                    }
                }
            }
            this.b = true;
        }
    }

    public final int c(RectF rectF) {
        CharSequence transformation;
        int length = this.f.length;
        if (length == 0) {
            throw new IllegalStateException("No available text sizes to choose from.");
        }
        int i2 = length - 1;
        int i3 = 0;
        int i4 = 1;
        while (i4 <= i2) {
            int i5 = (i4 + i2) / 2;
            int i6 = this.f[i5];
            TextView textView = this.f1374i;
            CharSequence text = textView.getText();
            TransformationMethod transformationMethod = textView.getTransformationMethod();
            CharSequence charSequence = (transformationMethod == null || (transformation = transformationMethod.getTransformation(text, textView)) == null) ? text : transformation;
            int maxLines = textView.getMaxLines();
            TextPaint textPaint = this.f1373h;
            if (textPaint == null) {
                this.f1373h = new TextPaint();
            } else {
                textPaint.reset();
            }
            this.f1373h.set(textView.getPaint());
            this.f1373h.setTextSize(i6);
            StaticLayout staticLayoutA = AbstractC0056e0.a(charSequence, (Layout.Alignment) e(textView, "getLayoutAlignment", Layout.Alignment.ALIGN_NORMAL), Math.round(rectF.right), maxLines, this.f1374i, this.f1373h, this.f1376k);
            if ((maxLines == -1 || (staticLayoutA.getLineCount() <= maxLines && staticLayoutA.getLineEnd(staticLayoutA.getLineCount() - 1) == charSequence.length())) && staticLayoutA.getHeight() <= rectF.bottom) {
                int i7 = i5 + 1;
                i3 = i4;
                i4 = i7;
            } else {
                i3 = i5 - 1;
                i2 = i3;
            }
        }
        return this.f[i3];
    }

    public final boolean f() {
        return j() && this.f1368a != 0;
    }

    public final void g(int i2, float f) {
        Context context = this.f1375j;
        float fApplyDimension = TypedValue.applyDimension(i2, f, (context == null ? Resources.getSystem() : context.getResources()).getDisplayMetrics());
        TextView textView = this.f1374i;
        if (fApplyDimension != textView.getPaint().getTextSize()) {
            textView.getPaint().setTextSize(fApplyDimension);
            boolean zIsInLayout = textView.isInLayout();
            if (textView.getLayout() != null) {
                this.b = false;
                try {
                    Method methodD = d("nullLayouts");
                    if (methodD != null) {
                        methodD.invoke(textView, null);
                    }
                } catch (Exception e2) {
                    Log.w("ACTVAutoSizeHelper", "Failed to invoke TextView#nullLayouts() method", e2);
                }
                if (zIsInLayout) {
                    textView.forceLayout();
                } else {
                    textView.requestLayout();
                }
                textView.invalidate();
            }
        }
    }

    public final boolean h() {
        if (j() && this.f1368a == 1) {
            if (!this.f1372g || this.f.length == 0) {
                int iFloor = ((int) Math.floor((this.f1371e - this.f1370d) / this.f1369c)) + 1;
                int[] iArr = new int[iFloor];
                for (int i2 = 0; i2 < iFloor; i2++) {
                    iArr[i2] = Math.round((i2 * this.f1369c) + this.f1370d);
                }
                this.f = b(iArr);
            }
            this.b = true;
        } else {
            this.b = false;
        }
        return this.b;
    }

    public final boolean i() {
        boolean z2 = this.f.length > 0;
        this.f1372g = z2;
        if (z2) {
            this.f1368a = 1;
            this.f1370d = r0[0];
            this.f1371e = r0[r1 - 1];
            this.f1369c = -1.0f;
        }
        return z2;
    }

    public final boolean j() {
        return !(this.f1374i instanceof C0092x);
    }

    public final void k(float f, float f2, float f3) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException("Minimum auto-size text size (" + f + "px) is less or equal to (0px)");
        }
        if (f2 <= f) {
            throw new IllegalArgumentException("Maximum auto-size text size (" + f2 + "px) is less or equal to minimum auto-size text size (" + f + "px)");
        }
        if (f3 <= 0.0f) {
            throw new IllegalArgumentException("The auto-size step granularity (" + f3 + "px) is less or equal to (0px)");
        }
        this.f1368a = 1;
        this.f1370d = f;
        this.f1371e = f2;
        this.f1369c = f3;
        this.f1372g = false;
    }
}
