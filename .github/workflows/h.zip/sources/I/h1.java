package i;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import com.warppaiwarden.tictactoe.R;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class h1 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public static h1 f1355k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public static h1 f1356l;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final View f1357a;
    public final CharSequence b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1358c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final g1 f1359d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final g1 f1360e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1361g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public i1 f1362h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f1363i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1364j;

    /* JADX WARN: Type inference failed for: r0v0, types: [i.g1] */
    /* JADX WARN: Type inference failed for: r0v1, types: [i.g1] */
    public h1(View view, CharSequence charSequence) {
        final int i2 = 0;
        this.f1359d = new Runnable(this) { // from class: i.g1
            public final /* synthetic */ h1 b;

            {
                this.b = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                switch (i2) {
                    case 0:
                        this.b.c(false);
                        break;
                    default:
                        this.b.a();
                        break;
                }
            }
        };
        final int i3 = 1;
        this.f1360e = new Runnable(this) { // from class: i.g1
            public final /* synthetic */ h1 b;

            {
                this.b = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                switch (i3) {
                    case 0:
                        this.b.c(false);
                        break;
                    default:
                        this.b.a();
                        break;
                }
            }
        };
        this.f1357a = view;
        this.b = charSequence;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(view.getContext());
        int i4 = y.N.f1651a;
        this.f1358c = Build.VERSION.SDK_INT >= 28 ? y.L.a(viewConfiguration) : viewConfiguration.getScaledTouchSlop() / 2;
        this.f1364j = true;
        view.setOnLongClickListener(this);
        view.setOnHoverListener(this);
    }

    public static void b(h1 h1Var) {
        h1 h1Var2 = f1355k;
        if (h1Var2 != null) {
            h1Var2.f1357a.removeCallbacks(h1Var2.f1359d);
        }
        f1355k = h1Var;
        if (h1Var != null) {
            h1Var.f1357a.postDelayed(h1Var.f1359d, ViewConfiguration.getLongPressTimeout());
        }
    }

    public final void a() {
        h1 h1Var = f1356l;
        View view = this.f1357a;
        if (h1Var == this) {
            f1356l = null;
            i1 i1Var = this.f1362h;
            if (i1Var != null) {
                View view2 = i1Var.b;
                if (view2.getParent() != null) {
                    ((WindowManager) i1Var.f1377a.getSystemService("window")).removeView(view2);
                }
                this.f1362h = null;
                this.f1364j = true;
                view.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f1355k == this) {
            b(null);
        }
        view.removeCallbacks(this.f1360e);
    }

    public final void c(boolean z2) {
        int height;
        int i2;
        int i3;
        int i4;
        int i5;
        int i6;
        long longPressTimeout;
        long j2;
        long j3;
        View view = this.f1357a;
        if (view.isAttachedToWindow()) {
            b(null);
            h1 h1Var = f1356l;
            if (h1Var != null) {
                h1Var.a();
            }
            f1356l = this;
            this.f1363i = z2;
            i1 i1Var = new i1(view.getContext());
            this.f1362h = i1Var;
            int width = this.f;
            int i7 = this.f1361g;
            boolean z3 = this.f1363i;
            View view2 = i1Var.b;
            ViewParent parent = view2.getParent();
            Context context = i1Var.f1377a;
            if (parent != null && view2.getParent() != null) {
                ((WindowManager) context.getSystemService("window")).removeView(view2);
            }
            i1Var.f1378c.setText(this.b);
            WindowManager.LayoutParams layoutParams = i1Var.f1379d;
            layoutParams.token = view.getApplicationWindowToken();
            int dimensionPixelOffset = context.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_threshold);
            if (view.getWidth() < dimensionPixelOffset) {
                width = view.getWidth() / 2;
            }
            if (view.getHeight() >= dimensionPixelOffset) {
                int dimensionPixelOffset2 = context.getResources().getDimensionPixelOffset(R.dimen.tooltip_precise_anchor_extra_offset);
                height = i7 + dimensionPixelOffset2;
                i2 = i7 - dimensionPixelOffset2;
            } else {
                height = view.getHeight();
                i2 = 0;
            }
            layoutParams.gravity = 49;
            int dimensionPixelOffset3 = context.getResources().getDimensionPixelOffset(z3 ? R.dimen.tooltip_y_offset_touch : R.dimen.tooltip_y_offset_non_touch);
            View rootView = view.getRootView();
            ViewGroup.LayoutParams layoutParams2 = rootView.getLayoutParams();
            if (!(layoutParams2 instanceof WindowManager.LayoutParams) || ((WindowManager.LayoutParams) layoutParams2).type != 2) {
                Context context2 = view.getContext();
                while (true) {
                    if (!(context2 instanceof ContextWrapper)) {
                        break;
                    }
                    if (context2 instanceof Activity) {
                        rootView = ((Activity) context2).getWindow().getDecorView();
                        break;
                    }
                    context2 = ((ContextWrapper) context2).getBaseContext();
                }
            }
            if (rootView == null) {
                Log.e("TooltipPopup", "Cannot find app view");
                i6 = 1;
            } else {
                Rect rect = i1Var.f1380e;
                rootView.getWindowVisibleDisplayFrame(rect);
                if (rect.left >= 0 || rect.top >= 0) {
                    i3 = width;
                    i4 = i2;
                    i5 = 0;
                    i6 = 1;
                } else {
                    Resources resources = context.getResources();
                    i6 = 1;
                    i3 = width;
                    i4 = i2;
                    int identifier = resources.getIdentifier("status_bar_height", "dimen", "android");
                    int dimensionPixelSize = identifier != 0 ? resources.getDimensionPixelSize(identifier) : 0;
                    DisplayMetrics displayMetrics = resources.getDisplayMetrics();
                    i5 = 0;
                    rect.set(0, dimensionPixelSize, displayMetrics.widthPixels, displayMetrics.heightPixels);
                }
                int[] iArr = i1Var.f1381g;
                rootView.getLocationOnScreen(iArr);
                int[] iArr2 = i1Var.f;
                view.getLocationOnScreen(iArr2);
                int i8 = iArr2[i5] - iArr[i5];
                iArr2[i5] = i8;
                iArr2[i6] = iArr2[i6] - iArr[i6];
                layoutParams.x = (i8 + i3) - (rootView.getWidth() / 2);
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i5, i5);
                view2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                int measuredHeight = view2.getMeasuredHeight();
                int i9 = iArr2[i6];
                int i10 = ((i9 + i4) - dimensionPixelOffset3) - measuredHeight;
                int i11 = i9 + height + dimensionPixelOffset3;
                if (z3) {
                    if (i10 >= 0) {
                        layoutParams.y = i10;
                    } else {
                        layoutParams.y = i11;
                    }
                } else if (measuredHeight + i11 <= rect.height()) {
                    layoutParams.y = i11;
                } else {
                    layoutParams.y = i10;
                }
            }
            ((WindowManager) context.getSystemService("window")).addView(view2, layoutParams);
            view.addOnAttachStateChangeListener(this);
            if (this.f1363i) {
                j3 = 2500;
            } else {
                WeakHashMap weakHashMap = y.K.f1647a;
                if ((view.getWindowSystemUiVisibility() & 1) == i6) {
                    longPressTimeout = ViewConfiguration.getLongPressTimeout();
                    j2 = 3000;
                } else {
                    longPressTimeout = ViewConfiguration.getLongPressTimeout();
                    j2 = 15000;
                }
                j3 = j2 - longPressTimeout;
            }
            g1 g1Var = this.f1360e;
            view.removeCallbacks(g1Var);
            view.postDelayed(g1Var, j3);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0066  */
    @Override // android.view.View.OnHoverListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onHover(android.view.View r4, android.view.MotionEvent r5) {
        /*
            r3 = this;
            i.i1 r4 = r3.f1362h
            r0 = 0
            if (r4 == 0) goto La
            boolean r4 = r3.f1363i
            if (r4 == 0) goto La
            goto L6f
        La:
            android.view.View r4 = r3.f1357a
            android.content.Context r1 = r4.getContext()
            java.lang.String r2 = "accessibility"
            java.lang.Object r1 = r1.getSystemService(r2)
            android.view.accessibility.AccessibilityManager r1 = (android.view.accessibility.AccessibilityManager) r1
            boolean r2 = r1.isEnabled()
            if (r2 == 0) goto L25
            boolean r1 = r1.isTouchExplorationEnabled()
            if (r1 == 0) goto L25
            goto L6f
        L25:
            int r1 = r5.getAction()
            r2 = 7
            if (r1 == r2) goto L38
            r4 = 10
            if (r1 == r4) goto L31
            goto L6f
        L31:
            r4 = 1
            r3.f1364j = r4
            r3.a()
            return r0
        L38:
            boolean r4 = r4.isEnabled()
            if (r4 == 0) goto L6f
            i.i1 r4 = r3.f1362h
            if (r4 != 0) goto L6f
            float r4 = r5.getX()
            int r4 = (int) r4
            float r5 = r5.getY()
            int r5 = (int) r5
            boolean r1 = r3.f1364j
            if (r1 != 0) goto L66
            int r1 = r3.f
            int r1 = r4 - r1
            int r1 = java.lang.Math.abs(r1)
            int r2 = r3.f1358c
            if (r1 > r2) goto L66
            int r1 = r3.f1361g
            int r1 = r5 - r1
            int r1 = java.lang.Math.abs(r1)
            if (r1 <= r2) goto L6f
        L66:
            r3.f = r4
            r3.f1361g = r5
            r3.f1364j = r0
            b(r3)
        L6f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: i.h1.onHover(android.view.View, android.view.MotionEvent):boolean");
    }

    @Override // android.view.View.OnLongClickListener
    public final boolean onLongClick(View view) {
        this.f = view.getWidth() / 2;
        this.f1361g = view.getHeight() / 2;
        c(true);
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        a();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
    }
}
