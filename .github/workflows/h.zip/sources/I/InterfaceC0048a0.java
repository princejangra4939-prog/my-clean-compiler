package i;

/* JADX INFO: renamed from: i.a0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0048a0 {
    void d(int i2);

    void o(int i2, float f);

    void v(int i2);
}
