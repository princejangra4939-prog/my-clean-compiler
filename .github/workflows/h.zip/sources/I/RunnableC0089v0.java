package i;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;

/* JADX INFO: renamed from: i.v0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class RunnableC0089v0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1451a;
    public final /* synthetic */ AbstractViewOnTouchListenerC0091w0 b;

    public /* synthetic */ RunnableC0089v0(AbstractViewOnTouchListenerC0091w0 abstractViewOnTouchListenerC0091w0, int i2) {
        this.f1451a = i2;
        this.b = abstractViewOnTouchListenerC0091w0;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f1451a) {
            case 0:
                ViewParent parent = this.b.f1455d.getParent();
                if (parent != null) {
                    parent.requestDisallowInterceptTouchEvent(true);
                }
                break;
            default:
                AbstractViewOnTouchListenerC0091w0 abstractViewOnTouchListenerC0091w0 = this.b;
                abstractViewOnTouchListenerC0091w0.a();
                View view = abstractViewOnTouchListenerC0091w0.f1455d;
                if (view.isEnabled() && !view.isLongClickable() && abstractViewOnTouchListenerC0091w0.c()) {
                    view.getParent().requestDisallowInterceptTouchEvent(true);
                    long jUptimeMillis = SystemClock.uptimeMillis();
                    MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                    view.onTouchEvent(motionEventObtain);
                    motionEventObtain.recycle();
                    abstractViewOnTouchListenerC0091w0.f1457g = true;
                    break;
                }
                break;
        }
    }
}
