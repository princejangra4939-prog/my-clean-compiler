package i;

import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;

/* JADX INFO: loaded from: classes.dex */
public final class X0 implements InterfaceC0075o, h.l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Toolbar f1309a;

    public /* synthetic */ X0(Toolbar toolbar) {
        this.f1309a = toolbar;
    }

    @Override // h.l
    public void g(h.n nVar) {
        Toolbar toolbar = this.f1309a;
        C0069l c0069l = toolbar.f489a.f450t;
        if (c0069l == null || !c0069l.h()) {
            toolbar.f475G.p();
        }
        e.G g2 = toolbar.f483O;
        if (g2 != null) {
            g2.g(nVar);
        }
    }

    @Override // h.l
    public boolean h(h.n nVar, MenuItem menuItem) {
        e.G g2 = this.f1309a.f483O;
        return false;
    }
}
