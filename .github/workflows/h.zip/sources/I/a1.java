package i;

import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public final class a1 extends ViewGroup.MarginLayoutParams {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1325a;
    public int b;

    public a1(a1 a1Var) {
        super((ViewGroup.MarginLayoutParams) a1Var);
        this.f1325a = 0;
        this.f1325a = a1Var.f1325a;
    }

    public a1(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f1325a = 0;
    }
}
