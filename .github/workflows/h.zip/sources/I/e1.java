package i;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;
import com.warppaiwarden.tictactoe.R;
import d.AbstractC0010a;

/* JADX INFO: loaded from: classes.dex */
public final class e1 implements InterfaceC0072m0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Toolbar f1339a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final View f1340c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Drawable f1341d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Drawable f1342e;
    public final Drawable f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f1343g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public CharSequence f1344h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final CharSequence f1345i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final CharSequence f1346j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public Window.Callback f1347k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f1348l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public C0069l f1349m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f1350n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Drawable f1351o;

    public e1(Toolbar toolbar, boolean z2) {
        Drawable drawable;
        this.f1350n = 0;
        this.f1339a = toolbar;
        this.f1344h = toolbar.getTitle();
        this.f1345i = toolbar.getSubtitle();
        this.f1343g = this.f1344h != null;
        this.f = toolbar.getNavigationIcon();
        C.h hVarM = C.h.m(toolbar.getContext(), null, AbstractC0010a.f800a, R.attr.actionBarStyle);
        int i2 = 15;
        this.f1351o = hVarM.i(15);
        if (z2) {
            TypedArray typedArray = (TypedArray) hVarM.b;
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                this.f1343g = true;
                this.f1344h = text;
                if ((this.b & 8) != 0) {
                    Toolbar toolbar2 = this.f1339a;
                    toolbar2.setTitle(text);
                    if (this.f1343g) {
                        y.K.i(toolbar2.getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                this.f1345i = text2;
                if ((this.b & 8) != 0) {
                    toolbar.setSubtitle(text2);
                }
            }
            Drawable drawableI = hVarM.i(20);
            if (drawableI != null) {
                this.f1342e = drawableI;
                c();
            }
            Drawable drawableI2 = hVarM.i(17);
            if (drawableI2 != null) {
                this.f1341d = drawableI2;
                c();
            }
            if (this.f == null && (drawable = this.f1351o) != null) {
                this.f = drawable;
                int i3 = this.b & 4;
                Toolbar toolbar3 = this.f1339a;
                if (i3 != 0) {
                    toolbar3.setNavigationIcon(drawable);
                } else {
                    toolbar3.setNavigationIcon((Drawable) null);
                }
            }
            a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View viewInflate = LayoutInflater.from(toolbar.getContext()).inflate(resourceId, (ViewGroup) toolbar, false);
                View view = this.f1340c;
                if (view != null && (this.b & 16) != 0) {
                    toolbar.removeView(view);
                }
                this.f1340c = viewInflate;
                if (viewInflate != null && (this.b & 16) != 0) {
                    toolbar.addView(viewInflate);
                }
                a(this.b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = toolbar.getLayoutParams();
                layoutParams.height = layoutDimension;
                toolbar.setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int iMax = Math.max(dimensionPixelOffset, 0);
                int iMax2 = Math.max(dimensionPixelOffset2, 0);
                toolbar.d();
                toolbar.f506t.a(iMax, iMax2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = toolbar.getContext();
                toolbar.f498l = resourceId2;
                C0054d0 c0054d0 = toolbar.b;
                if (c0054d0 != null) {
                    c0054d0.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = toolbar.getContext();
                toolbar.f499m = resourceId3;
                C0054d0 c0054d02 = toolbar.f490c;
                if (c0054d02 != null) {
                    c0054d02.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                toolbar.setPopupTheme(resourceId4);
            }
        } else {
            if (toolbar.getNavigationIcon() != null) {
                this.f1351o = toolbar.getNavigationIcon();
            } else {
                i2 = 11;
            }
            this.b = i2;
        }
        hVarM.r();
        if (R.string.abc_action_bar_up_description != this.f1350n) {
            this.f1350n = R.string.abc_action_bar_up_description;
            if (TextUtils.isEmpty(toolbar.getNavigationContentDescription())) {
                int i4 = this.f1350n;
                this.f1346j = i4 != 0 ? toolbar.getContext().getString(i4) : null;
                b();
            }
        }
        this.f1346j = toolbar.getNavigationContentDescription();
        toolbar.setNavigationOnClickListener(new d1(this));
    }

    public final void a(int i2) {
        View view;
        int i3 = this.b ^ i2;
        this.b = i2;
        if (i3 != 0) {
            if ((i3 & 4) != 0) {
                if ((i2 & 4) != 0) {
                    b();
                }
                int i4 = this.b & 4;
                Toolbar toolbar = this.f1339a;
                if (i4 != 0) {
                    Drawable drawable = this.f;
                    if (drawable == null) {
                        drawable = this.f1351o;
                    }
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            if ((i3 & 3) != 0) {
                c();
            }
            int i5 = i3 & 8;
            Toolbar toolbar2 = this.f1339a;
            if (i5 != 0) {
                if ((i2 & 8) != 0) {
                    toolbar2.setTitle(this.f1344h);
                    toolbar2.setSubtitle(this.f1345i);
                } else {
                    toolbar2.setTitle((CharSequence) null);
                    toolbar2.setSubtitle((CharSequence) null);
                }
            }
            if ((i3 & 16) == 0 || (view = this.f1340c) == null) {
                return;
            }
            if ((i2 & 16) != 0) {
                toolbar2.addView(view);
            } else {
                toolbar2.removeView(view);
            }
        }
    }

    public final void b() {
        if ((this.b & 4) != 0) {
            boolean zIsEmpty = TextUtils.isEmpty(this.f1346j);
            Toolbar toolbar = this.f1339a;
            if (zIsEmpty) {
                toolbar.setNavigationContentDescription(this.f1350n);
            } else {
                toolbar.setNavigationContentDescription(this.f1346j);
            }
        }
    }

    public final void c() {
        Drawable drawable;
        int i2 = this.b;
        if ((i2 & 2) == 0) {
            drawable = null;
        } else if ((i2 & 1) == 0 || (drawable = this.f1342e) == null) {
            drawable = this.f1341d;
        }
        this.f1339a.setLogo(drawable);
    }
}
