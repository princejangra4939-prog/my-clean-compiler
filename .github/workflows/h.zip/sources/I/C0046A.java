package i;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import d.AbstractC0010a;

/* JADX INFO: renamed from: i.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0046A {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ImageView f1210a;
    public U0 b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1211c = 0;

    public C0046A(ImageView imageView) {
        this.f1210a = imageView;
    }

    public final void a() {
        U0 u0;
        ImageView imageView = this.f1210a;
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            AbstractC0074n0.a(drawable);
        }
        if (drawable == null || (u0 = this.b) == null) {
            return;
        }
        C0088v.d(drawable, u0, imageView.getDrawableState());
    }

    public final void b(AttributeSet attributeSet, int i2) {
        int resourceId;
        ImageView imageView = this.f1210a;
        Context context = imageView.getContext();
        int[] iArr = AbstractC0010a.f;
        C.h hVarM = C.h.m(context, attributeSet, iArr, i2);
        y.K.g(imageView, imageView.getContext(), iArr, attributeSet, (TypedArray) hVarM.b, i2);
        try {
            Drawable drawable = imageView.getDrawable();
            TypedArray typedArray = (TypedArray) hVarM.b;
            if (drawable == null && (resourceId = typedArray.getResourceId(1, -1)) != -1 && (drawable = D.g.w(imageView.getContext(), resourceId)) != null) {
                imageView.setImageDrawable(drawable);
            }
            if (drawable != null) {
                AbstractC0074n0.a(drawable);
            }
            if (typedArray.hasValue(2)) {
                D.h.c(imageView, hVarM.h(2));
            }
            if (typedArray.hasValue(3)) {
                D.h.d(imageView, AbstractC0074n0.b(typedArray.getInt(3, -1), null));
            }
            hVarM.r();
        } catch (Throwable th) {
            hVarM.r();
            throw th;
        }
    }
}
