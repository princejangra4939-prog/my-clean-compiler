package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import com.warppaiwarden.tictactoe.R;

/* JADX INFO: loaded from: classes.dex */
public final class r extends Button {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0079q f1425a;
    public final Z b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C0094y f1426c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public r(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.buttonStyle);
        T0.a(context);
        S0.a(this, getContext());
        C0079q c0079q = new C0079q(this);
        this.f1425a = c0079q;
        c0079q.d(attributeSet, R.attr.buttonStyle);
        Z z2 = new Z(this);
        this.b = z2;
        z2.f(attributeSet, R.attr.buttonStyle);
        z2.b();
        getEmojiTextViewHelper().a(attributeSet, R.attr.buttonStyle);
    }

    private C0094y getEmojiTextViewHelper() {
        if (this.f1426c == null) {
            this.f1426c = new C0094y(this);
        }
        return this.f1426c;
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0079q c0079q = this.f1425a;
        if (c0079q != null) {
            c0079q.a();
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.b();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (m1.f1409c) {
            return super.getAutoSizeMaxTextSize();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f1316i.f1371e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (m1.f1409c) {
            return super.getAutoSizeMinTextSize();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f1316i.f1370d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (m1.f1409c) {
            return super.getAutoSizeStepGranularity();
        }
        Z z2 = this.b;
        if (z2 != null) {
            return Math.round(z2.f1316i.f1369c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (m1.f1409c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        Z z2 = this.b;
        return z2 != null ? z2.f1316i.f : new int[0];
    }

    @Override // android.widget.TextView
    public int getAutoSizeTextType() {
        if (m1.f1409c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        Z z2 = this.b;
        if (z2 != null) {
            return z2.f1316i.f1368a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return D.g.i0(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0079q c0079q = this.f1425a;
        if (c0079q != null) {
            return c0079q.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0079q c0079q = this.f1425a;
        if (c0079q != null) {
            return c0079q.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.b.d();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.b.e();
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        super.onLayout(z2, i2, i3, i4, i5);
        Z z3 = this.b;
        if (z3 == null || m1.f1409c) {
            return;
        }
        z3.f1316i.a();
    }

    @Override // android.widget.TextView
    public final void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
        super.onTextChanged(charSequence, i2, i3, i4);
        Z z2 = this.b;
        if (z2 == null || m1.f1409c) {
            return;
        }
        C0064i0 c0064i0 = z2.f1316i;
        if (c0064i0.f()) {
            c0064i0.a();
        }
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z2) {
        super.setAllCaps(z2);
        getEmojiTextViewHelper().b(z2);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i2, int i3, int i4, int i5) {
        if (m1.f1409c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i2, i3, i4, i5);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.i(i2, i3, i4, i5);
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i2) {
        if (m1.f1409c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i2);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.j(iArr, i2);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i2) {
        if (m1.f1409c) {
            super.setAutoSizeTextTypeWithDefaults(i2);
            return;
        }
        Z z2 = this.b;
        if (z2 != null) {
            z2.k(i2);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0079q c0079q = this.f1425a;
        if (c0079q != null) {
            c0079q.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0079q c0079q = this.f1425a;
        if (c0079q != null) {
            c0079q.f(i2);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(D.g.j0(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z2) {
        getEmojiTextViewHelper().c(z2);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(((D.g) getEmojiTextViewHelper().b.b).y(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z2) {
        Z z3 = this.b;
        if (z3 != null) {
            z3.f1310a.setAllCaps(z2);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0079q c0079q = this.f1425a;
        if (c0079q != null) {
            c0079q.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0079q c0079q = this.f1425a;
        if (c0079q != null) {
            c0079q.i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        Z z2 = this.b;
        z2.l(colorStateList);
        z2.b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        Z z2 = this.b;
        z2.m(mode);
        z2.b();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i2) {
        super.setTextAppearance(context, i2);
        Z z2 = this.b;
        if (z2 != null) {
            z2.g(context, i2);
        }
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i2, float f) {
        boolean z2 = m1.f1409c;
        if (z2) {
            super.setTextSize(i2, f);
            return;
        }
        Z z3 = this.b;
        if (z3 == null || z2) {
            return;
        }
        C0064i0 c0064i0 = z3.f1316i;
        if (c0064i0.f()) {
            return;
        }
        c0064i0.g(i2, f);
    }
}
