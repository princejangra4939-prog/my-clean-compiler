package i;

import android.view.View;
import android.widget.AdapterView;

/* JADX INFO: renamed from: i.z0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0097z0 implements AdapterView.OnItemSelectedListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ G0 f1480a;

    public C0097z0(G0 g02) {
        this.f1480a = g02;
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public final void onItemSelected(AdapterView adapterView, View view, int i2, long j2) {
        C0085t0 c0085t0;
        if (i2 == -1 || (c0085t0 = this.f1480a.f1230c) == null) {
            return;
        }
        c0085t0.setListSelectionHidden(false);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public final void onNothingSelected(AdapterView adapterView) {
    }
}
