package i;

/* JADX INFO: renamed from: i.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0090w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0092x f1452a;

    public C0090w(C0092x c0092x) {
        this.f1452a = c0092x;
    }
}
