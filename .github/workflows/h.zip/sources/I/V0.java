package i;

/* JADX INFO: loaded from: classes.dex */
public abstract class V0 extends O0 {
}
