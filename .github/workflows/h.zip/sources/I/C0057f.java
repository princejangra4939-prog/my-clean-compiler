package i;

import android.view.ViewGroup;

/* JADX INFO: renamed from: i.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0057f extends ViewGroup.MarginLayoutParams {
}
