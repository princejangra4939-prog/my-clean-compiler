package i;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewTreeObserver;
import android.widget.ListAdapter;
import com.warppaiwarden.tictactoe.R;
import h.ViewTreeObserverOnGlobalLayoutListenerC0043d;

/* JADX INFO: loaded from: classes.dex */
public final class O extends G0 implements Q {

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public CharSequence f1275B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public L f1276C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final Rect f1277D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public int f1278E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final /* synthetic */ S f1279F;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public O(S s2, Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.spinnerStyle);
        this.f1279F = s2;
        this.f1277D = new Rect();
        this.f1241o = s2;
        this.f1250x = true;
        this.f1251y.setFocusable(true);
        this.f1242p = new M(this);
    }

    @Override // i.Q
    public final CharSequence b() {
        return this.f1275B;
    }

    @Override // i.Q
    public final void e(int i2, int i3) {
        ViewTreeObserver viewTreeObserver;
        D d2 = this.f1251y;
        boolean zIsShowing = d2.isShowing();
        q();
        this.f1251y.setInputMethodMode(2);
        h();
        C0085t0 c0085t0 = this.f1230c;
        c0085t0.setChoiceMode(1);
        c0085t0.setTextDirection(i2);
        c0085t0.setTextAlignment(i3);
        S s2 = this.f1279F;
        int selectedItemPosition = s2.getSelectedItemPosition();
        C0085t0 c0085t02 = this.f1230c;
        if (d2.isShowing() && c0085t02 != null) {
            c0085t02.setListSelectionHidden(false);
            c0085t02.setSelection(selectedItemPosition);
            if (c0085t02.getChoiceMode() != 0) {
                c0085t02.setItemChecked(selectedItemPosition, true);
            }
        }
        if (zIsShowing || (viewTreeObserver = s2.getViewTreeObserver()) == null) {
            return;
        }
        ViewTreeObserverOnGlobalLayoutListenerC0043d viewTreeObserverOnGlobalLayoutListenerC0043d = new ViewTreeObserverOnGlobalLayoutListenerC0043d(3, this);
        viewTreeObserver.addOnGlobalLayoutListener(viewTreeObserverOnGlobalLayoutListenerC0043d);
        this.f1251y.setOnDismissListener(new N(this, viewTreeObserverOnGlobalLayoutListenerC0043d));
    }

    @Override // i.Q
    public final void g(CharSequence charSequence) {
        this.f1275B = charSequence;
    }

    @Override // i.G0, i.Q
    public final void m(ListAdapter listAdapter) {
        super.m(listAdapter);
        this.f1276C = (L) listAdapter;
    }

    @Override // i.Q
    public final void n(int i2) {
        this.f1278E = i2;
    }

    public final void q() {
        int i2;
        D d2 = this.f1251y;
        Drawable background = d2.getBackground();
        S s2 = this.f1279F;
        if (background != null) {
            background.getPadding(s2.f1293h);
            boolean z2 = m1.f1408a;
            int layoutDirection = s2.getLayoutDirection();
            Rect rect = s2.f1293h;
            i2 = layoutDirection == 1 ? rect.right : -rect.left;
        } else {
            Rect rect2 = s2.f1293h;
            rect2.right = 0;
            rect2.left = 0;
            i2 = 0;
        }
        int paddingLeft = s2.getPaddingLeft();
        int paddingRight = s2.getPaddingRight();
        int width = s2.getWidth();
        int i3 = s2.f1292g;
        if (i3 == -2) {
            int iA = s2.a(this.f1276C, d2.getBackground());
            int i4 = s2.getContext().getResources().getDisplayMetrics().widthPixels;
            Rect rect3 = s2.f1293h;
            int i5 = (i4 - rect3.left) - rect3.right;
            if (iA > i5) {
                iA = i5;
            }
            p(Math.max(iA, (width - paddingLeft) - paddingRight));
        } else if (i3 == -1) {
            p((width - paddingLeft) - paddingRight);
        } else {
            p(i3);
        }
        boolean z3 = m1.f1408a;
        this.f = s2.getLayoutDirection() == 1 ? (((width - paddingRight) - this.f1232e) - this.f1278E) + i2 : paddingLeft + this.f1278E + i2;
    }
}
