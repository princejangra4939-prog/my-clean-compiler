package i;

import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.appcompat.widget.Toolbar;
import g.InterfaceC0029b;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class Z0 implements h.z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public h.n f1321a;
    public h.p b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Toolbar f1322c;

    public Z0(Toolbar toolbar) {
        this.f1322c = toolbar;
    }

    @Override // h.z
    public final void c() {
        if (this.b != null) {
            h.n nVar = this.f1321a;
            if (nVar != null) {
                int size = nVar.f.size();
                for (int i2 = 0; i2 < size; i2++) {
                    if (this.f1321a.getItem(i2) == this.b) {
                        return;
                    }
                }
            }
            d(this.b);
        }
    }

    @Override // h.z
    public final boolean d(h.p pVar) {
        Toolbar toolbar = this.f1322c;
        KeyEvent.Callback callback = toolbar.f495i;
        if (callback instanceof InterfaceC0029b) {
            ((h.r) ((InterfaceC0029b) callback)).f1194a.onActionViewCollapsed();
        }
        toolbar.removeView(toolbar.f495i);
        toolbar.removeView(toolbar.f494h);
        toolbar.f495i = null;
        ArrayList arrayList = toolbar.f473E;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.b = null;
        toolbar.requestLayout();
        pVar.f1167C = false;
        pVar.f1179n.p(false);
        toolbar.v();
        return true;
    }

    @Override // h.z
    public final void g(Context context, h.n nVar) {
        h.p pVar;
        h.n nVar2 = this.f1321a;
        if (nVar2 != null && (pVar = this.b) != null) {
            nVar2.d(pVar);
        }
        this.f1321a = nVar;
    }

    @Override // h.z
    public final boolean i() {
        return false;
    }

    @Override // h.z
    public final boolean j(h.F f) {
        return false;
    }

    @Override // h.z
    public final boolean k(h.p pVar) {
        Toolbar toolbar = this.f1322c;
        toolbar.c();
        ViewParent parent = toolbar.f494h.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.f494h);
            }
            toolbar.addView(toolbar.f494h);
        }
        View actionView = pVar.getActionView();
        toolbar.f495i = actionView;
        this.b = pVar;
        ViewParent parent2 = actionView.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.f495i);
            }
            a1 a1VarH = Toolbar.h();
            a1VarH.f1325a = (toolbar.f500n & 112) | 8388611;
            a1VarH.b = 2;
            toolbar.f495i.setLayoutParams(a1VarH);
            toolbar.addView(toolbar.f495i);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = toolbar.getChildAt(childCount);
            if (((a1) childAt.getLayoutParams()).b != 2 && childAt != toolbar.f489a) {
                toolbar.removeViewAt(childCount);
                toolbar.f473E.add(childAt);
            }
        }
        toolbar.requestLayout();
        pVar.f1167C = true;
        pVar.f1179n.p(false);
        KeyEvent.Callback callback = toolbar.f495i;
        if (callback instanceof InterfaceC0029b) {
            ((h.r) ((InterfaceC0029b) callback)).f1194a.onActionViewExpanded();
        }
        toolbar.v();
        return true;
    }

    @Override // h.z
    public final void b(h.n nVar, boolean z2) {
    }
}
