package i;

/* JADX INFO: loaded from: classes.dex */
public interface k1 {
}
