package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

/* JADX INFO: loaded from: classes.dex */
public class B extends ImageView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0079q f1212a;
    public final C0046A b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1213c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public B(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        T0.a(context);
        this.f1213c = false;
        S0.a(this, getContext());
        C0079q c0079q = new C0079q(this);
        this.f1212a = c0079q;
        c0079q.d(attributeSet, i2);
        C0046A c0046a = new C0046A(this);
        this.b = c0046a;
        c0046a.b(attributeSet, i2);
    }

    @Override // android.widget.ImageView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        C0079q c0079q = this.f1212a;
        if (c0079q != null) {
            c0079q.a();
        }
        C0046A c0046a = this.b;
        if (c0046a != null) {
            c0046a.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0079q c0079q = this.f1212a;
        if (c0079q != null) {
            return c0079q.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0079q c0079q = this.f1212a;
        if (c0079q != null) {
            return c0079q.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        U0 u0;
        C0046A c0046a = this.b;
        if (c0046a == null || (u0 = c0046a.b) == null) {
            return null;
        }
        return u0.f1303a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        U0 u0;
        C0046A c0046a = this.b;
        if (c0046a == null || (u0 = c0046a.b) == null) {
            return null;
        }
        return u0.b;
    }

    @Override // android.widget.ImageView, android.view.View
    public final boolean hasOverlappingRendering() {
        return !(this.b.f1210a.getBackground() instanceof RippleDrawable) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0079q c0079q = this.f1212a;
        if (c0079q != null) {
            c0079q.e();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i2) {
        super.setBackgroundResource(i2);
        C0079q c0079q = this.f1212a;
        if (c0079q != null) {
            c0079q.f(i2);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C0046A c0046a = this.b;
        if (c0046a != null) {
            c0046a.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        C0046A c0046a = this.b;
        if (c0046a != null && drawable != null && !this.f1213c) {
            c0046a.f1211c = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (c0046a != null) {
            c0046a.a();
            if (this.f1213c) {
                return;
            }
            ImageView imageView = c0046a.f1210a;
            if (imageView.getDrawable() != null) {
                imageView.getDrawable().setLevel(c0046a.f1211c);
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i2) {
        super.setImageLevel(i2);
        this.f1213c = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i2) {
        C0046A c0046a = this.b;
        if (c0046a != null) {
            ImageView imageView = c0046a.f1210a;
            if (i2 != 0) {
                Drawable drawableW = D.g.w(imageView.getContext(), i2);
                if (drawableW != null) {
                    AbstractC0074n0.a(drawableW);
                }
                imageView.setImageDrawable(drawableW);
            } else {
                imageView.setImageDrawable(null);
            }
            c0046a.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C0046A c0046a = this.b;
        if (c0046a != null) {
            c0046a.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0079q c0079q = this.f1212a;
        if (c0079q != null) {
            c0079q.h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0079q c0079q = this.f1212a;
        if (c0079q != null) {
            c0079q.i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        C0046A c0046a = this.b;
        if (c0046a != null) {
            if (c0046a.b == null) {
                c0046a.b = new U0();
            }
            U0 u0 = c0046a.b;
            u0.f1303a = colorStateList;
            u0.f1305d = true;
            c0046a.a();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C0046A c0046a = this.b;
        if (c0046a != null) {
            if (c0046a.b == null) {
                c0046a.b = new U0();
            }
            U0 u0 = c0046a.b;
            u0.b = mode;
            u0.f1304c = true;
            c0046a.a();
        }
    }
}
