package i;

/* JADX INFO: renamed from: i.c0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0052c0 extends C0050b0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C0054d0 f1329d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0052c0(C0054d0 c0054d0) {
        super(c0054d0);
        this.f1329d = c0054d0;
    }

    @Override // C.j, i.InterfaceC0048a0
    public final void o(int i2, float f) {
        super/*android.widget.TextView*/.setLineHeight(i2, f);
    }
}
