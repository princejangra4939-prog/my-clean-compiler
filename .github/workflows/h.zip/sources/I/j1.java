package i;

/* JADX INFO: loaded from: classes.dex */
public abstract class j1 extends O0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int f1385a = 0;
}
