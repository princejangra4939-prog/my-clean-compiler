package i;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public final class U {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1300a;
    public final /* synthetic */ int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ WeakReference f1301c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Z f1302d;

    public U(Z z2, int i2, int i3, WeakReference weakReference) {
        this.f1302d = z2;
        this.f1300a = i2;
        this.b = i3;
        this.f1301c = weakReference;
    }

    public final void a() {
        new Handler(Looper.getMainLooper()).post(new androidx.activity.d(6, this));
    }

    public final void b(Typeface typeface) {
        int i2;
        if (Build.VERSION.SDK_INT >= 28 && (i2 = this.f1300a) != -1) {
            typeface = Y.a(typeface, i2, (this.b & 2) != 0);
        }
        Z z2 = this.f1302d;
        if (z2.f1320m) {
            z2.f1319l = typeface;
            TextView textView = (TextView) this.f1301c.get();
            if (textView != null) {
                if (textView.isAttachedToWindow()) {
                    textView.post(new V(textView, typeface, z2.f1317j));
                } else {
                    textView.setTypeface(typeface, z2.f1317j);
                }
            }
        }
    }
}
