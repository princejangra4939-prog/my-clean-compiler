package i;

import android.view.View;

/* JADX INFO: renamed from: i.o0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0076o0 {
    public static void a(View view, float f, float f2) {
        view.drawableHotspotChanged(f, f2);
    }
}
