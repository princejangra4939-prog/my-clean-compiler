package i;

import android.widget.AdapterView;
import android.widget.HorizontalScrollView;

/* JADX INFO: loaded from: classes.dex */
public abstract class Q0 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
}
