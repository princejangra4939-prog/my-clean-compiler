package i;

import android.content.Context;
import android.view.View;
import android.view.Window;
import h.C0040a;

/* JADX INFO: loaded from: classes.dex */
public final class d1 implements View.OnClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0040a f1338a;
    public final /* synthetic */ e1 b;

    public d1(e1 e1Var) {
        this.b = e1Var;
        Context context = e1Var.f1339a.getContext();
        CharSequence charSequence = e1Var.f1344h;
        C0040a c0040a = new C0040a();
        c0040a.f1088e = 4096;
        c0040a.f1089g = 4096;
        c0040a.f1094l = null;
        c0040a.f1095m = null;
        c0040a.f1096n = false;
        c0040a.f1097o = false;
        c0040a.f1098p = 16;
        c0040a.f1091i = context;
        c0040a.f1085a = charSequence;
        this.f1338a = c0040a;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        e1 e1Var = this.b;
        Window.Callback callback = e1Var.f1347k;
        if (callback == null || !e1Var.f1348l) {
            return;
        }
        callback.onMenuItemSelected(0, this.f1338a);
    }
}
