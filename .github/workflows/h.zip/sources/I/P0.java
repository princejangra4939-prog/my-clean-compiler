package i;

/* JADX INFO: loaded from: classes.dex */
public final class P0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1281a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1282c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1283d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1284e;
    public int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1285g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1286h;

    public final void a(int i2, int i3) {
        this.f1282c = i2;
        this.f1283d = i3;
        this.f1286h = true;
        if (this.f1285g) {
            if (i3 != Integer.MIN_VALUE) {
                this.f1281a = i3;
            }
            if (i2 != Integer.MIN_VALUE) {
                this.b = i2;
                return;
            }
            return;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f1281a = i2;
        }
        if (i3 != Integer.MIN_VALUE) {
            this.b = i3;
        }
    }
}
