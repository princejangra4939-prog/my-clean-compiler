package i;

/* JADX INFO: loaded from: classes.dex */
public final class C0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1217a;
    public final /* synthetic */ G0 b;

    public /* synthetic */ C0(G0 g02, int i2) {
        this.f1217a = i2;
        this.b = g02;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f1217a) {
            case 0:
                C0085t0 c0085t0 = this.b.f1230c;
                if (c0085t0 != null) {
                    c0085t0.setListSelectionHidden(true);
                    c0085t0.requestLayout();
                }
                break;
            default:
                G0 g02 = this.b;
                C0085t0 c0085t02 = g02.f1230c;
                if (c0085t02 != null && c0085t02.isAttachedToWindow() && g02.f1230c.getCount() > g02.f1230c.getChildCount() && g02.f1230c.getChildCount() <= g02.f1239m) {
                    g02.f1251y.setInputMethodMode(2);
                    g02.h();
                    break;
                }
                break;
        }
    }
}
