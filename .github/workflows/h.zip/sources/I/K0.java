package i;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;

/* JADX INFO: loaded from: classes.dex */
public final class K0 extends C0085t0 {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final int f1260m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f1261n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public H0 f1262o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public h.p f1263p;

    public K0(Context context, boolean z2) {
        super(context, z2);
        if (1 == context.getResources().getConfiguration().getLayoutDirection()) {
            this.f1260m = 21;
            this.f1261n = 22;
        } else {
            this.f1260m = 22;
            this.f1261n = 21;
        }
    }

    @Override // i.C0085t0, android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        h.k kVar;
        int headersCount;
        int iPointToPosition;
        int i2;
        if (this.f1262o != null) {
            ListAdapter adapter = getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                HeaderViewListAdapter headerViewListAdapter = (HeaderViewListAdapter) adapter;
                headersCount = headerViewListAdapter.getHeadersCount();
                kVar = (h.k) headerViewListAdapter.getWrappedAdapter();
            } else {
                kVar = (h.k) adapter;
                headersCount = 0;
            }
            h.p item = (motionEvent.getAction() == 10 || (iPointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY())) == -1 || (i2 = iPointToPosition - headersCount) < 0 || i2 >= kVar.getCount()) ? null : kVar.getItem(i2);
            h.p pVar = this.f1263p;
            if (pVar != item) {
                h.n nVar = kVar.f1136a;
                if (pVar != null) {
                    this.f1262o.t(nVar, pVar);
                }
                this.f1263p = item;
                if (item != null) {
                    this.f1262o.r(nVar, item);
                }
            }
        }
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        ListMenuItemView listMenuItemView = (ListMenuItemView) getSelectedView();
        if (listMenuItemView != null && i2 == this.f1260m) {
            if (listMenuItemView.isEnabled() && listMenuItemView.getItemData().hasSubMenu()) {
                performItemClick(listMenuItemView, getSelectedItemPosition(), getSelectedItemId());
            }
            return true;
        }
        if (listMenuItemView == null || i2 != this.f1261n) {
            return super.onKeyDown(i2, keyEvent);
        }
        setSelection(-1);
        ListAdapter adapter = getAdapter();
        (adapter instanceof HeaderViewListAdapter ? (h.k) ((HeaderViewListAdapter) adapter).getWrappedAdapter() : (h.k) adapter).f1136a.c(false);
        return true;
    }

    public void setHoverListener(H0 h02) {
        this.f1262o = h02;
    }

    @Override // i.C0085t0, android.widget.AbsListView
    public /* bridge */ /* synthetic */ void setSelector(Drawable drawable) {
        super.setSelector(drawable);
    }
}
