package i;

import android.view.MotionEvent;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class F0 implements View.OnTouchListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ G0 f1226a;

    public F0(G0 g02) {
        this.f1226a = g02;
    }

    @Override // android.view.View.OnTouchListener
    public final boolean onTouch(View view, MotionEvent motionEvent) {
        D d2;
        int action = motionEvent.getAction();
        int x2 = (int) motionEvent.getX();
        int y2 = (int) motionEvent.getY();
        G0 g02 = this.f1226a;
        if (action == 0 && (d2 = g02.f1251y) != null && d2.isShowing() && x2 >= 0 && x2 < g02.f1251y.getWidth() && y2 >= 0 && y2 < g02.f1251y.getHeight()) {
            g02.f1247u.postDelayed(g02.f1243q, 250L);
            return false;
        }
        if (action != 1) {
            return false;
        }
        g02.f1247u.removeCallbacks(g02.f1243q);
        return false;
    }
}
