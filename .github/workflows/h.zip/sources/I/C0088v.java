package i;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.Log;

/* JADX INFO: renamed from: i.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0088v {
    public static final PorterDuff.Mode b = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static C0088v f1449c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public N0 f1450a;

    public static synchronized C0088v a() {
        try {
            if (f1449c == null) {
                c();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f1449c;
    }

    public static synchronized void c() {
        if (f1449c == null) {
            C0088v c0088v = new C0088v();
            f1449c = c0088v;
            c0088v.f1450a = N0.b();
            N0 n0 = f1449c.f1450a;
            C0086u c0086u = new C0086u();
            synchronized (n0) {
                n0.f1274e = c0086u;
            }
        }
    }

    public static void d(Drawable drawable, U0 u0, int[] iArr) {
        PorterDuff.Mode mode = N0.f;
        int[] state = drawable.getState();
        if (drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        if ((drawable instanceof LayerDrawable) && drawable.isStateful()) {
            drawable.setState(new int[0]);
            drawable.setState(state);
        }
        boolean z2 = u0.f1305d;
        if (!z2 && !u0.f1304c) {
            drawable.clearColorFilter();
            return;
        }
        PorterDuffColorFilter porterDuffColorFilterE = null;
        ColorStateList colorStateList = z2 ? u0.f1303a : null;
        PorterDuff.Mode mode2 = u0.f1304c ? u0.b : N0.f;
        if (colorStateList != null && mode2 != null) {
            porterDuffColorFilterE = N0.e(colorStateList.getColorForState(iArr, 0), mode2);
        }
        drawable.setColorFilter(porterDuffColorFilterE);
    }

    public final synchronized Drawable b(Context context, int i2) {
        return this.f1450a.c(context, i2);
    }
}
