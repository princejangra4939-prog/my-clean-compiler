package i;

import android.view.View;
import android.view.ViewConfiguration;

/* JADX INFO: renamed from: i.w0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractViewOnTouchListenerC0091w0 implements View.OnTouchListener, View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f1453a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1454c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final View f1455d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public RunnableC0089v0 f1456e;
    public RunnableC0089v0 f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1457g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f1458h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int[] f1459i = new int[2];

    public AbstractViewOnTouchListenerC0091w0(View view) {
        this.f1455d = view;
        view.setLongClickable(true);
        view.addOnAttachStateChangeListener(this);
        this.f1453a = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
        int tapTimeout = ViewConfiguration.getTapTimeout();
        this.b = tapTimeout;
        this.f1454c = (ViewConfiguration.getLongPressTimeout() + tapTimeout) / 2;
    }

    public final void a() {
        RunnableC0089v0 runnableC0089v0 = this.f;
        View view = this.f1455d;
        if (runnableC0089v0 != null) {
            view.removeCallbacks(runnableC0089v0);
        }
        RunnableC0089v0 runnableC0089v02 = this.f1456e;
        if (runnableC0089v02 != null) {
            view.removeCallbacks(runnableC0089v02);
        }
    }

    public abstract h.D b();

    public abstract boolean c();

    public boolean d() {
        h.D dB = b();
        if (dB == null || !dB.a()) {
            return true;
        }
        dB.dismiss();
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0100  */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onTouch(android.view.View r13, android.view.MotionEvent r14) {
        /*
            Method dump skipped, instruction units count: 284
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: i.AbstractViewOnTouchListenerC0091w0.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        this.f1457g = false;
        this.f1458h = -1;
        RunnableC0089v0 runnableC0089v0 = this.f1456e;
        if (runnableC0089v0 != null) {
            this.f1455d.removeCallbacks(runnableC0089v0);
        }
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
    }
}
