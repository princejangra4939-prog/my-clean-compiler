package i;

import android.content.Context;
import android.view.View;
import com.warppaiwarden.tictactoe.R;

/* JADX INFO: renamed from: i.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0061h extends h.x {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final /* synthetic */ int f1353l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final /* synthetic */ C0069l f1354m;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0061h(C0069l c0069l, Context context, h.n nVar, View view) {
        super(R.attr.actionOverflowMenuStyle, context, view, nVar, true);
        this.f1354m = c0069l;
        this.f = 8388613;
        C.j jVar = c0069l.f1407w;
        this.f1206h = jVar;
        h.v vVar = this.f1207i;
        if (vVar != null) {
            vVar.e(jVar);
        }
    }

    @Override // h.x
    public final void c() {
        switch (this.f1353l) {
            case 0:
                C0069l c0069l = this.f1354m;
                c0069l.f1404t = null;
                c0069l.getClass();
                super.c();
                break;
            default:
                C0069l c0069l2 = this.f1354m;
                h.n nVar = c0069l2.f1388c;
                if (nVar != null) {
                    nVar.c(true);
                }
                c0069l2.f1403s = null;
                super.c();
                break;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0061h(C0069l c0069l, Context context, h.F f, View view) {
        super(R.attr.actionOverflowMenuStyle, context, view, f, false);
        this.f1354m = c0069l;
        if ((f.f1083A.f1189x & 32) != 32) {
            View view2 = c0069l.f1393i;
            this.f1204e = view2 == null ? (View) c0069l.f1392h : view2;
        }
        C.j jVar = c0069l.f1407w;
        this.f1206h = jVar;
        h.v vVar = this.f1207i;
        if (vVar != null) {
            vVar.e(jVar);
        }
    }
}
