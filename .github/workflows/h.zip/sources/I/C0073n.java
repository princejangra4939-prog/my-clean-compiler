package i;

/* JADX INFO: renamed from: i.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0073n extends C0093x0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1410a;
    public int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1411c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f1412d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1413e;
    public boolean f;
}
