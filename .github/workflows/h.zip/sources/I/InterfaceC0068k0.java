package i;

/* JADX INFO: renamed from: i.k0, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0068k0 {
}
