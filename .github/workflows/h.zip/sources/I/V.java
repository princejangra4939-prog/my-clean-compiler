package i;

import android.graphics.Typeface;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public final class V implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ TextView f1306a;
    public final /* synthetic */ Typeface b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1307c;

    public V(TextView textView, Typeface typeface, int i2) {
        this.f1306a = textView;
        this.b = typeface;
        this.f1307c = i2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f1306a.setTypeface(this.b, this.f1307c);
    }
}
