package g;

import T.t;
import android.content.Context;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.ActionBarContextView;
import h.n;
import i.C0069l;
import java.lang.ref.WeakReference;

/* JADX INFO: renamed from: g.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0031d extends AbstractC0028a implements h.l {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Context f1017c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ActionBarContextView f1018d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public G.a f1019e;
    public WeakReference f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1020g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public n f1021h;

    @Override // g.AbstractC0028a
    public final void a() {
        if (this.f1020g) {
            return;
        }
        this.f1020g = true;
        this.f1019e.b(this);
    }

    @Override // g.AbstractC0028a
    public final View b() {
        WeakReference weakReference = this.f;
        if (weakReference != null) {
            return (View) weakReference.get();
        }
        return null;
    }

    @Override // g.AbstractC0028a
    public final n c() {
        return this.f1021h;
    }

    @Override // g.AbstractC0028a
    public final MenuInflater d() {
        return new C0035h(this.f1018d.getContext());
    }

    @Override // g.AbstractC0028a
    public final CharSequence e() {
        return this.f1018d.getSubtitle();
    }

    @Override // g.AbstractC0028a
    public final CharSequence f() {
        return this.f1018d.getTitle();
    }

    @Override // h.l
    public final void g(n nVar) {
        i();
        C0069l c0069l = this.f1018d.f400d;
        if (c0069l != null) {
            c0069l.l();
        }
    }

    @Override // h.l
    public final boolean h(n nVar, MenuItem menuItem) {
        return ((t) this.f1019e.f57a).f(this, menuItem);
    }

    @Override // g.AbstractC0028a
    public final void i() {
        this.f1019e.d(this, this.f1021h);
    }

    @Override // g.AbstractC0028a
    public final boolean j() {
        return this.f1018d.f414s;
    }

    @Override // g.AbstractC0028a
    public final void k(View view) {
        this.f1018d.setCustomView(view);
        this.f = view != null ? new WeakReference(view) : null;
    }

    @Override // g.AbstractC0028a
    public final void l(int i2) {
        m(this.f1017c.getString(i2));
    }

    @Override // g.AbstractC0028a
    public final void m(CharSequence charSequence) {
        this.f1018d.setSubtitle(charSequence);
    }

    @Override // g.AbstractC0028a
    public final void n(int i2) {
        o(this.f1017c.getString(i2));
    }

    @Override // g.AbstractC0028a
    public final void o(CharSequence charSequence) {
        this.f1018d.setTitle(charSequence);
    }

    @Override // g.AbstractC0028a
    public final void p(boolean z2) {
        this.b = z2;
        this.f1018d.setTitleOptional(z2);
    }
}
