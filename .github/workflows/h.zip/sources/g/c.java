package G;

import android.os.Bundle;
import android.text.Editable;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.widget.EditText;
import java.nio.ByteBuffer;

/* JADX INFO: loaded from: classes.dex */
public final class c extends InputConnectionWrapper {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final EditText f60a;
    public final F.d b;

    public c(EditText editText, InputConnection inputConnection, EditorInfo editorInfo) {
        F.d dVar = new F.d(1);
        super(inputConnection, false);
        this.f60a = editText;
        this.b = dVar;
        if (androidx.emoji2.text.k.f569k != null) {
            androidx.emoji2.text.k kVarA = androidx.emoji2.text.k.a();
            if (kVarA.b() != 1 || editorInfo == null) {
                return;
            }
            if (editorInfo.extras == null) {
                editorInfo.extras = new Bundle();
            }
            androidx.emoji2.text.g gVar = kVarA.f573e;
            gVar.getClass();
            Bundle bundle = editorInfo.extras;
            F.b bVar = (F.b) gVar.f566c.f211a;
            int iA = bVar.a(4);
            bundle.putInt("android.support.text.emoji.emojiCompat_metadataVersion", iA != 0 ? ((ByteBuffer) bVar.f55d).getInt(iA + bVar.f53a) : 0);
            Bundle bundle2 = editorInfo.extras;
            gVar.f565a.getClass();
            bundle2.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", false);
        }
    }

    @Override // android.view.inputmethod.InputConnectionWrapper, android.view.inputmethod.InputConnection
    public final boolean deleteSurroundingText(int i2, int i3) {
        Editable editableText = this.f60a.getEditableText();
        this.b.getClass();
        return F.d.f(this, editableText, i2, i3, false) || super.deleteSurroundingText(i2, i3);
    }

    @Override // android.view.inputmethod.InputConnectionWrapper, android.view.inputmethod.InputConnection
    public final boolean deleteSurroundingTextInCodePoints(int i2, int i3) {
        Editable editableText = this.f60a.getEditableText();
        this.b.getClass();
        return F.d.f(this, editableText, i2, i3, true) || super.deleteSurroundingTextInCodePoints(i2, i3);
    }
}
