package g;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.SubMenu;
import d.AbstractC0010a;
import h.n;
import h.q;
import i.AbstractC0074n0;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: renamed from: g.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0035h extends MenuInflater {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final Class[] f1054e;
    public static final Class[] f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object[] f1055a;
    public final Object[] b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Context f1056c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f1057d;

    static {
        Class[] clsArr = {Context.class};
        f1054e = clsArr;
        f = clsArr;
    }

    public C0035h(Context context) {
        super(context);
        this.f1056c = context;
        Object[] objArr = {context};
        this.f1055a = objArr;
        this.b = objArr;
    }

    public static Object a(Object obj) {
        return (!(obj instanceof Activity) && (obj instanceof ContextWrapper)) ? a(((ContextWrapper) obj).getBaseContext()) : obj;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r16v0, types: [g.h] */
    /* JADX WARN: Type inference failed for: r3v15, types: [android.content.res.TypedArray] */
    /* JADX WARN: Type inference failed for: r4v0 */
    /* JADX WARN: Type inference failed for: r4v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r4v60 */
    /* JADX WARN: Type inference failed for: r8v1 */
    /* JADX WARN: Type inference failed for: r8v10 */
    /* JADX WARN: Type inference failed for: r8v11 */
    /* JADX WARN: Type inference failed for: r8v13 */
    /* JADX WARN: Type inference failed for: r8v2 */
    /* JADX WARN: Type inference failed for: r8v5 */
    /* JADX WARN: Type inference failed for: r8v7 */
    /* JADX WARN: Type inference failed for: r8v8 */
    /* JADX WARN: Type inference failed for: r8v9 */
    public final void b(XmlResourceParser xmlResourceParser, AttributeSet attributeSet, Menu menu) throws XmlPullParserException, IOException {
        ?? r4;
        int i2;
        XmlResourceParser xmlResourceParser2;
        ?? r8;
        ColorStateList colorStateList;
        int resourceId;
        C0034g c0034g = new C0034g(this, menu);
        int eventType = xmlResourceParser.getEventType();
        while (true) {
            r4 = 1;
            i2 = 2;
            if (eventType == 2) {
                String name = xmlResourceParser.getName();
                if (!name.equals("menu")) {
                    throw new RuntimeException("Expecting menu, got ".concat(name));
                }
                eventType = xmlResourceParser.next();
            } else {
                eventType = xmlResourceParser.next();
                if (eventType == 1) {
                    break;
                }
            }
        }
        boolean z2 = false;
        boolean z3 = false;
        String str = null;
        while (!z2) {
            if (eventType == r4) {
                throw new RuntimeException("Unexpected end of document");
            }
            if (eventType != i2) {
                if (eventType != 3) {
                    xmlResourceParser2 = xmlResourceParser;
                    r8 = r4;
                    z2 = z2;
                } else {
                    String name2 = xmlResourceParser.getName();
                    if (z3 && name2.equals(str)) {
                        xmlResourceParser2 = xmlResourceParser;
                        r8 = r4;
                        z3 = false;
                        str = null;
                    } else {
                        if (name2.equals("group")) {
                            c0034g.b = 0;
                            c0034g.f1031c = 0;
                            c0034g.f1032d = 0;
                            c0034g.f1033e = 0;
                            c0034g.f = r4;
                            c0034g.f1034g = r4;
                        } else if (name2.equals("item")) {
                            if (!c0034g.f1035h) {
                                q qVar = c0034g.f1053z;
                                if (qVar == null || !qVar.b.hasSubMenu()) {
                                    c0034g.f1035h = r4;
                                    c0034g.b(c0034g.f1030a.add(c0034g.b, c0034g.f1036i, c0034g.f1037j, c0034g.f1038k));
                                } else {
                                    c0034g.f1035h = r4;
                                    c0034g.b(c0034g.f1030a.addSubMenu(c0034g.b, c0034g.f1036i, c0034g.f1037j, c0034g.f1038k).getItem());
                                }
                            }
                        } else if (name2.equals("menu")) {
                            xmlResourceParser2 = xmlResourceParser;
                            ?? r82 = r4;
                            z2 = r82 == true ? 1 : 0;
                            r8 = r82;
                        }
                        xmlResourceParser2 = xmlResourceParser;
                        r8 = r4;
                        z2 = z2;
                    }
                }
                eventType = xmlResourceParser2.next();
                r4 = r8;
                i2 = 2;
                z2 = z2;
                z3 = z3;
            } else {
                if (!z3) {
                    String name3 = xmlResourceParser.getName();
                    boolean zEquals = name3.equals("group");
                    C0035h c0035h = c0034g.f1029E;
                    if (zEquals) {
                        ?? ObtainStyledAttributes = c0035h.f1056c.obtainStyledAttributes(attributeSet, AbstractC0010a.f813p);
                        c0034g.b = ObtainStyledAttributes.getResourceId(r4, 0);
                        c0034g.f1031c = ObtainStyledAttributes.getInt(3, 0);
                        c0034g.f1032d = ObtainStyledAttributes.getInt(4, 0);
                        c0034g.f1033e = ObtainStyledAttributes.getInt(5, 0);
                        c0034g.f = ObtainStyledAttributes.getBoolean(2, r4);
                        c0034g.f1034g = ObtainStyledAttributes.getBoolean(0, r4);
                        ObtainStyledAttributes.recycle();
                    } else {
                        if (name3.equals("item")) {
                            Context context = c0035h.f1056c;
                            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0010a.f814q);
                            c0034g.f1036i = typedArrayObtainStyledAttributes.getResourceId(2, 0);
                            c0034g.f1037j = (typedArrayObtainStyledAttributes.getInt(5, c0034g.f1031c) & (-65536)) | (typedArrayObtainStyledAttributes.getInt(6, c0034g.f1032d) & 65535);
                            c0034g.f1038k = typedArrayObtainStyledAttributes.getText(7);
                            c0034g.f1039l = typedArrayObtainStyledAttributes.getText(8);
                            c0034g.f1040m = typedArrayObtainStyledAttributes.getResourceId(0, 0);
                            String string = typedArrayObtainStyledAttributes.getString(9);
                            c0034g.f1041n = string == null ? (char) 0 : string.charAt(0);
                            c0034g.f1042o = typedArrayObtainStyledAttributes.getInt(16, 4096);
                            String string2 = typedArrayObtainStyledAttributes.getString(10);
                            c0034g.f1043p = string2 == null ? (char) 0 : string2.charAt(0);
                            c0034g.f1044q = typedArrayObtainStyledAttributes.getInt(20, 4096);
                            if (typedArrayObtainStyledAttributes.hasValue(11)) {
                                c0034g.f1045r = typedArrayObtainStyledAttributes.getBoolean(11, false) ? 1 : 0;
                            } else {
                                c0034g.f1045r = c0034g.f1033e;
                            }
                            c0034g.f1046s = typedArrayObtainStyledAttributes.getBoolean(3, false);
                            c0034g.f1047t = typedArrayObtainStyledAttributes.getBoolean(4, c0034g.f);
                            c0034g.f1048u = typedArrayObtainStyledAttributes.getBoolean(1, c0034g.f1034g);
                            c0034g.f1049v = typedArrayObtainStyledAttributes.getInt(21, -1);
                            c0034g.f1052y = typedArrayObtainStyledAttributes.getString(12);
                            c0034g.f1050w = typedArrayObtainStyledAttributes.getResourceId(13, 0);
                            c0034g.f1051x = typedArrayObtainStyledAttributes.getString(15);
                            String string3 = typedArrayObtainStyledAttributes.getString(14);
                            boolean z4 = string3 != null;
                            if (z4 && c0034g.f1050w == 0 && c0034g.f1051x == null) {
                                c0034g.f1053z = (q) c0034g.a(string3, f, c0035h.b);
                            } else {
                                if (z4) {
                                    Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                                }
                                c0034g.f1053z = null;
                            }
                            c0034g.f1025A = typedArrayObtainStyledAttributes.getText(17);
                            c0034g.f1026B = typedArrayObtainStyledAttributes.getText(22);
                            if (typedArrayObtainStyledAttributes.hasValue(19)) {
                                c0034g.f1028D = AbstractC0074n0.b(typedArrayObtainStyledAttributes.getInt(19, -1), c0034g.f1028D);
                            } else {
                                c0034g.f1028D = null;
                            }
                            if (typedArrayObtainStyledAttributes.hasValue(18)) {
                                if (!typedArrayObtainStyledAttributes.hasValue(18) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(18, 0)) == 0 || (colorStateList = D.g.t(context, resourceId)) == null) {
                                    colorStateList = typedArrayObtainStyledAttributes.getColorStateList(18);
                                }
                                c0034g.f1027C = colorStateList;
                            } else {
                                c0034g.f1027C = null;
                            }
                            typedArrayObtainStyledAttributes.recycle();
                            c0034g.f1035h = false;
                            xmlResourceParser2 = xmlResourceParser;
                            r8 = 1;
                        } else if (name3.equals("menu")) {
                            r8 = 1;
                            c0034g.f1035h = true;
                            SubMenu subMenuAddSubMenu = c0034g.f1030a.addSubMenu(c0034g.b, c0034g.f1036i, c0034g.f1037j, c0034g.f1038k);
                            c0034g.b(subMenuAddSubMenu.getItem());
                            xmlResourceParser2 = xmlResourceParser;
                            b(xmlResourceParser2, attributeSet, subMenuAddSubMenu);
                        } else {
                            xmlResourceParser2 = xmlResourceParser;
                            r8 = 1;
                            str = name3;
                            z3 = true;
                        }
                        eventType = xmlResourceParser2.next();
                        r4 = r8;
                        i2 = 2;
                        z2 = z2;
                        z3 = z3;
                    }
                }
                xmlResourceParser2 = xmlResourceParser;
                r8 = r4;
                z2 = z2;
            }
            eventType = xmlResourceParser2.next();
            r4 = r8;
            i2 = 2;
            z2 = z2;
            z3 = z3;
        }
    }

    @Override // android.view.MenuInflater
    public final void inflate(int i2, Menu menu) {
        if (!(menu instanceof n)) {
            super.inflate(i2, menu);
            return;
        }
        XmlResourceParser layout = null;
        boolean z2 = false;
        try {
            try {
                layout = this.f1056c.getResources().getLayout(i2);
                AttributeSet attributeSetAsAttributeSet = Xml.asAttributeSet(layout);
                if (menu instanceof n) {
                    n nVar = (n) menu;
                    if (!nVar.f1154p) {
                        nVar.w();
                        z2 = true;
                    }
                }
                b(layout, attributeSetAsAttributeSet, menu);
                if (z2) {
                    ((n) menu).v();
                }
                layout.close();
            } catch (IOException e2) {
                throw new InflateException("Error inflating menu XML", e2);
            } catch (XmlPullParserException e3) {
                throw new InflateException("Error inflating menu XML", e3);
            }
        } catch (Throwable th) {
            if (z2) {
                ((n) menu).v();
            }
            if (layout != null) {
                layout.close();
            }
            throw th;
        }
    }
}
