package G;

import android.text.InputFilter;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public final class h extends D.g {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final g f67o;

    public h(TextView textView) {
        this.f67o = new g(textView);
    }

    @Override // D.g
    public final void Y(boolean z2) {
        if (androidx.emoji2.text.k.f569k != null) {
            this.f67o.Y(z2);
        }
    }

    @Override // D.g
    public final void a0(boolean z2) {
        boolean z3 = androidx.emoji2.text.k.f569k != null;
        g gVar = this.f67o;
        if (z3) {
            gVar.a0(z2);
        } else {
            gVar.f66q = z2;
        }
    }

    @Override // D.g
    public final InputFilter[] y(InputFilter[] inputFilterArr) {
        return !(androidx.emoji2.text.k.f569k != null) ? inputFilterArr : this.f67o.y(inputFilterArr);
    }
}
