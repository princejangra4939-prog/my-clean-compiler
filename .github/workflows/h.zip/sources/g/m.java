package g;

import android.view.Window;

/* JADX INFO: loaded from: classes.dex */
public abstract class m {
    public static void a(Window.Callback callback, boolean z2) {
        callback.onPointerCaptureChanged(z2);
    }
}
