package g;

/* JADX INFO: renamed from: g.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0029b {
}
