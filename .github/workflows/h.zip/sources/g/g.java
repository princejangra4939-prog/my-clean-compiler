package G;

import android.text.InputFilter;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.SparseArray;
import android.widget.TextView;

/* JADX INFO: loaded from: classes.dex */
public final class g extends D.g {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final TextView f64o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final e f65p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f66q = true;

    public g(TextView textView) {
        this.f64o = textView;
        this.f65p = new e(textView);
    }

    @Override // D.g
    public final void Y(boolean z2) {
        if (z2) {
            k0();
        }
    }

    @Override // D.g
    public final void a0(boolean z2) {
        this.f66q = z2;
        k0();
        TextView textView = this.f64o;
        textView.setFilters(y(textView.getFilters()));
    }

    public final void k0() {
        TextView textView = this.f64o;
        TransformationMethod transformationMethod = textView.getTransformationMethod();
        if (this.f66q) {
            if (!(transformationMethod instanceof k) && !(transformationMethod instanceof PasswordTransformationMethod)) {
                transformationMethod = new k(transformationMethod);
            }
        } else if (transformationMethod instanceof k) {
            transformationMethod = ((k) transformationMethod).f71a;
        }
        textView.setTransformationMethod(transformationMethod);
    }

    @Override // D.g
    public final InputFilter[] y(InputFilter[] inputFilterArr) {
        if (!this.f66q) {
            SparseArray sparseArray = new SparseArray(1);
            for (int i2 = 0; i2 < inputFilterArr.length; i2++) {
                InputFilter inputFilter = inputFilterArr[i2];
                if (inputFilter instanceof e) {
                    sparseArray.put(i2, inputFilter);
                }
            }
            if (sparseArray.size() == 0) {
                return inputFilterArr;
            }
            int length = inputFilterArr.length;
            InputFilter[] inputFilterArr2 = new InputFilter[inputFilterArr.length - sparseArray.size()];
            int i3 = 0;
            for (int i4 = 0; i4 < length; i4++) {
                if (sparseArray.indexOfKey(i4) < 0) {
                    inputFilterArr2[i3] = inputFilterArr[i4];
                    i3++;
                }
            }
            return inputFilterArr2;
        }
        int length2 = inputFilterArr.length;
        int i5 = 0;
        while (true) {
            e eVar = this.f65p;
            if (i5 >= length2) {
                InputFilter[] inputFilterArr3 = new InputFilter[inputFilterArr.length + 1];
                System.arraycopy(inputFilterArr, 0, inputFilterArr3, 0, length2);
                inputFilterArr3[length2] = eVar;
                return inputFilterArr3;
            }
            if (inputFilterArr[i5] == eVar) {
                return inputFilterArr;
            }
            i5++;
        }
    }
}
