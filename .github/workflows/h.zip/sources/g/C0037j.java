package g;

import android.view.View;
import android.view.animation.BaseInterpolator;
import java.util.ArrayList;
import y.Q;

/* JADX INFO: renamed from: g.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0037j {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public BaseInterpolator f1062c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public z.i f1063d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f1064e;
    public long b = -1;
    public final C0036i f = new C0036i(this);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f1061a = new ArrayList();

    public final void a() {
        if (this.f1064e) {
            ArrayList arrayList = this.f1061a;
            int size = arrayList.size();
            int i2 = 0;
            while (i2 < size) {
                Object obj = arrayList.get(i2);
                i2++;
                ((Q) obj).b();
            }
            this.f1064e = false;
        }
    }

    public final void b() {
        View view;
        if (this.f1064e) {
            return;
        }
        ArrayList arrayList = this.f1061a;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            Q q2 = (Q) obj;
            long j2 = this.b;
            if (j2 >= 0) {
                q2.c(j2);
            }
            BaseInterpolator baseInterpolator = this.f1062c;
            if (baseInterpolator != null && (view = (View) q2.f1653a.get()) != null) {
                view.animate().setInterpolator(baseInterpolator);
            }
            if (this.f1063d != null) {
                q2.d(this.f);
            }
            View view2 = (View) q2.f1653a.get();
            if (view2 != null) {
                view2.animate().start();
            }
        }
        this.f1064e = true;
    }
}
