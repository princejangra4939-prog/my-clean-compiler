package g;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import h.p;
import h.q;
import h.u;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import t.InterfaceMenuItemC0131a;
import y.AbstractC0168l;

/* JADX INFO: renamed from: g.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0034g {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public CharSequence f1025A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public CharSequence f1026B;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final /* synthetic */ C0035h f1029E;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Menu f1030a;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1035h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f1036i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f1037j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public CharSequence f1038k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public CharSequence f1039l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f1040m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public char f1041n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f1042o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public char f1043p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f1044q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f1045r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f1046s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f1047t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f1048u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f1049v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f1050w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public String f1051x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public String f1052y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public q f1053z;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public ColorStateList f1027C = null;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public PorterDuff.Mode f1028D = null;
    public int b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1031c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f1032d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1033e = 0;
    public boolean f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1034g = true;

    public C0034g(C0035h c0035h, Menu menu) {
        this.f1029E = c0035h;
        this.f1030a = menu;
    }

    public final Object a(String str, Class[] clsArr, Object[] objArr) {
        try {
            Constructor<?> constructor = Class.forName(str, false, this.f1029E.f1056c.getClassLoader()).getConstructor(clsArr);
            constructor.setAccessible(true);
            return constructor.newInstance(objArr);
        } catch (Exception e2) {
            Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e2);
            return null;
        }
    }

    public final void b(MenuItem menuItem) {
        boolean z2 = false;
        menuItem.setChecked(this.f1046s).setVisible(this.f1047t).setEnabled(this.f1048u).setCheckable(this.f1045r >= 1).setTitleCondensed(this.f1039l).setIcon(this.f1040m);
        int i2 = this.f1049v;
        if (i2 >= 0) {
            menuItem.setShowAsAction(i2);
        }
        String str = this.f1052y;
        C0035h c0035h = this.f1029E;
        if (str != null) {
            if (c0035h.f1056c.isRestricted()) {
                throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
            }
            if (c0035h.f1057d == null) {
                c0035h.f1057d = C0035h.a(c0035h.f1056c);
            }
            Object obj = c0035h.f1057d;
            String str2 = this.f1052y;
            MenuItemOnMenuItemClickListenerC0033f menuItemOnMenuItemClickListenerC0033f = new MenuItemOnMenuItemClickListenerC0033f();
            menuItemOnMenuItemClickListenerC0033f.f1024a = obj;
            Class<?> cls = obj.getClass();
            try {
                menuItemOnMenuItemClickListenerC0033f.b = cls.getMethod(str2, MenuItemOnMenuItemClickListenerC0033f.f1023c);
                menuItem.setOnMenuItemClickListener(menuItemOnMenuItemClickListenerC0033f);
            } catch (Exception e2) {
                InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str2 + " in class " + cls.getName());
                inflateException.initCause(e2);
                throw inflateException;
            }
        }
        if (this.f1045r >= 2) {
            if (menuItem instanceof p) {
                p pVar = (p) menuItem;
                pVar.f1189x = (pVar.f1189x & (-5)) | 4;
            } else if (menuItem instanceof u) {
                u uVar = (u) menuItem;
                try {
                    Method method = uVar.f1198d;
                    InterfaceMenuItemC0131a interfaceMenuItemC0131a = uVar.f1197c;
                    if (method == null) {
                        uVar.f1198d = interfaceMenuItemC0131a.getClass().getDeclaredMethod("setExclusiveCheckable", Boolean.TYPE);
                    }
                    uVar.f1198d.invoke(interfaceMenuItemC0131a, Boolean.TRUE);
                } catch (Exception e3) {
                    Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e3);
                }
            }
        }
        String str3 = this.f1051x;
        if (str3 != null) {
            menuItem.setActionView((View) a(str3, C0035h.f1054e, c0035h.f1055a));
            z2 = true;
        }
        int i3 = this.f1050w;
        if (i3 > 0) {
            if (z2) {
                Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
            } else {
                menuItem.setActionView(i3);
            }
        }
        q qVar = this.f1053z;
        if (qVar != null) {
            if (menuItem instanceof InterfaceMenuItemC0131a) {
                ((InterfaceMenuItemC0131a) menuItem).b(qVar);
            } else {
                Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
            }
        }
        CharSequence charSequence = this.f1025A;
        boolean z3 = menuItem instanceof InterfaceMenuItemC0131a;
        if (z3) {
            ((InterfaceMenuItemC0131a) menuItem).setContentDescription(charSequence);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0168l.h(menuItem, charSequence);
        }
        CharSequence charSequence2 = this.f1026B;
        if (z3) {
            ((InterfaceMenuItemC0131a) menuItem).setTooltipText(charSequence2);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0168l.m(menuItem, charSequence2);
        }
        char c2 = this.f1041n;
        int i4 = this.f1042o;
        if (z3) {
            ((InterfaceMenuItemC0131a) menuItem).setAlphabeticShortcut(c2, i4);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0168l.g(menuItem, c2, i4);
        }
        char c3 = this.f1043p;
        int i5 = this.f1044q;
        if (z3) {
            ((InterfaceMenuItemC0131a) menuItem).setNumericShortcut(c3, i5);
        } else if (Build.VERSION.SDK_INT >= 26) {
            AbstractC0168l.k(menuItem, c3, i5);
        }
        PorterDuff.Mode mode = this.f1028D;
        if (mode != null) {
            if (z3) {
                ((InterfaceMenuItemC0131a) menuItem).setIconTintMode(mode);
            } else if (Build.VERSION.SDK_INT >= 26) {
                AbstractC0168l.j(menuItem, mode);
            }
        }
        ColorStateList colorStateList = this.f1027C;
        if (colorStateList != null) {
            if (z3) {
                ((InterfaceMenuItemC0131a) menuItem).setIconTintList(colorStateList);
            } else if (Build.VERSION.SDK_INT >= 26) {
                AbstractC0168l.i(menuItem, colorStateList);
            }
        }
    }
}
