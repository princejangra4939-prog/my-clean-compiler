package g;

import i.e1;

/* JADX INFO: renamed from: g.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0036i extends z.i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1058a;
    public boolean b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1059c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f1060d;

    public C0036i(C0037j c0037j) {
        this.f1058a = 0;
        this.f1060d = c0037j;
        this.b = false;
        this.f1059c = 0;
    }

    @Override // y.S
    public final void a() {
        switch (this.f1058a) {
            case 0:
                int i2 = this.f1059c + 1;
                this.f1059c = i2;
                C0037j c0037j = (C0037j) this.f1060d;
                if (i2 == c0037j.f1061a.size()) {
                    z.i iVar = c0037j.f1063d;
                    if (iVar != null) {
                        iVar.a();
                    }
                    this.f1059c = 0;
                    this.b = false;
                    c0037j.f1064e = false;
                }
                break;
            default:
                if (!this.b) {
                    ((e1) this.f1060d).f1339a.setVisibility(this.f1059c);
                }
                break;
        }
    }

    @Override // z.i, y.S
    public void b() {
        switch (this.f1058a) {
            case 1:
                this.b = true;
                break;
        }
    }

    @Override // z.i, y.S
    public final void c() {
        switch (this.f1058a) {
            case 0:
                if (!this.b) {
                    this.b = true;
                    z.i iVar = ((C0037j) this.f1060d).f1063d;
                    if (iVar != null) {
                        iVar.c();
                    }
                    break;
                }
                break;
            default:
                ((e1) this.f1060d).f1339a.setVisibility(0);
                break;
        }
    }

    public C0036i(e1 e1Var, int i2) {
        this.f1058a = 1;
        this.f1060d = e1Var;
        this.f1059c = i2;
        this.b = false;
    }
}
