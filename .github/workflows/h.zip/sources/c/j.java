package C;

import T.k;
import T.o;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.ContentInfo;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.emoji2.text.p;
import androidx.emoji2.text.w;
import androidx.profileinstaller.ProfileInstallReceiver;
import e.G;
import h.F;
import h.RunnableC0045f;
import h.l;
import h.n;
import h.y;
import i.C0069l;
import i.H0;
import i.InterfaceC0048a0;
import i.InterfaceC0075o;
import i.X0;
import i.b1;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;
import y.AbstractC0159c;
import y.C0163g;
import y.InterfaceC0160d;
import y.InterfaceC0162f;

/* JADX INFO: loaded from: classes.dex */
public class j implements L.f, P.j, o, androidx.emoji2.text.j, p, H0, y, l, InterfaceC0048a0, InterfaceC0160d, InterfaceC0162f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f8a;
    public Object b;

    public /* synthetic */ j(int i2) {
        this.f8a = i2;
    }

    @Override // y.InterfaceC0160d
    public void a(Bundle bundle) {
        ((ContentInfo.Builder) this.b).setExtras(bundle);
    }

    @Override // h.y
    public void b(n nVar, boolean z2) {
        if (nVar instanceof F) {
            ((F) nVar).f1084z.k().c(false);
        }
        y yVar = ((C0069l) this.b).f1390e;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    @Override // androidx.emoji2.text.p
    public boolean c(CharSequence charSequence, int i2, int i3, w wVar) {
        if (!TextUtils.equals(charSequence.subSequence(i2, i3), (String) this.b)) {
            return true;
        }
        wVar.f599c = (wVar.f599c & 3) | 4;
        return false;
    }

    @Override // y.InterfaceC0160d
    public void e(Uri uri) {
        ((ContentInfo.Builder) this.b).setLinkUri(uri);
    }

    @Override // y.InterfaceC0162f
    public int f() {
        return ((ContentInfo) this.b).getSource();
    }

    @Override // h.l
    public void g(n nVar) {
        l lVar = ((ActionMenuView) this.b).f452v;
        if (lVar != null) {
            lVar.g(nVar);
        }
    }

    @Override // h.l
    public boolean h(n nVar, MenuItem menuItem) {
        InterfaceC0075o interfaceC0075o = ((ActionMenuView) this.b).f445A;
        if (interfaceC0075o != null) {
            Toolbar toolbar = ((X0) interfaceC0075o).f1309a;
            toolbar.f475G.o();
            b1 b1Var = toolbar.f477I;
            if (b1Var != null ? ((G) b1Var).f897a.f900p.f998a.onMenuItemSelected(0, menuItem) : false) {
                return true;
            }
        }
        return false;
    }

    @Override // y.InterfaceC0162f
    public ClipData j() {
        return ((ContentInfo) this.b).getClip();
    }

    @Override // y.InterfaceC0160d
    public C0163g k() {
        return new C0163g(new j(((ContentInfo.Builder) this.b).build()));
    }

    @Override // L.f
    public void l(int i2, Serializable serializable) {
        String str;
        switch (i2) {
            case 1:
                str = "RESULT_INSTALL_SUCCESS";
                break;
            case 2:
                str = "RESULT_ALREADY_INSTALLED";
                break;
            case 3:
                str = "RESULT_UNSUPPORTED_ART_VERSION";
                break;
            case 4:
                str = "RESULT_NOT_WRITABLE";
                break;
            case 5:
                str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                break;
            case 6:
                str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                break;
            case 7:
                str = "RESULT_IO_EXCEPTION";
                break;
            case 8:
                str = "RESULT_PARSE_EXCEPTION";
                break;
            case 9:
            default:
                str = "";
                break;
            case 10:
                str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                break;
            case 11:
                str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                break;
        }
        if (i2 == 6 || i2 == 7 || i2 == 8) {
            Log.e("ProfileInstaller", str, (Throwable) serializable);
        } else {
            Log.d("ProfileInstaller", str);
        }
        ((ProfileInstallReceiver) this.b).setResultCode(i2);
    }

    @Override // h.y
    public boolean m(n nVar) {
        C0069l c0069l = (C0069l) this.b;
        if (nVar == c0069l.f1388c) {
            return false;
        }
        ((F) nVar).f1083A.getClass();
        c0069l.getClass();
        y yVar = c0069l.f1390e;
        if (yVar != null) {
            return yVar.m(nVar);
        }
        return false;
    }

    @Override // y.InterfaceC0162f
    public int n() {
        return ((ContentInfo) this.b).getFlags();
    }

    @Override // androidx.emoji2.text.j
    public void p(final D.g gVar) {
        final ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new androidx.emoji2.text.a("EmojiCompatInitializer"));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        threadPoolExecutor.execute(new Runnable() { // from class: androidx.emoji2.text.l
            @Override // java.lang.Runnable
            public final void run() {
                C.j jVar = this.f577a;
                D.g gVar2 = gVar;
                ThreadPoolExecutor threadPoolExecutor2 = threadPoolExecutor;
                jVar.getClass();
                try {
                    s sVarK = D.g.k((Context) jVar.b);
                    if (sVarK == null) {
                        throw new RuntimeException("EmojiCompat font provider not available on this device.");
                    }
                    r rVar = (r) sVarK.f592a;
                    synchronized (rVar.f587d) {
                        rVar.f = threadPoolExecutor2;
                    }
                    sVarK.f592a.p(new m(gVar2, threadPoolExecutor2));
                } catch (Throwable th) {
                    gVar2.M(th);
                    threadPoolExecutor2.shutdown();
                }
            }
        });
    }

    @Override // L.f
    public void q() {
        Log.d("ProfileInstaller", "DIAGNOSTIC_PROFILE_IS_COMPRESSED");
    }

    @Override // i.H0
    public void r(n nVar, h.p pVar) {
        h.h hVar = (h.h) this.b;
        hVar.f.removeCallbacksAndMessages(null);
        ArrayList arrayList = hVar.f1112h;
        int size = arrayList.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (nVar == ((h.g) arrayList.get(i2)).b) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 == -1) {
            return;
        }
        int i3 = i2 + 1;
        hVar.f.postAtTime(new RunnableC0045f(this, i3 < arrayList.size() ? (h.g) arrayList.get(i3) : null, pVar, nVar), nVar, SystemClock.uptimeMillis() + 200);
    }

    @Override // y.InterfaceC0162f
    public ContentInfo s() {
        return (ContentInfo) this.b;
    }

    @Override // i.H0
    public void t(n nVar, h.p pVar) {
        ((h.h) this.b).f.removeCallbacksAndMessages(nVar);
    }

    public String toString() {
        switch (this.f8a) {
            case 22:
                return "ContentInfoCompat{" + ((ContentInfo) this.b) + "}";
            default:
                return super.toString();
        }
    }

    @Override // T.o
    public void u(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            boolean zHas = jSONObject.has("ad_display");
            T.h hVar = (T.h) this.b;
            W.g gVar = (W.g) hVar.f186d;
            if (zHas && !jSONObject.isNull("ad_display")) {
                gVar.f275m = jSONObject.getString("ad_display");
            }
            if (gVar.f275m.equals("true")) {
                if (jSONObject.has("ad_mode") && !jSONObject.isNull("ad_mode")) {
                    gVar.f273k = jSONObject.getString("ad_mode");
                }
                if (jSONObject.has("ad_url") && !jSONObject.isNull("ad_url")) {
                    gVar.f274l = jSONObject.getString("ad_url");
                }
                if (jSONObject.has("request_id") && !jSONObject.isNull("request_id")) {
                    gVar.f280r = jSONObject.getString("request_id");
                }
                if (gVar.f273k.equals("banner")) {
                    W.d dVar = (W.d) hVar.f185c;
                    if (dVar != null) {
                        ((ViewGroup) dVar.f260e).removeView((View) dVar.f);
                        hVar.f185c = null;
                    }
                    W.d dVar2 = new W.d(gVar.b);
                    hVar.f185c = dVar2;
                    dVar2.f258c = new j(7, this);
                    dVar2.a(gVar.f274l, gVar.f280r);
                }
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
    }

    @Override // y.InterfaceC0160d
    public void w(int i2) {
        ((ContentInfo.Builder) this.b).setFlags(i2);
    }

    public void x() {
        androidx.fragment.app.p pVar = ((androidx.fragment.app.f) this.b).f635c;
        if (pVar.f671r == null) {
            return;
        }
        pVar.f678y = false;
        pVar.f679z = false;
        pVar.f654E.getClass();
        Iterator it = pVar.f657c.d().iterator();
        while (it.hasNext()) {
            if (it.next() != null) {
                throw new ClassCastException();
            }
        }
    }

    public void y(U.h hVar, k kVar, T.c cVar) {
        synchronized (hVar.f233e) {
            hVar.f237j = true;
        }
        hVar.a("post-response");
        ((T.g) this.b).execute(new T.h(hVar, kVar, cVar));
    }

    public /* synthetic */ j(int i2, Object obj) {
        this.f8a = i2;
        this.b = obj;
    }

    public j(Handler handler) {
        this.f8a = 5;
        this.b = new T.g(handler);
    }

    public j(TextView textView) {
        this.f8a = 3;
        this.b = new G.h(textView);
    }

    public j(EditText editText) {
        this.f8a = 2;
        this.b = new G.a(editText);
    }

    public j(Context context) {
        this.f8a = 10;
        this.b = context.getApplicationContext();
    }

    public j(Uri uri, ClipDescription clipDescription, Uri uri2) {
        this.f8a = 0;
        if (Build.VERSION.SDK_INT >= 25) {
            this.b = new g(uri, clipDescription, uri2);
        } else {
            this.b = new h(uri, clipDescription, uri2);
        }
    }

    public j(ContentInfo contentInfo) {
        this.f8a = 22;
        contentInfo.getClass();
        this.b = AbstractC0159c.e(contentInfo);
    }

    public j(ClipData clipData, int i2) {
        this.f8a = 21;
        this.b = AbstractC0159c.c(clipData, i2);
    }

    @Override // i.InterfaceC0048a0
    public void d(int i2) {
    }

    @Override // i.InterfaceC0048a0
    public void v(int i2) {
    }

    @Override // androidx.emoji2.text.p
    public Object i() {
        return this;
    }

    @Override // i.InterfaceC0048a0
    public void o(int i2, float f) {
    }
}
