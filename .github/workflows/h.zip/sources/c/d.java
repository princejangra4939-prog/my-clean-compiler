package C;

import android.content.ClipData;
import android.content.ClipDescription;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import i.C0092x;
import y.C0161e;
import y.InterfaceC0160d;
import y.K;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0092x f1a;

    public /* synthetic */ d(C0092x c0092x) {
        this.f1a = c0092x;
    }

    public final boolean a(j jVar, int i2, Bundle bundle) {
        InterfaceC0160d jVar2;
        int i3 = Build.VERSION.SDK_INT;
        if (i3 >= 25 && (i2 & 1) != 0) {
            try {
                ((i) jVar.b).b();
                Parcelable parcelable = (Parcelable) ((i) jVar.b).d();
                bundle = bundle == null ? new Bundle() : new Bundle(bundle);
                bundle.putParcelable("androidx.core.view.extra.INPUT_CONTENT_INFO", parcelable);
            } catch (Exception e2) {
                Log.w("InputConnectionCompat", "Can't insert content from IME; requestPermission() failed", e2);
                return false;
            }
        }
        ClipDescription clipDescriptionA = ((i) jVar.b).a();
        i iVar = (i) jVar.b;
        ClipData clipData = new ClipData(clipDescriptionA, new ClipData.Item(iVar.e()));
        if (i3 >= 31) {
            jVar2 = new j(clipData, 2);
        } else {
            C0161e c0161e = new C0161e();
            c0161e.b = clipData;
            c0161e.f1681c = 2;
            jVar2 = c0161e;
        }
        jVar2.e(iVar.c());
        jVar2.a(bundle);
        return K.f(this.f1a, jVar2.k()) == null;
    }
}
