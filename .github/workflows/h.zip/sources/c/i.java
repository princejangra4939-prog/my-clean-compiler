package C;

import android.content.ClipDescription;
import android.net.Uri;

/* JADX INFO: loaded from: classes.dex */
public interface i {
    ClipDescription a();

    void b();

    Uri c();

    Object d();

    Uri e();
}
