package i0;

/* JADX INFO: loaded from: classes.dex */
public abstract class g extends f {
    public static String k0(String str) {
        e0.c.e(str, "<this>");
        e0.c.e(str, "missingDelimiterValue");
        int iLastIndexOf = str.lastIndexOf(46, str.length() - 1);
        if (iLastIndexOf == -1) {
            return str;
        }
        String strSubstring = str.substring(iLastIndexOf + 1, str.length());
        e0.c.d(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }
}
