package i0;

/* JADX INFO: loaded from: classes.dex */
public abstract class e extends d {
}
