package h;

import android.view.MenuItem;

/* JADX INFO: loaded from: classes.dex */
public final class s implements MenuItem.OnActionExpandListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MenuItem.OnActionExpandListener f1195a;
    public final /* synthetic */ u b;

    public s(u uVar, MenuItem.OnActionExpandListener onActionExpandListener) {
        this.b = uVar;
        this.f1195a = onActionExpandListener;
    }

    @Override // android.view.MenuItem.OnActionExpandListener
    public final boolean onMenuItemActionCollapse(MenuItem menuItem) {
        return this.f1195a.onMenuItemActionCollapse(this.b.f(menuItem));
    }

    @Override // android.view.MenuItem.OnActionExpandListener
    public final boolean onMenuItemActionExpand(MenuItem menuItem) {
        return this.f1195a.onMenuItemActionExpand(this.b.f(menuItem));
    }
}
