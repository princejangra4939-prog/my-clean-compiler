package h;

import android.R;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import p.AbstractC0122a;
import s.AbstractC0128a;
import t.InterfaceMenuItemC0131a;

/* JADX INFO: renamed from: h.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0040a implements InterfaceMenuItemC0131a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public CharSequence f1085a;
    public CharSequence b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Intent f1086c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public char f1087d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1088e;
    public char f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1089g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public Drawable f1090h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public Context f1091i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public CharSequence f1092j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public CharSequence f1093k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public ColorStateList f1094l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public PorterDuff.Mode f1095m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f1096n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f1097o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f1098p;

    @Override // t.InterfaceMenuItemC0131a
    public final q a() {
        return null;
    }

    @Override // t.InterfaceMenuItemC0131a
    public final InterfaceMenuItemC0131a b(q qVar) {
        throw new UnsupportedOperationException();
    }

    public final void c() {
        Drawable drawable = this.f1090h;
        if (drawable != null) {
            if (this.f1096n || this.f1097o) {
                this.f1090h = drawable;
                Drawable drawableMutate = drawable.mutate();
                this.f1090h = drawableMutate;
                if (this.f1096n) {
                    AbstractC0128a.h(drawableMutate, this.f1094l);
                }
                if (this.f1097o) {
                    AbstractC0128a.i(this.f1090h, this.f1095m);
                }
            }
        }
    }

    @Override // android.view.MenuItem
    public final boolean collapseActionView() {
        return false;
    }

    @Override // android.view.MenuItem
    public final boolean expandActionView() {
        return false;
    }

    @Override // android.view.MenuItem
    public final ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public final View getActionView() {
        return null;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final int getAlphabeticModifiers() {
        return this.f1089g;
    }

    @Override // android.view.MenuItem
    public final char getAlphabeticShortcut() {
        return this.f;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final CharSequence getContentDescription() {
        return this.f1092j;
    }

    @Override // android.view.MenuItem
    public final int getGroupId() {
        return 0;
    }

    @Override // android.view.MenuItem
    public final Drawable getIcon() {
        return this.f1090h;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final ColorStateList getIconTintList() {
        return this.f1094l;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final PorterDuff.Mode getIconTintMode() {
        return this.f1095m;
    }

    @Override // android.view.MenuItem
    public final Intent getIntent() {
        return this.f1086c;
    }

    @Override // android.view.MenuItem
    public final int getItemId() {
        return R.id.home;
    }

    @Override // android.view.MenuItem
    public final ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final int getNumericModifiers() {
        return this.f1088e;
    }

    @Override // android.view.MenuItem
    public final char getNumericShortcut() {
        return this.f1087d;
    }

    @Override // android.view.MenuItem
    public final int getOrder() {
        return 0;
    }

    @Override // android.view.MenuItem
    public final SubMenu getSubMenu() {
        return null;
    }

    @Override // android.view.MenuItem
    public final CharSequence getTitle() {
        return this.f1085a;
    }

    @Override // android.view.MenuItem
    public final CharSequence getTitleCondensed() {
        CharSequence charSequence = this.b;
        return charSequence != null ? charSequence : this.f1085a;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final CharSequence getTooltipText() {
        return this.f1093k;
    }

    @Override // android.view.MenuItem
    public final boolean hasSubMenu() {
        return false;
    }

    @Override // android.view.MenuItem
    public final boolean isActionViewExpanded() {
        return false;
    }

    @Override // android.view.MenuItem
    public final boolean isCheckable() {
        return (this.f1098p & 1) != 0;
    }

    @Override // android.view.MenuItem
    public final boolean isChecked() {
        return (this.f1098p & 2) != 0;
    }

    @Override // android.view.MenuItem
    public final boolean isEnabled() {
        return (this.f1098p & 16) != 0;
    }

    @Override // android.view.MenuItem
    public final boolean isVisible() {
        return (this.f1098p & 8) == 0;
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionView(View view) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public final MenuItem setAlphabeticShortcut(char c2) {
        this.f = Character.toLowerCase(c2);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setCheckable(boolean z2) {
        this.f1098p = (z2 ? 1 : 0) | (this.f1098p & (-2));
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setChecked(boolean z2) {
        this.f1098p = (z2 ? 2 : 0) | (this.f1098p & (-3));
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setContentDescription(CharSequence charSequence) {
        this.f1092j = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setEnabled(boolean z2) {
        this.f1098p = (z2 ? 16 : 0) | (this.f1098p & (-17));
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIcon(Drawable drawable) {
        this.f1090h = drawable;
        c();
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f1094l = colorStateList;
        this.f1096n = true;
        c();
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f1095m = mode;
        this.f1097o = true;
        c();
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIntent(Intent intent) {
        this.f1086c = intent;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setNumericShortcut(char c2) {
        this.f1087d = c2;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    @Override // android.view.MenuItem
    public final MenuItem setShortcut(char c2, char c3) {
        this.f1087d = c2;
        this.f = Character.toLowerCase(c3);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitle(CharSequence charSequence) {
        this.f1085a = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitleCondensed(CharSequence charSequence) {
        this.b = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTooltipText(CharSequence charSequence) {
        this.f1093k = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setVisible(boolean z2) {
        this.f1098p = (this.f1098p & 8) | (z2 ? 0 : 8);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionView(int i2) {
        throw new UnsupportedOperationException();
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setAlphabeticShortcut(char c2, int i2) {
        this.f = Character.toLowerCase(c2);
        this.f1089g = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final InterfaceMenuItemC0131a setContentDescription(CharSequence charSequence) {
        this.f1092j = charSequence;
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setNumericShortcut(char c2, int i2) {
        this.f1087d = c2;
        this.f1088e = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitle(int i2) {
        this.f1085a = this.f1091i.getResources().getString(i2);
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final InterfaceMenuItemC0131a setTooltipText(CharSequence charSequence) {
        this.f1093k = charSequence;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIcon(int i2) {
        this.f1090h = AbstractC0122a.b(this.f1091i, i2);
        c();
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f1087d = c2;
        this.f1088e = KeyEvent.normalizeMetaState(i2);
        this.f = Character.toLowerCase(c3);
        this.f1089g = KeyEvent.normalizeMetaState(i3);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        return this;
    }

    @Override // android.view.MenuItem
    public final void setShowAsAction(int i2) {
    }

    @Override // android.view.MenuItem
    public final MenuItem setShowAsActionFlags(int i2) {
        return this;
    }
}
