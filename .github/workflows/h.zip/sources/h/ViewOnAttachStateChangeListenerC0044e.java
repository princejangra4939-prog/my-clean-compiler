package h;

import android.view.View;
import android.view.ViewTreeObserver;

/* JADX INFO: renamed from: h.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ViewOnAttachStateChangeListenerC0044e implements View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1102a;
    public final /* synthetic */ v b;

    public /* synthetic */ ViewOnAttachStateChangeListenerC0044e(v vVar, int i2) {
        this.f1102a = i2;
        this.b = vVar;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        int i2 = this.f1102a;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        switch (this.f1102a) {
            case 0:
                h hVar = (h) this.b;
                ViewTreeObserver viewTreeObserver = hVar.f1128x;
                if (viewTreeObserver != null) {
                    if (!viewTreeObserver.isAlive()) {
                        hVar.f1128x = view.getViewTreeObserver();
                    }
                    hVar.f1128x.removeGlobalOnLayoutListener(hVar.f1113i);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
            default:
                E e2 = (E) this.b;
                ViewTreeObserver viewTreeObserver2 = e2.f1077o;
                if (viewTreeObserver2 != null) {
                    if (!viewTreeObserver2.isAlive()) {
                        e2.f1077o = view.getViewTreeObserver();
                    }
                    e2.f1077o.removeGlobalOnLayoutListener(e2.f1071i);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
        }
    }

    private final void a(View view) {
    }

    private final void b(View view) {
    }
}
