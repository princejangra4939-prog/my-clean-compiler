package h;

/* JADX INFO: renamed from: h.A, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0039A {
    void c(p pVar);

    p getItemData();
}
