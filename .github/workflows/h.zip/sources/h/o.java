package h;

import android.content.DialogInterface;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import e.DialogC0020g;

/* JADX INFO: loaded from: classes.dex */
public final class o implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public F f1163a;
    public DialogC0020g b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public j f1164c;

    @Override // h.y
    public final void b(n nVar, boolean z2) {
        DialogC0020g dialogC0020g;
        if ((z2 || nVar == this.f1163a) && (dialogC0020g = this.b) != null) {
            dialogC0020g.dismiss();
        }
    }

    @Override // h.y
    public final boolean m(n nVar) {
        return false;
    }

    @Override // android.content.DialogInterface.OnClickListener
    public final void onClick(DialogInterface dialogInterface, int i2) {
        j jVar = this.f1164c;
        if (jVar.f == null) {
            jVar.f = new i(jVar);
        }
        this.f1163a.q(jVar.f.getItem(i2), null, 0);
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        this.f1164c.b(this.f1163a, true);
    }

    @Override // android.content.DialogInterface.OnKeyListener
    public final boolean onKey(DialogInterface dialogInterface, int i2, KeyEvent keyEvent) {
        Window window;
        View decorView;
        KeyEvent.DispatcherState keyDispatcherState;
        View decorView2;
        KeyEvent.DispatcherState keyDispatcherState2;
        F f = this.f1163a;
        if (i2 == 82 || i2 == 4) {
            if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                Window window2 = this.b.getWindow();
                if (window2 != null && (decorView2 = window2.getDecorView()) != null && (keyDispatcherState2 = decorView2.getKeyDispatcherState()) != null) {
                    keyDispatcherState2.startTracking(keyEvent, this);
                    return true;
                }
            } else if (keyEvent.getAction() == 1 && !keyEvent.isCanceled() && (window = this.b.getWindow()) != null && (decorView = window.getDecorView()) != null && (keyDispatcherState = decorView.getKeyDispatcherState()) != null && keyDispatcherState.isTracking(keyEvent)) {
                f.c(true);
                dialogInterface.dismiss();
                return true;
            }
        }
        return f.performShortcut(i2, keyEvent, 0);
    }
}
