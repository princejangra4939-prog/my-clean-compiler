package h;

import android.widget.PopupWindow;

/* JADX INFO: loaded from: classes.dex */
public final class w implements PopupWindow.OnDismissListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ x f1200a;

    public w(x xVar) {
        this.f1200a = xVar;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public final void onDismiss() {
        this.f1200a.c();
    }
}
