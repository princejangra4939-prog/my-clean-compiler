package h;

import i.C0085t0;

/* JADX INFO: loaded from: classes.dex */
public interface D {
    boolean a();

    void dismiss();

    C0085t0 f();

    void h();
}
