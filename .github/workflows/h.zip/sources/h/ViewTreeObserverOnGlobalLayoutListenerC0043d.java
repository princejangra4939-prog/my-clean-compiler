package h;

import android.view.View;
import android.view.ViewTreeObserver;
import i.L0;
import i.O;
import i.S;
import java.util.ArrayList;

/* JADX INFO: renamed from: h.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class ViewTreeObserverOnGlobalLayoutListenerC0043d implements ViewTreeObserver.OnGlobalLayoutListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f1101a;
    public final /* synthetic */ Object b;

    public /* synthetic */ ViewTreeObserverOnGlobalLayoutListenerC0043d(int i2, Object obj) {
        this.f1101a = i2;
        this.b = obj;
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public final void onGlobalLayout() {
        switch (this.f1101a) {
            case 0:
                h hVar = (h) this.b;
                if (hVar.a()) {
                    ArrayList arrayList = hVar.f1112h;
                    if (arrayList.size() > 0) {
                        int i2 = 0;
                        if (!((g) arrayList.get(0)).f1106a.f1250x) {
                            View view = hVar.f1119o;
                            if (view != null && view.isShown()) {
                                int size = arrayList.size();
                                while (i2 < size) {
                                    Object obj = arrayList.get(i2);
                                    i2++;
                                    ((g) obj).f1106a.h();
                                }
                            } else {
                                hVar.dismiss();
                            }
                        }
                    }
                }
                break;
            case 1:
                E e2 = (E) this.b;
                if (e2.a()) {
                    L0 l0 = e2.f1070h;
                    if (!l0.f1250x) {
                        View view2 = e2.f1075m;
                        if (view2 != null && view2.isShown()) {
                            l0.h();
                        } else {
                            e2.dismiss();
                        }
                    }
                }
                break;
            case 2:
                S s2 = (S) this.b;
                if (!s2.getInternalPopup().a()) {
                    s2.f.e(s2.getTextDirection(), s2.getTextAlignment());
                }
                ViewTreeObserver viewTreeObserver = s2.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeOnGlobalLayoutListener(this);
                }
                break;
            default:
                O o2 = (O) this.b;
                S s3 = o2.f1279F;
                o2.getClass();
                if (s3.isAttachedToWindow() && s3.getGlobalVisibleRect(o2.f1277D)) {
                    o2.q();
                    o2.h();
                } else {
                    o2.dismiss();
                }
                break;
        }
    }
}
