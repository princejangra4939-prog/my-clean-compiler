package h;

/* JADX INFO: loaded from: classes.dex */
public interface y {
    void b(n nVar, boolean z2);

    boolean m(n nVar);
}
