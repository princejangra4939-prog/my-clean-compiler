package h;

/* JADX INFO: renamed from: h.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class RunnableC0045f implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ g f1103a;
    public final /* synthetic */ p b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ n f1104c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ C.j f1105d;

    public RunnableC0045f(C.j jVar, g gVar, p pVar, n nVar) {
        this.f1105d = jVar;
        this.f1103a = gVar;
        this.b = pVar;
        this.f1104c = nVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        g gVar = this.f1103a;
        if (gVar != null) {
            C.j jVar = this.f1105d;
            ((h) jVar.b).f1130z = true;
            gVar.b.c(false);
            ((h) jVar.b).f1130z = false;
        }
        p pVar = this.b;
        if (pVar.isEnabled() && pVar.hasSubMenu()) {
            this.f1104c.q(pVar, null, 4);
        }
    }
}
