package h;

import i.L0;

/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final L0 f1106a;
    public final n b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1107c;

    public g(L0 l0, n nVar, int i2) {
        this.f1106a = l0;
        this.b = nVar;
        this.f1107c = i2;
    }
}
