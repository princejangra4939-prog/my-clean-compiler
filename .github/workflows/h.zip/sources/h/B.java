package h;

/* JADX INFO: loaded from: classes.dex */
public interface B {
    void a(n nVar);
}
