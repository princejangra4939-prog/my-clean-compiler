package h;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.warppaiwarden.tictactoe.R;
import i.C0085t0;
import i.L0;

/* JADX INFO: loaded from: classes.dex */
public final class E extends v implements PopupWindow.OnDismissListener, View.OnKeyListener {
    public final Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final n f1066c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final k f1067d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f1068e;
    public final int f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f1069g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final L0 f1070h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ViewTreeObserverOnGlobalLayoutListenerC0043d f1071i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final ViewOnAttachStateChangeListenerC0044e f1072j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public w f1073k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public View f1074l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public View f1075m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public y f1076n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public ViewTreeObserver f1077o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public boolean f1078p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f1079q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f1080r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1081s = 0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f1082t;

    public E(int i2, Context context, View view, n nVar, boolean z2) {
        int i3 = 1;
        this.f1071i = new ViewTreeObserverOnGlobalLayoutListenerC0043d(i3, this);
        this.f1072j = new ViewOnAttachStateChangeListenerC0044e(this, i3);
        this.b = context;
        this.f1066c = nVar;
        this.f1068e = z2;
        this.f1067d = new k(nVar, LayoutInflater.from(context), z2, R.layout.abc_popup_menu_item_layout);
        this.f1069g = i2;
        Resources resources = context.getResources();
        this.f = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
        this.f1074l = view;
        this.f1070h = new L0(context, null, i2);
        nVar.b(this, context);
    }

    @Override // h.D
    public final boolean a() {
        return !this.f1078p && this.f1070h.f1251y.isShowing();
    }

    @Override // h.z
    public final void b(n nVar, boolean z2) {
        if (nVar != this.f1066c) {
            return;
        }
        dismiss();
        y yVar = this.f1076n;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    @Override // h.z
    public final void c() {
        this.f1079q = false;
        k kVar = this.f1067d;
        if (kVar != null) {
            kVar.notifyDataSetChanged();
        }
    }

    @Override // h.D
    public final void dismiss() {
        if (a()) {
            this.f1070h.dismiss();
        }
    }

    @Override // h.z
    public final void e(y yVar) {
        this.f1076n = yVar;
    }

    @Override // h.D
    public final C0085t0 f() {
        return this.f1070h.f1230c;
    }

    @Override // h.D
    public final void h() {
        View view;
        if (a()) {
            return;
        }
        if (this.f1078p || (view = this.f1074l) == null) {
            throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
        }
        this.f1075m = view;
        L0 l0 = this.f1070h;
        l0.f1251y.setOnDismissListener(this);
        l0.f1242p = this;
        l0.f1250x = true;
        l0.f1251y.setFocusable(true);
        View view2 = this.f1075m;
        boolean z2 = this.f1077o == null;
        ViewTreeObserver viewTreeObserver = view2.getViewTreeObserver();
        this.f1077o = viewTreeObserver;
        if (z2) {
            viewTreeObserver.addOnGlobalLayoutListener(this.f1071i);
        }
        view2.addOnAttachStateChangeListener(this.f1072j);
        l0.f1241o = view2;
        l0.f1238l = this.f1081s;
        boolean z3 = this.f1079q;
        Context context = this.b;
        k kVar = this.f1067d;
        if (!z3) {
            this.f1080r = v.m(kVar, context, this.f);
            this.f1079q = true;
        }
        l0.p(this.f1080r);
        l0.f1251y.setInputMethodMode(2);
        Rect rect = this.f1199a;
        l0.f1249w = rect != null ? new Rect(rect) : null;
        l0.h();
        C0085t0 c0085t0 = l0.f1230c;
        c0085t0.setOnKeyListener(this);
        if (this.f1082t) {
            n nVar = this.f1066c;
            if (nVar.f1151m != null) {
                FrameLayout frameLayout = (FrameLayout) LayoutInflater.from(context).inflate(R.layout.abc_popup_menu_header_item_layout, (ViewGroup) c0085t0, false);
                TextView textView = (TextView) frameLayout.findViewById(android.R.id.title);
                if (textView != null) {
                    textView.setText(nVar.f1151m);
                }
                frameLayout.setEnabled(false);
                c0085t0.addHeaderView(frameLayout, null, false);
            }
        }
        l0.m(kVar);
        l0.h();
    }

    @Override // h.z
    public final boolean i() {
        return false;
    }

    @Override // h.z
    public final boolean j(F f) {
        if (f.hasVisibleItems()) {
            View view = this.f1075m;
            x xVar = new x(this.f1069g, this.b, view, f, this.f1068e);
            y yVar = this.f1076n;
            xVar.f1206h = yVar;
            v vVar = xVar.f1207i;
            if (vVar != null) {
                vVar.e(yVar);
            }
            boolean zU = v.u(f);
            xVar.f1205g = zU;
            v vVar2 = xVar.f1207i;
            if (vVar2 != null) {
                vVar2.o(zU);
            }
            xVar.f1208j = this.f1073k;
            this.f1073k = null;
            this.f1066c.c(false);
            L0 l0 = this.f1070h;
            int width = l0.f;
            int i2 = l0.i();
            if ((Gravity.getAbsoluteGravity(this.f1081s, this.f1074l.getLayoutDirection()) & 7) == 5) {
                width += this.f1074l.getWidth();
            }
            if (!xVar.b()) {
                if (xVar.f1204e != null) {
                    xVar.d(width, i2, true, true);
                }
            }
            y yVar2 = this.f1076n;
            if (yVar2 != null) {
                yVar2.m(f);
            }
            return true;
        }
        return false;
    }

    @Override // h.v
    public final void n(View view) {
        this.f1074l = view;
    }

    @Override // h.v
    public final void o(boolean z2) {
        this.f1067d.f1137c = z2;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public final void onDismiss() {
        this.f1078p = true;
        this.f1066c.c(true);
        ViewTreeObserver viewTreeObserver = this.f1077o;
        if (viewTreeObserver != null) {
            if (!viewTreeObserver.isAlive()) {
                this.f1077o = this.f1075m.getViewTreeObserver();
            }
            this.f1077o.removeGlobalOnLayoutListener(this.f1071i);
            this.f1077o = null;
        }
        this.f1075m.removeOnAttachStateChangeListener(this.f1072j);
        w wVar = this.f1073k;
        if (wVar != null) {
            wVar.onDismiss();
        }
    }

    @Override // android.view.View.OnKeyListener
    public final boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // h.v
    public final void p(int i2) {
        this.f1081s = i2;
    }

    @Override // h.v
    public final void q(int i2) {
        this.f1070h.f = i2;
    }

    @Override // h.v
    public final void r(PopupWindow.OnDismissListener onDismissListener) {
        this.f1073k = (w) onDismissListener;
    }

    @Override // h.v
    public final void s(boolean z2) {
        this.f1082t = z2;
    }

    @Override // h.v
    public final void t(int i2) {
        this.f1070h.k(i2);
    }

    @Override // h.v
    public final void l(n nVar) {
    }
}
