package h;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import com.warppaiwarden.tictactoe.R;
import i.C0085t0;
import i.I0;
import i.L0;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class h extends v implements View.OnKeyListener, PopupWindow.OnDismissListener {
    public final Context b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1108c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1109d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f1110e;
    public final Handler f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ViewTreeObserverOnGlobalLayoutListenerC0043d f1113i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final ViewOnAttachStateChangeListenerC0044e f1114j;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public View f1118n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public View f1119o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f1120p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f1121q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f1122r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1123s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f1124t;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f1126v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public y f1127w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public ViewTreeObserver f1128x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public w f1129y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f1130z;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ArrayList f1111g = new ArrayList();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ArrayList f1112h = new ArrayList();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final C.j f1115k = new C.j(15, this);

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f1116l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f1117m = 0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f1125u = false;

    public h(Context context, View view, int i2, boolean z2) {
        int i3 = 0;
        this.f1113i = new ViewTreeObserverOnGlobalLayoutListenerC0043d(i3, this);
        this.f1114j = new ViewOnAttachStateChangeListenerC0044e(this, i3);
        this.b = context;
        this.f1118n = view;
        this.f1109d = i2;
        this.f1110e = z2;
        this.f1120p = view.getLayoutDirection() != 1 ? 1 : 0;
        Resources resources = context.getResources();
        this.f1108c = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
        this.f = new Handler();
    }

    @Override // h.D
    public final boolean a() {
        ArrayList arrayList = this.f1112h;
        return arrayList.size() > 0 && ((g) arrayList.get(0)).f1106a.f1251y.isShowing();
    }

    @Override // h.z
    public final void b(n nVar, boolean z2) {
        ArrayList arrayList = this.f1112h;
        int size = arrayList.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (nVar == ((g) arrayList.get(i2)).b) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 < 0) {
            return;
        }
        int i3 = i2 + 1;
        if (i3 < arrayList.size()) {
            ((g) arrayList.get(i3)).b.c(false);
        }
        g gVar = (g) arrayList.remove(i2);
        gVar.b.r(this);
        boolean z3 = this.f1130z;
        L0 l0 = gVar.f1106a;
        if (z3) {
            I0.b(l0.f1251y, null);
            l0.f1251y.setAnimationStyle(0);
        }
        l0.dismiss();
        int size2 = arrayList.size();
        if (size2 > 0) {
            this.f1120p = ((g) arrayList.get(size2 - 1)).f1107c;
        } else {
            this.f1120p = this.f1118n.getLayoutDirection() == 1 ? 0 : 1;
        }
        if (size2 != 0) {
            if (z2) {
                ((g) arrayList.get(0)).b.c(false);
                return;
            }
            return;
        }
        dismiss();
        y yVar = this.f1127w;
        if (yVar != null) {
            yVar.b(nVar, true);
        }
        ViewTreeObserver viewTreeObserver = this.f1128x;
        if (viewTreeObserver != null) {
            if (viewTreeObserver.isAlive()) {
                this.f1128x.removeGlobalOnLayoutListener(this.f1113i);
            }
            this.f1128x = null;
        }
        this.f1119o.removeOnAttachStateChangeListener(this.f1114j);
        this.f1129y.onDismiss();
    }

    @Override // h.z
    public final void c() {
        ArrayList arrayList = this.f1112h;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            ListAdapter adapter = ((g) obj).f1106a.f1230c.getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }
            ((k) adapter).notifyDataSetChanged();
        }
    }

    @Override // h.D
    public final void dismiss() {
        ArrayList arrayList = this.f1112h;
        int size = arrayList.size();
        if (size > 0) {
            g[] gVarArr = (g[]) arrayList.toArray(new g[size]);
            for (int i2 = size - 1; i2 >= 0; i2--) {
                g gVar = gVarArr[i2];
                if (gVar.f1106a.f1251y.isShowing()) {
                    gVar.f1106a.dismiss();
                }
            }
        }
    }

    @Override // h.z
    public final void e(y yVar) {
        this.f1127w = yVar;
    }

    @Override // h.D
    public final C0085t0 f() {
        ArrayList arrayList = this.f1112h;
        if (arrayList.isEmpty()) {
            return null;
        }
        return ((g) arrayList.get(arrayList.size() - 1)).f1106a.f1230c;
    }

    @Override // h.D
    public final void h() {
        if (a()) {
            return;
        }
        ArrayList arrayList = this.f1111g;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            v((n) obj);
        }
        arrayList.clear();
        View view = this.f1118n;
        this.f1119o = view;
        if (view != null) {
            boolean z2 = this.f1128x == null;
            ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
            this.f1128x = viewTreeObserver;
            if (z2) {
                viewTreeObserver.addOnGlobalLayoutListener(this.f1113i);
            }
            this.f1119o.addOnAttachStateChangeListener(this.f1114j);
        }
    }

    @Override // h.z
    public final boolean i() {
        return false;
    }

    @Override // h.z
    public final boolean j(F f) {
        ArrayList arrayList = this.f1112h;
        int size = arrayList.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj = arrayList.get(i2);
            i2++;
            g gVar = (g) obj;
            if (f == gVar.b) {
                gVar.f1106a.f1230c.requestFocus();
                return true;
            }
        }
        if (!f.hasVisibleItems()) {
            return false;
        }
        l(f);
        y yVar = this.f1127w;
        if (yVar != null) {
            yVar.m(f);
        }
        return true;
    }

    @Override // h.v
    public final void l(n nVar) {
        nVar.b(this, this.b);
        if (a()) {
            v(nVar);
        } else {
            this.f1111g.add(nVar);
        }
    }

    @Override // h.v
    public final void n(View view) {
        if (this.f1118n != view) {
            this.f1118n = view;
            this.f1117m = Gravity.getAbsoluteGravity(this.f1116l, view.getLayoutDirection());
        }
    }

    @Override // h.v
    public final void o(boolean z2) {
        this.f1125u = z2;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public final void onDismiss() {
        g gVar;
        ArrayList arrayList = this.f1112h;
        int size = arrayList.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                gVar = null;
                break;
            }
            gVar = (g) arrayList.get(i2);
            if (!gVar.f1106a.f1251y.isShowing()) {
                break;
            } else {
                i2++;
            }
        }
        if (gVar != null) {
            gVar.b.c(false);
        }
    }

    @Override // android.view.View.OnKeyListener
    public final boolean onKey(View view, int i2, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i2 != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // h.v
    public final void p(int i2) {
        if (this.f1116l != i2) {
            this.f1116l = i2;
            this.f1117m = Gravity.getAbsoluteGravity(i2, this.f1118n.getLayoutDirection());
        }
    }

    @Override // h.v
    public final void q(int i2) {
        this.f1121q = true;
        this.f1123s = i2;
    }

    @Override // h.v
    public final void r(PopupWindow.OnDismissListener onDismissListener) {
        this.f1129y = (w) onDismissListener;
    }

    @Override // h.v
    public final void s(boolean z2) {
        this.f1126v = z2;
    }

    @Override // h.v
    public final void t(int i2) {
        this.f1122r = true;
        this.f1124t = i2;
    }

    /* JADX WARN: Removed duplicated region for block: B:46:0x00ef  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0148  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x014b  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x01ba  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void v(h.n r18) {
        /*
            Method dump skipped, instruction units count: 534
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: h.h.v(h.n):void");
    }
}
