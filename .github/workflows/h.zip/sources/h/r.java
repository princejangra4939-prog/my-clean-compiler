package h;

import android.view.CollapsibleActionView;
import android.view.View;
import android.widget.FrameLayout;
import g.InterfaceC0029b;

/* JADX INFO: loaded from: classes.dex */
public final class r extends FrameLayout implements InterfaceC0029b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final CollapsibleActionView f1194a;

    /* JADX WARN: Multi-variable type inference failed */
    public r(View view) {
        super(view.getContext());
        this.f1194a = (CollapsibleActionView) view;
        addView(view);
    }
}
