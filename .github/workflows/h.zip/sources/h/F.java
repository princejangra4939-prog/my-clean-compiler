package h;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class F extends n implements SubMenu {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final p f1083A;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final n f1084z;

    public F(Context context, n nVar, p pVar) {
        super(context);
        this.f1084z = nVar;
        this.f1083A = pVar;
    }

    @Override // h.n
    public final boolean d(p pVar) {
        return this.f1084z.d(pVar);
    }

    @Override // h.n
    public final boolean e(n nVar, MenuItem menuItem) {
        return super.e(nVar, menuItem) || this.f1084z.e(nVar, menuItem);
    }

    @Override // h.n
    public final boolean f(p pVar) {
        return this.f1084z.f(pVar);
    }

    @Override // android.view.SubMenu
    public final MenuItem getItem() {
        return this.f1083A;
    }

    @Override // h.n
    public final String j() {
        p pVar = this.f1083A;
        int i2 = pVar != null ? pVar.f1168a : 0;
        if (i2 == 0) {
            return null;
        }
        return "android:menu:actionviewstates:" + i2;
    }

    @Override // h.n
    public final n k() {
        return this.f1084z.k();
    }

    @Override // h.n
    public final boolean m() {
        return this.f1084z.m();
    }

    @Override // h.n
    public final boolean n() {
        return this.f1084z.n();
    }

    @Override // h.n
    public final boolean o() {
        return this.f1084z.o();
    }

    @Override // h.n, android.view.Menu
    public final void setGroupDividerEnabled(boolean z2) {
        this.f1084z.setGroupDividerEnabled(z2);
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderIcon(Drawable drawable) {
        u(0, null, 0, drawable, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderTitle(CharSequence charSequence) {
        u(0, charSequence, 0, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderView(View view) {
        u(0, null, 0, null, view);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setIcon(Drawable drawable) {
        this.f1083A.setIcon(drawable);
        return this;
    }

    @Override // h.n, android.view.Menu
    public final void setQwertyMode(boolean z2) {
        this.f1084z.setQwertyMode(z2);
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderIcon(int i2) {
        u(0, null, i2, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setHeaderTitle(int i2) {
        u(i2, null, 0, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public final SubMenu setIcon(int i2) {
        this.f1083A.setIcon(i2);
        return this;
    }
}
