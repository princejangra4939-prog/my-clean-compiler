package h;

import android.view.ActionProvider;

/* JADX INFO: loaded from: classes.dex */
public final class q implements ActionProvider.VisibilityListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public C.j f1192a;
    public final ActionProvider b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ u f1193c;

    public q(u uVar, ActionProvider actionProvider) {
        this.f1193c = uVar;
        this.b = actionProvider;
    }

    @Override // android.view.ActionProvider.VisibilityListener
    public final void onActionProviderVisibilityChanged(boolean z2) {
        C.j jVar = this.f1192a;
        if (jVar != null) {
            n nVar = ((p) jVar.b).f1179n;
            nVar.f1146h = true;
            nVar.p(true);
        }
    }
}
