package h;

import android.view.MenuItem;

/* JADX INFO: loaded from: classes.dex */
public interface l {
    void g(n nVar);

    boolean h(n nVar, MenuItem menuItem);
}
