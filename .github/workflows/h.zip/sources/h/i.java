package h;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import com.warppaiwarden.tictactoe.R;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class i extends BaseAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1131a = -1;
    public final /* synthetic */ j b;

    public i(j jVar) {
        this.b = jVar;
        a();
    }

    public final void a() {
        n nVar = this.b.f1133c;
        p pVar = nVar.f1160v;
        if (pVar != null) {
            nVar.i();
            ArrayList arrayList = nVar.f1148j;
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (((p) arrayList.get(i2)) == pVar) {
                    this.f1131a = i2;
                    return;
                }
            }
        }
        this.f1131a = -1;
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public final p getItem(int i2) {
        j jVar = this.b;
        n nVar = jVar.f1133c;
        nVar.i();
        ArrayList arrayList = nVar.f1148j;
        jVar.getClass();
        int i3 = this.f1131a;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return (p) arrayList.get(i2);
    }

    @Override // android.widget.Adapter
    public final int getCount() {
        j jVar = this.b;
        n nVar = jVar.f1133c;
        nVar.i();
        int size = nVar.f1148j.size();
        jVar.getClass();
        return this.f1131a < 0 ? size : size - 1;
    }

    @Override // android.widget.Adapter
    public final long getItemId(int i2) {
        return i2;
    }

    @Override // android.widget.Adapter
    public final View getView(int i2, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.b.b.inflate(R.layout.abc_list_menu_item_layout, viewGroup, false);
        }
        ((InterfaceC0039A) view).c(getItem(i2));
        return view;
    }

    @Override // android.widget.BaseAdapter
    public final void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
