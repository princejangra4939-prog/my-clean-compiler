package h;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class k extends BaseAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n f1136a;
    public int b = -1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1137c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f1138d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final LayoutInflater f1139e;
    public final int f;

    public k(n nVar, LayoutInflater layoutInflater, boolean z2, int i2) {
        this.f1138d = z2;
        this.f1139e = layoutInflater;
        this.f1136a = nVar;
        this.f = i2;
        a();
    }

    public final void a() {
        n nVar = this.f1136a;
        p pVar = nVar.f1160v;
        if (pVar != null) {
            nVar.i();
            ArrayList arrayList = nVar.f1148j;
            int size = arrayList.size();
            for (int i2 = 0; i2 < size; i2++) {
                if (((p) arrayList.get(i2)) == pVar) {
                    this.b = i2;
                    return;
                }
            }
        }
        this.b = -1;
    }

    @Override // android.widget.Adapter
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public final p getItem(int i2) {
        ArrayList arrayListL;
        n nVar = this.f1136a;
        if (this.f1138d) {
            nVar.i();
            arrayListL = nVar.f1148j;
        } else {
            arrayListL = nVar.l();
        }
        int i3 = this.b;
        if (i3 >= 0 && i2 >= i3) {
            i2++;
        }
        return (p) arrayListL.get(i2);
    }

    @Override // android.widget.Adapter
    public final int getCount() {
        ArrayList arrayListL;
        n nVar = this.f1136a;
        if (this.f1138d) {
            nVar.i();
            arrayListL = nVar.f1148j;
        } else {
            arrayListL = nVar.l();
        }
        return this.b < 0 ? arrayListL.size() : arrayListL.size() - 1;
    }

    @Override // android.widget.Adapter
    public final long getItemId(int i2) {
        return i2;
    }

    @Override // android.widget.Adapter
    public final View getView(int i2, View view, ViewGroup viewGroup) {
        boolean z2 = false;
        if (view == null) {
            view = this.f1139e.inflate(this.f, viewGroup, false);
        }
        int i3 = getItem(i2).b;
        int i4 = i2 - 1;
        int i5 = i4 >= 0 ? getItem(i4).b : i3;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        if (this.f1136a.m() && i3 != i5) {
            z2 = true;
        }
        listMenuItemView.setGroupDividerEnabled(z2);
        InterfaceC0039A interfaceC0039A = (InterfaceC0039A) view;
        if (this.f1137c) {
            listMenuItemView.setForceShowIcon(true);
        }
        interfaceC0039A.c(getItem(i2));
        return view;
    }

    @Override // android.widget.BaseAdapter
    public final void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
