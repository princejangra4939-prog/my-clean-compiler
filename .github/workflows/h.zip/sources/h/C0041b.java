package h;

import android.view.View;
import androidx.appcompat.view.menu.ActionMenuItemView;
import i.AbstractViewOnTouchListenerC0091w0;
import i.C0061h;
import i.C0063i;
import i.C0067k;
import i.C0069l;

/* JADX INFO: renamed from: h.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0041b extends AbstractViewOnTouchListenerC0091w0 {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final /* synthetic */ int f1099j = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final /* synthetic */ View f1100k;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0041b(ActionMenuItemView actionMenuItemView) {
        super(actionMenuItemView);
        this.f1100k = actionMenuItemView;
    }

    @Override // i.AbstractViewOnTouchListenerC0091w0
    public final D b() {
        C0061h c0061h;
        switch (this.f1099j) {
            case 0:
                AbstractC0042c abstractC0042c = ((ActionMenuItemView) this.f1100k).f369m;
                if (abstractC0042c == null || (c0061h = ((C0063i) abstractC0042c).f1365a.f1404t) == null) {
                    return null;
                }
                return c0061h.a();
            default:
                C0061h c0061h2 = ((C0067k) this.f1100k).f1386d.f1403s;
                if (c0061h2 == null) {
                    return null;
                }
                return c0061h2.a();
        }
    }

    @Override // i.AbstractViewOnTouchListenerC0091w0
    public final boolean c() {
        D dB;
        switch (this.f1099j) {
            case 0:
                ActionMenuItemView actionMenuItemView = (ActionMenuItemView) this.f1100k;
                m mVar = actionMenuItemView.f367k;
                return mVar != null && mVar.b(actionMenuItemView.f364h) && (dB = b()) != null && dB.a();
            default:
                ((C0067k) this.f1100k).f1386d.l();
                return true;
        }
    }

    @Override // i.AbstractViewOnTouchListenerC0091w0
    public boolean d() {
        switch (this.f1099j) {
            case 1:
                C0069l c0069l = ((C0067k) this.f1100k).f1386d;
                if (c0069l.f1405u != null) {
                    return false;
                }
                c0069l.f();
                return true;
            default:
                return super.d();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0041b(C0067k c0067k, C0067k c0067k2) {
        super(c0067k2);
        this.f1100k = c0067k;
    }
}
