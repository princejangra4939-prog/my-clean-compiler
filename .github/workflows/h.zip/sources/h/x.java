package h;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import com.warppaiwarden.tictactoe.R;

/* JADX INFO: loaded from: classes.dex */
public class x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f1201a;
    public final n b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f1202c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1203d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public View f1204e;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1205g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public y f1206h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public v f1207i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public w f1208j;
    public int f = 8388611;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public final w f1209k = new w(this);

    public x(int i2, Context context, View view, n nVar, boolean z2) {
        this.f1201a = context;
        this.b = nVar;
        this.f1204e = view;
        this.f1202c = z2;
        this.f1203d = i2;
    }

    public final v a() {
        v e2;
        if (this.f1207i == null) {
            Context context = this.f1201a;
            Display defaultDisplay = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
            Point point = new Point();
            defaultDisplay.getRealSize(point);
            if (Math.min(point.x, point.y) >= context.getResources().getDimensionPixelSize(R.dimen.abc_cascading_menus_min_smallest_width)) {
                e2 = new h(context, this.f1204e, this.f1203d, this.f1202c);
            } else {
                View view = this.f1204e;
                Context context2 = this.f1201a;
                boolean z2 = this.f1202c;
                e2 = new E(this.f1203d, context2, view, this.b, z2);
            }
            e2.l(this.b);
            e2.r(this.f1209k);
            e2.n(this.f1204e);
            e2.e(this.f1206h);
            e2.o(this.f1205g);
            e2.p(this.f);
            this.f1207i = e2;
        }
        return this.f1207i;
    }

    public final boolean b() {
        v vVar = this.f1207i;
        return vVar != null && vVar.a();
    }

    public void c() {
        this.f1207i = null;
        w wVar = this.f1208j;
        if (wVar != null) {
            wVar.onDismiss();
        }
    }

    public final void d(int i2, int i3, boolean z2, boolean z3) {
        v vVarA = a();
        vVarA.s(z3);
        if (z2) {
            if ((Gravity.getAbsoluteGravity(this.f, this.f1204e.getLayoutDirection()) & 7) == 5) {
                i2 -= this.f1204e.getWidth();
            }
            vVarA.q(i2);
            vVarA.t(i3);
            int i4 = (int) ((this.f1201a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            vVarA.f1199a = new Rect(i2 - i4, i3 - i4, i2 + i4, i3 + i4);
        }
        vVarA.h();
    }
}
