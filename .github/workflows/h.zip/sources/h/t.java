package h;

import android.view.MenuItem;

/* JADX INFO: loaded from: classes.dex */
public final class t implements MenuItem.OnMenuItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final MenuItem.OnMenuItemClickListener f1196a;
    public final /* synthetic */ u b;

    public t(u uVar, MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.b = uVar;
        this.f1196a = onMenuItemClickListener;
    }

    @Override // android.view.MenuItem.OnMenuItemClickListener
    public final boolean onMenuItemClick(MenuItem menuItem) {
        return this.f1196a.onMenuItemClick(this.b.f(menuItem));
    }
}
