package h;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import java.util.ArrayList;
import s.AbstractC0128a;
import t.InterfaceMenuItemC0131a;

/* JADX INFO: loaded from: classes.dex */
public final class p implements InterfaceMenuItemC0131a {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public q f1165A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public MenuItem.OnActionExpandListener f1166B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f1168a;
    public final int b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f1169c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f1170d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public CharSequence f1171e;
    public CharSequence f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Intent f1172g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public char f1173h;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public char f1175j;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public Drawable f1177l;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final n f1179n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public F f1180o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public MenuItem.OnMenuItemClickListener f1181p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public CharSequence f1182q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public CharSequence f1183r;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f1190y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public View f1191z;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f1174i = 4096;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f1176k = 4096;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f1178m = 0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public ColorStateList f1184s = null;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public PorterDuff.Mode f1185t = null;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f1186u = false;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f1187v = false;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f1188w = false;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f1189x = 16;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f1167C = false;

    public p(n nVar, int i2, int i3, int i4, int i5, CharSequence charSequence, int i6) {
        this.f1179n = nVar;
        this.f1168a = i3;
        this.b = i2;
        this.f1169c = i4;
        this.f1170d = i5;
        this.f1171e = charSequence;
        this.f1190y = i6;
    }

    public static void c(StringBuilder sb, int i2, int i3, String str) {
        if ((i2 & i3) == i3) {
            sb.append(str);
        }
    }

    @Override // t.InterfaceMenuItemC0131a
    public final q a() {
        return this.f1165A;
    }

    @Override // t.InterfaceMenuItemC0131a
    public final InterfaceMenuItemC0131a b(q qVar) {
        this.f1191z = null;
        this.f1165A = qVar;
        this.f1179n.p(true);
        q qVar2 = this.f1165A;
        if (qVar2 != null) {
            qVar2.f1192a = new C.j(16, this);
            qVar2.b.setVisibilityListener(qVar2);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public final boolean collapseActionView() {
        if ((this.f1190y & 8) == 0) {
            return false;
        }
        if (this.f1191z == null) {
            return true;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f1166B;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionCollapse(this)) {
            return this.f1179n.d(this);
        }
        return false;
    }

    public final Drawable d(Drawable drawable) {
        if (drawable != null && this.f1188w && (this.f1186u || this.f1187v)) {
            drawable = drawable.mutate();
            if (this.f1186u) {
                AbstractC0128a.h(drawable, this.f1184s);
            }
            if (this.f1187v) {
                AbstractC0128a.i(drawable, this.f1185t);
            }
            this.f1188w = false;
        }
        return drawable;
    }

    public final boolean e() {
        q qVar;
        if ((this.f1190y & 8) != 0) {
            if (this.f1191z == null && (qVar = this.f1165A) != null) {
                this.f1191z = qVar.b.onCreateActionView(this);
            }
            if (this.f1191z != null) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.MenuItem
    public final boolean expandActionView() {
        if (!e()) {
            return false;
        }
        MenuItem.OnActionExpandListener onActionExpandListener = this.f1166B;
        if (onActionExpandListener == null || onActionExpandListener.onMenuItemActionExpand(this)) {
            return this.f1179n.f(this);
        }
        return false;
    }

    public final void f(boolean z2) {
        if (z2) {
            this.f1189x |= 32;
        } else {
            this.f1189x &= -33;
        }
    }

    @Override // android.view.MenuItem
    public final ActionProvider getActionProvider() {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.getActionProvider()");
    }

    @Override // android.view.MenuItem
    public final View getActionView() {
        View view = this.f1191z;
        if (view != null) {
            return view;
        }
        q qVar = this.f1165A;
        if (qVar == null) {
            return null;
        }
        View viewOnCreateActionView = qVar.b.onCreateActionView(this);
        this.f1191z = viewOnCreateActionView;
        return viewOnCreateActionView;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final int getAlphabeticModifiers() {
        return this.f1176k;
    }

    @Override // android.view.MenuItem
    public final char getAlphabeticShortcut() {
        return this.f1175j;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final CharSequence getContentDescription() {
        return this.f1182q;
    }

    @Override // android.view.MenuItem
    public final int getGroupId() {
        return this.b;
    }

    @Override // android.view.MenuItem
    public final Drawable getIcon() {
        Drawable drawable = this.f1177l;
        if (drawable != null) {
            return d(drawable);
        }
        int i2 = this.f1178m;
        if (i2 == 0) {
            return null;
        }
        Drawable drawableW = D.g.w(this.f1179n.f1141a, i2);
        this.f1178m = 0;
        this.f1177l = drawableW;
        return d(drawableW);
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final ColorStateList getIconTintList() {
        return this.f1184s;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final PorterDuff.Mode getIconTintMode() {
        return this.f1185t;
    }

    @Override // android.view.MenuItem
    public final Intent getIntent() {
        return this.f1172g;
    }

    @Override // android.view.MenuItem
    public final int getItemId() {
        return this.f1168a;
    }

    @Override // android.view.MenuItem
    public final ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final int getNumericModifiers() {
        return this.f1174i;
    }

    @Override // android.view.MenuItem
    public final char getNumericShortcut() {
        return this.f1173h;
    }

    @Override // android.view.MenuItem
    public final int getOrder() {
        return this.f1169c;
    }

    @Override // android.view.MenuItem
    public final SubMenu getSubMenu() {
        return this.f1180o;
    }

    @Override // android.view.MenuItem
    public final CharSequence getTitle() {
        return this.f1171e;
    }

    @Override // android.view.MenuItem
    public final CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f;
        return charSequence != null ? charSequence : this.f1171e;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final CharSequence getTooltipText() {
        return this.f1183r;
    }

    @Override // android.view.MenuItem
    public final boolean hasSubMenu() {
        return this.f1180o != null;
    }

    @Override // android.view.MenuItem
    public final boolean isActionViewExpanded() {
        return this.f1167C;
    }

    @Override // android.view.MenuItem
    public final boolean isCheckable() {
        return (this.f1189x & 1) == 1;
    }

    @Override // android.view.MenuItem
    public final boolean isChecked() {
        return (this.f1189x & 2) == 2;
    }

    @Override // android.view.MenuItem
    public final boolean isEnabled() {
        return (this.f1189x & 16) != 0;
    }

    @Override // android.view.MenuItem
    public final boolean isVisible() {
        q qVar = this.f1165A;
        return (qVar == null || !qVar.b.overridesItemVisibility()) ? (this.f1189x & 8) == 0 : (this.f1189x & 8) == 0 && this.f1165A.b.isVisible();
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException("This is not supported, use MenuItemCompat.setActionProvider()");
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionView(View view) {
        int i2;
        this.f1191z = view;
        this.f1165A = null;
        if (view != null && view.getId() == -1 && (i2 = this.f1168a) > 0) {
            view.setId(i2);
        }
        n nVar = this.f1179n;
        nVar.f1149k = true;
        nVar.p(true);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setAlphabeticShortcut(char c2) {
        if (this.f1175j == c2) {
            return this;
        }
        this.f1175j = Character.toLowerCase(c2);
        this.f1179n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setCheckable(boolean z2) {
        int i2 = this.f1189x;
        int i3 = (z2 ? 1 : 0) | (i2 & (-2));
        this.f1189x = i3;
        if (i2 != i3) {
            this.f1179n.p(false);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setChecked(boolean z2) {
        int i2 = this.f1189x;
        if ((i2 & 4) == 0) {
            int i3 = (i2 & (-3)) | (z2 ? 2 : 0);
            this.f1189x = i3;
            if (i2 != i3) {
                this.f1179n.p(false);
            }
            return this;
        }
        n nVar = this.f1179n;
        nVar.getClass();
        ArrayList arrayList = nVar.f;
        int size = arrayList.size();
        nVar.w();
        for (int i4 = 0; i4 < size; i4++) {
            p pVar = (p) arrayList.get(i4);
            if (pVar.b == this.b && (pVar.f1189x & 4) != 0 && pVar.isCheckable()) {
                boolean z3 = pVar == this;
                int i5 = pVar.f1189x;
                int i6 = (z3 ? 2 : 0) | (i5 & (-3));
                pVar.f1189x = i6;
                if (i5 != i6) {
                    pVar.f1179n.p(false);
                }
            }
        }
        nVar.v();
        return this;
    }

    @Override // android.view.MenuItem
    public final /* bridge */ /* synthetic */ MenuItem setContentDescription(CharSequence charSequence) {
        setContentDescription(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setEnabled(boolean z2) {
        if (z2) {
            this.f1189x |= 16;
        } else {
            this.f1189x &= -17;
        }
        this.f1179n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIcon(Drawable drawable) {
        this.f1178m = 0;
        this.f1177l = drawable;
        this.f1188w = true;
        this.f1179n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f1184s = colorStateList;
        this.f1186u = true;
        this.f1188w = true;
        this.f1179n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f1185t = mode;
        this.f1187v = true;
        this.f1188w = true;
        this.f1179n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIntent(Intent intent) {
        this.f1172g = intent;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setNumericShortcut(char c2) {
        if (this.f1173h == c2) {
            return this;
        }
        this.f1173h = c2;
        this.f1179n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        this.f1166B = onActionExpandListener;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        this.f1181p = onMenuItemClickListener;
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setShortcut(char c2, char c3) {
        this.f1173h = c2;
        this.f1175j = Character.toLowerCase(c3);
        this.f1179n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final void setShowAsAction(int i2) {
        int i3 = i2 & 3;
        if (i3 != 0 && i3 != 1 && i3 != 2) {
            throw new IllegalArgumentException("SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive.");
        }
        this.f1190y = i2;
        n nVar = this.f1179n;
        nVar.f1149k = true;
        nVar.p(true);
    }

    @Override // android.view.MenuItem
    public final MenuItem setShowAsActionFlags(int i2) {
        setShowAsAction(i2);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitle(CharSequence charSequence) {
        this.f1171e = charSequence;
        this.f1179n.p(false);
        F f = this.f1180o;
        if (f != null) {
            f.setHeaderTitle(charSequence);
        }
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f = charSequence;
        this.f1179n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final /* bridge */ /* synthetic */ MenuItem setTooltipText(CharSequence charSequence) {
        setTooltipText(charSequence);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setVisible(boolean z2) {
        int i2 = this.f1189x;
        int i3 = (z2 ? 0 : 8) | (i2 & (-9));
        this.f1189x = i3;
        if (i2 != i3) {
            n nVar = this.f1179n;
            nVar.f1146h = true;
            nVar.p(true);
        }
        return this;
    }

    public final String toString() {
        CharSequence charSequence = this.f1171e;
        if (charSequence != null) {
            return charSequence.toString();
        }
        return null;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final InterfaceMenuItemC0131a setContentDescription(CharSequence charSequence) {
        this.f1182q = charSequence;
        this.f1179n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final InterfaceMenuItemC0131a setTooltipText(CharSequence charSequence) {
        this.f1183r = charSequence;
        this.f1179n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setAlphabeticShortcut(char c2, int i2) {
        if (this.f1175j == c2 && this.f1176k == i2) {
            return this;
        }
        this.f1175j = Character.toLowerCase(c2);
        this.f1176k = KeyEvent.normalizeMetaState(i2);
        this.f1179n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setNumericShortcut(char c2, int i2) {
        if (this.f1173h == c2 && this.f1174i == i2) {
            return this;
        }
        this.f1173h = c2;
        this.f1174i = KeyEvent.normalizeMetaState(i2);
        this.f1179n.p(false);
        return this;
    }

    @Override // t.InterfaceMenuItemC0131a, android.view.MenuItem
    public final MenuItem setShortcut(char c2, char c3, int i2, int i3) {
        this.f1173h = c2;
        this.f1174i = KeyEvent.normalizeMetaState(i2);
        this.f1175j = Character.toLowerCase(c3);
        this.f1176k = KeyEvent.normalizeMetaState(i3);
        this.f1179n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setIcon(int i2) {
        this.f1177l = null;
        this.f1178m = i2;
        this.f1188w = true;
        this.f1179n.p(false);
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setTitle(int i2) {
        setTitle(this.f1179n.f1141a.getString(i2));
        return this;
    }

    @Override // android.view.MenuItem
    public final MenuItem setActionView(int i2) {
        int i3;
        Context context = this.f1179n.f1141a;
        View viewInflate = LayoutInflater.from(context).inflate(i2, (ViewGroup) new LinearLayout(context), false);
        this.f1191z = viewInflate;
        this.f1165A = null;
        if (viewInflate != null && viewInflate.getId() == -1 && (i3 = this.f1168a) > 0) {
            viewInflate.setId(i3);
        }
        n nVar = this.f1179n;
        nVar.f1149k = true;
        nVar.p(true);
        return this;
    }
}
