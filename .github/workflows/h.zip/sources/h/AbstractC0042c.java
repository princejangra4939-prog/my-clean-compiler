package h;

/* JADX INFO: renamed from: h.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0042c {
}
