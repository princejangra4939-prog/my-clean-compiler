package h;

/* JADX INFO: loaded from: classes.dex */
public interface m {
    boolean b(p pVar);
}
