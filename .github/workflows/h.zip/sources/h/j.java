package h;

import android.content.Context;
import android.content.ContextWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import androidx.appcompat.view.menu.ExpandedMenuView;
import e.C0015b;
import e.C0019f;
import e.DialogC0020g;

/* JADX INFO: loaded from: classes.dex */
public final class j implements z, AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Context f1132a;
    public LayoutInflater b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public n f1133c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ExpandedMenuView f1134d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public y f1135e;
    public i f;

    public j(ContextWrapper contextWrapper) {
        this.f1132a = contextWrapper;
        this.b = LayoutInflater.from(contextWrapper);
    }

    @Override // h.z
    public final void b(n nVar, boolean z2) {
        y yVar = this.f1135e;
        if (yVar != null) {
            yVar.b(nVar, z2);
        }
    }

    @Override // h.z
    public final void c() {
        i iVar = this.f;
        if (iVar != null) {
            iVar.notifyDataSetChanged();
        }
    }

    @Override // h.z
    public final boolean d(p pVar) {
        return false;
    }

    @Override // h.z
    public final void e(y yVar) {
        throw null;
    }

    @Override // h.z
    public final void g(Context context, n nVar) {
        if (this.f1132a != null) {
            this.f1132a = context;
            if (this.b == null) {
                this.b = LayoutInflater.from(context);
            }
        }
        this.f1133c = nVar;
        i iVar = this.f;
        if (iVar != null) {
            iVar.notifyDataSetChanged();
        }
    }

    @Override // h.z
    public final boolean i() {
        return false;
    }

    @Override // h.z
    public final boolean j(F f) {
        if (!f.hasVisibleItems()) {
            return false;
        }
        o oVar = new o();
        oVar.f1163a = f;
        Context context = f.f1141a;
        C0019f c0019f = new C0019f(context);
        C0015b c0015b = (C0015b) c0019f.b;
        j jVar = new j(c0015b.f943a);
        oVar.f1164c = jVar;
        jVar.f1135e = oVar;
        f.b(jVar, context);
        j jVar2 = oVar.f1164c;
        if (jVar2.f == null) {
            jVar2.f = new i(jVar2);
        }
        c0015b.f947g = jVar2.f;
        c0015b.f948h = oVar;
        View view = f.f1153o;
        if (view != null) {
            c0015b.f946e = view;
        } else {
            c0015b.f944c = f.f1152n;
            c0015b.f945d = f.f1151m;
        }
        c0015b.f = oVar;
        DialogC0020g dialogC0020gA = c0019f.a();
        oVar.b = dialogC0020gA;
        dialogC0020gA.setOnDismissListener(oVar);
        WindowManager.LayoutParams attributes = oVar.b.getWindow().getAttributes();
        attributes.type = 1003;
        attributes.flags |= 131072;
        oVar.b.show();
        y yVar = this.f1135e;
        if (yVar == null) {
            return true;
        }
        yVar.m(f);
        return true;
    }

    @Override // h.z
    public final boolean k(p pVar) {
        return false;
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        this.f1133c.q(this.f.getItem(i2), this, 0);
    }
}
