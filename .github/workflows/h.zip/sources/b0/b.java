package b0;

import f0.c;

/* JADX INFO: loaded from: classes.dex */
public class b extends a0.a {
    @Override // Z.a
    public final f0.a a() {
        Integer num = a.f786a;
        return (num == null || num.intValue() >= 34) ? new g0.a() : new c();
    }
}
