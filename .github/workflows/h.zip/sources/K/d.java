package k;

import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class d extends e implements Iterator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public c f1490a;
    public boolean b = true;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ f f1491c;

    public d(f fVar) {
        this.f1491c = fVar;
    }

    @Override // k.e
    public final void a(c cVar) {
        c cVar2 = this.f1490a;
        if (cVar == cVar2) {
            c cVar3 = cVar2.f1489d;
            this.f1490a = cVar3;
            this.b = cVar3 == null;
        }
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.b) {
            return this.f1491c.f1492a != null;
        }
        c cVar = this.f1490a;
        return (cVar == null || cVar.f1488c == null) ? false : true;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (this.b) {
            this.b = false;
            this.f1490a = this.f1491c.f1492a;
        } else {
            c cVar = this.f1490a;
            this.f1490a = cVar != null ? cVar.f1488c : null;
        }
        return this.f1490a;
    }
}
