package k;

import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public final class b extends e implements Iterator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public c f1485a;
    public c b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f1486c;

    public b(c cVar, c cVar2, int i2) {
        this.f1486c = i2;
        this.f1485a = cVar2;
        this.b = cVar;
    }

    @Override // k.e
    public final void a(c cVar) {
        c cVar2;
        c cVarB = null;
        if (this.f1485a == cVar && cVar == this.b) {
            this.b = null;
            this.f1485a = null;
        }
        c cVar3 = this.f1485a;
        if (cVar3 == cVar) {
            switch (this.f1486c) {
                case 0:
                    cVar2 = cVar3.f1489d;
                    break;
                default:
                    cVar2 = cVar3.f1488c;
                    break;
            }
            this.f1485a = cVar2;
        }
        c cVar4 = this.b;
        if (cVar4 == cVar) {
            c cVar5 = this.f1485a;
            if (cVar4 != cVar5 && cVar5 != null) {
                cVarB = b(cVar4);
            }
            this.b = cVarB;
        }
    }

    public final c b(c cVar) {
        switch (this.f1486c) {
            case 0:
                return cVar.f1488c;
            default:
                return cVar.f1489d;
        }
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.b != null;
    }

    @Override // java.util.Iterator
    public final Object next() {
        c cVar = this.b;
        c cVar2 = this.f1485a;
        this.b = (cVar == cVar2 || cVar2 == null) ? null : b(cVar);
        return cVar;
    }
}
