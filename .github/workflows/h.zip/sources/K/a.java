package K;

import F.d;
import androidx.lifecycle.E;
import l.C0112l;

/* JADX INFO: loaded from: classes.dex */
public class a extends E {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final d f77d = new d(3);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C0112l f78c = new C0112l();

    @Override // androidx.lifecycle.E
    public final void a() {
        C0112l c0112l = this.f78c;
        int i2 = c0112l.f1533c;
        if (i2 > 0) {
            c0112l.b[0].getClass();
            throw new ClassCastException();
        }
        Object[] objArr = c0112l.b;
        for (int i3 = 0; i3 < i2; i3++) {
            objArr[i3] = null;
        }
        c0112l.f1533c = 0;
    }
}
