package k;

import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class c implements Map.Entry {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f1487a;
    public final Object b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public c f1488c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public c f1489d;

    public c(Object obj, Object obj2) {
        this.f1487a = obj;
        this.b = obj2;
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return this.f1487a.equals(cVar.f1487a) && this.b.equals(cVar.b);
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.f1487a;
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.b;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        return this.f1487a.hashCode() ^ this.b.hashCode();
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        throw new UnsupportedOperationException("An entry modification is not supported");
    }

    public final String toString() {
        return this.f1487a + "=" + this.b;
    }
}
