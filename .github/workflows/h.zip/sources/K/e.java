package k;

/* JADX INFO: loaded from: classes.dex */
public abstract class e {
    public abstract void a(c cVar);
}
