package k;

import java.util.HashMap;

/* JADX INFO: renamed from: k.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0100a extends f {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final HashMap f1484e = new HashMap();

    public final c a(Object obj) {
        return (c) this.f1484e.get(obj);
    }
}
