package f0;

import java.util.Random;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f1011a = Z.b.f302a.a();

    public abstract Random a();

    public final int b() {
        return a().nextInt(2147418112);
    }
}
