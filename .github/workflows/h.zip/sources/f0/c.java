package f0;

import java.util.Random;

/* JADX INFO: loaded from: classes.dex */
public final class c extends a {
    public final b b = new b();

    @Override // f0.a
    public final Random a() {
        Object obj = this.b.get();
        e0.c.d(obj, "implStorage.get()");
        return (Random) obj;
    }
}
